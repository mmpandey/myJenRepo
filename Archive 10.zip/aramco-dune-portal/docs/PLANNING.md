# Operational Planning & Decision Support

The portal now goes from "what will the sand do" to "what should we do about it". The **Planning** page (`/planning`) answers four questions from the latest prediction run:

| # | Question | Answer on the page |
|---|---|---|
| 1 | What is going to happen? | Risk counts, total sand volume (m³), sites with observed movement, wind, daily volume chart |
| 2 | Which site needs attention first? | Ranked list with a 0 to 100 score, a tier (P1 to P4) and the reasons |
| 3 | When should the team go? | Day-by-day crew schedule (leave / arrive / finish), capacity check, sites that do not fit |
| 4 | Who and what should be deployed? | Per site: equipment, vehicles, people. Per crew: have vs need, units to add from the yard, one-click dispatch |

## Inputs and what is ignored
Only prediction numbers are used: risk, sand deposition (expected, range), dune direction and intensity, confidence, net accumulation, observed movement, the run's wind summary and daily volume series.

**The prediction API's own `schedule`, `scheduling`, team and equipment fields are never read.** They are removed when the response arrives (`stripApiScheduling` in `backend/sandSiteDashboard.js`) so they are not stored either. Crews, equipment, bookings and distances come from this application.

## API
`GET /api/planning/plan[?run_id=]` returns `run`, `assumptions`, `forecast`, `answers`, `sites` (ranked, with `plan` and `deployment`), `schedule` (`days`, `stops`), `crews`, `crew_bases` and `capacity`. Default is the latest completed run; `null` if none exists. It is computed on demand from the current crews, equipment and bookings, so nothing is stored and no database change was needed (`schema.sql` is unchanged).

## Rules (all in `backend/planning.js`)
**Priority score (0 to 100):** risk 40 (High 40, Moderate 24, Low 8) + volume 25 (expected m³ / 500, capped) + dune movement 15 (intensity %) + confidence 10 + growth 10 (depth still rising 5, movement observed 5).
**Tiers:** P1 Act now (60+, start by day 2), P2 Plan this week (40+, start within 3 days), P3 Routine (20+, any time in the window), P4 Monitor only (below 20, not scheduled).
**Deployment by sand volume:** under 100 m³: skid-steer, sweeper, pickup. 100 to 299: bulldozer, pickup. 300 and above: bulldozer, wheel loader, pickup. High risk adds an ATV for survey. People = 1 supervisor + one per unit. At most 2 heavy units per crew, same as the Equipment page.
**On-site hours:** volume / (40 m³ per hour per heavy unit), or 15 m³ per hour for light-only jobs, rounded up to 15 minutes, minimum 1 hour.
**Schedule:** for each day and each crew that is not off duty (crews on a job start the next day), repeatedly take the highest tier first, nearest site next, as long as drive out + work + drive back fit the shift (default 07:00, 10 hours). A site is only split across days if no single shift could finish it. One crew per site per day. Whatever does not fit is listed with the extra crew-days needed.
**Equipment match:** a crew's own AVAILABLE units are counted first; the gap is filled from yard units that are available and not booked in the window. Shortfalls are shown, never hidden.

## Assumptions to confirm with the client
Work rates, shift length, speed and the scoring weights are placeholders in `CONFIG` (and `PLAN_*` environment variables). Distances are straight-line x 1.3 until a crew is dispatched, when the existing OSRM road route is used. Tier thresholds are on the page so reviewers can see them.
