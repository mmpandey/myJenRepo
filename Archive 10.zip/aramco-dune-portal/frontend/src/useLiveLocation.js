import { useEffect, useRef, useState } from 'react';
import { api } from './api';

const REPORT_INTERVAL_MS = 20000; // don't hammer the API on every GPS tick

export function useLiveLocationReporting(crewId, enabled) {
  const [status, setStatus] = useState('idle'); // idle | requesting | active | denied | unsupported
  const [lastPosition, setLastPosition] = useState(null); // { lat, lon, heading } — updated every GPS tick, not throttled
  const lastSentAt = useRef(0);
  const watchId = useRef(null);

  useEffect(() => {
    if (!enabled || !crewId) return undefined;

    if (!('geolocation' in navigator)) {
      setStatus('unsupported');
      return undefined;
    }

    setStatus('requesting');

    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        setStatus('active');
        const heading = typeof pos.coords.heading === 'number' && !Number.isNaN(pos.coords.heading) ? pos.coords.heading : null;
        setLastPosition({ lat: pos.coords.latitude, lon: pos.coords.longitude, heading });

        const now = Date.now();
        if (now - lastSentAt.current < REPORT_INTERVAL_MS) return;
        lastSentAt.current = now;
        api.reportCrewLocation(crewId, pos.coords.latitude, pos.coords.longitude, heading).catch(() => {
          // A missed location ping isn't worth interrupting the crew over — silently retry next tick
        });
      },
      () => setStatus('denied'),
      { enableHighAccuracy: false, maximumAge: 15000, timeout: 20000 }
    );

    return () => {
      if (watchId.current != null) navigator.geolocation.clearWatch(watchId.current);
    };
  }, [crewId, enabled]);

  return { status, lastPosition };
}
