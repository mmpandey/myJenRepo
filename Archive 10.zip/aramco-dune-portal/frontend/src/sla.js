import { haversineMeters } from './constants';

// Response-time targets by priority — the core of the "business value" this
// adds: turning raw timestamps into an on-track/at-risk/breached read a
// dispatcher or stakeholder can act on at a glance.
export const SLA_TARGET_MINUTES = {
  CRITICAL: 30,
  HIGH: 60,
  MEDIUM: 120,
  LOW: 240,
};

function findEventTime(events, status) {
  const match = (events || []).find((e) => e.status === status);
  return match ? new Date(match.created_at).getTime() : null;
}

/**
 * Returns null if there's nothing meaningful to say (e.g. still OPEN with no
 * crew assigned yet), otherwise one of:
 *   { phase: 'resolved', met: boolean, elapsedMin }
 *   { phase: 'pending', level: 'on_track' | 'at_risk' | 'breached', elapsedMin, targetMin }
 */
export function computeSlaStatus(wo) {
  if (wo.status === 'CANCELLED' || wo.status === 'OPEN') return null;
  const targetMin = SLA_TARGET_MINUTES[wo.priority];
  if (!targetMin) return null;

  const dispatchedAt = findEventTime(wo.events, 'DISPATCHED') ?? new Date(wo.created_at).getTime();
  const arrivedAt = findEventTime(wo.events, 'IN_PROGRESS');

  if (arrivedAt) {
    const elapsedMin = (arrivedAt - dispatchedAt) / 60000;
    return { phase: 'resolved', met: elapsedMin <= targetMin, elapsedMin, targetMin };
  }

  const elapsedMin = (Date.now() - dispatchedAt) / 60000;
  const ratio = elapsedMin / targetMin;
  const level = ratio < 0.8 ? 'on_track' : ratio <= 1 ? 'at_risk' : 'breached';
  return { phase: 'pending', level, elapsedMin, targetMin };
}

export const SLA_LABEL = {
  on_track: 'On track',
  at_risk: 'At risk',
  breached: 'SLA breached',
};

/**
 * Approximate live progress toward the asset, using the crew's current
 * (live-or-base) position vs. the planned route distance. Straight-line, so
 * it's an estimate of remaining distance, not a road-accurate figure — good
 * enough to drive a progress bar without another routing API call per tick.
 */
export function computeRouteProgress(wo) {
  if (!wo.distance_km || wo.crew_lat == null || wo.asset_lat == null) return null;
  if (!['DISPATCHED', 'IN_PROGRESS'].includes(wo.status)) return null;

  const remainingKm = haversineMeters(wo.crew_lat, wo.crew_lon, wo.asset_lat, wo.asset_lon) / 1000;
  const pct = Math.max(0, Math.min(100, Math.round(100 * (1 - remainingKm / wo.distance_km))));
  return { remainingKm: Math.round(remainingKm * 10) / 10, pct };
}
