import React, { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', end: true },
  { to: '/prediction', label: 'Prediction' },
  { to: '/planning', label: 'Planning' },
  { to: '/schedule', label: 'Scheduling Team' },
  { to: '/dispatch', label: 'Dispatch' },
  { to: '/work-orders', label: 'Work orders' },
  { to: '/crews', label: 'Crews' },
  { to: '/equipment', label: 'Equipment' },
];

const PAGE_TITLES = {
  '/': 'Operations Dashboard',
  '/prediction': 'Sand Accumulation Prediction',
  '/planning': 'Operational Planning',
  '/schedule': 'Scheduling Team',
  '/dispatch': 'Dispatch',
  '/work-orders': 'Work Orders',
  '/crews': 'Crews',
  '/equipment': 'Equipment',
};

function DateTime() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(id);
  }, []);
  const o = { timeZone: 'Asia/Riyadh' };
  return (
    <span className="header-clock">
      {now.toLocaleDateString('en-GB', { ...o, day: '2-digit', month: 'short', year: 'numeric' })}
      <span className="header-sep">|</span>
      {now.toLocaleTimeString('en-GB', { ...o, hour: '2-digit', minute: '2-digit' })}
    </span>
  );
}

export default function DesktopLayout() {
  const [online, setOnline] = useState(true);
  const { pathname } = useLocation();

  useEffect(() => {
    // Lightweight liveness check against the API, independent of any one page's data fetch
    let cancelled = false;
    const check = async () => {
      try {
        const res = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}/api/health`);
        if (!cancelled) setOnline(res.ok);
      } catch {
        if (!cancelled) setOnline(false);
      }
    };
    check();
    const id = setInterval(check, 15000);
    return () => { cancelled = true; clearInterval(id); };
  }, []);

  return (
    <div className="portal">
      <header className="portal-header">
        <div className="brand">
          <span className="brand-mark">DDX</span>
          <span className="brand-divider" />
          <h1 className="brand-title">{PAGE_TITLES[pathname] || 'Dune Dynamix'}</h1>
        </div>

        <div className="header-status">
          <div className="status-pill" title={online ? 'API reachable' : 'API unreachable'}>
            <span className={`status-dot${online ? '' : ' offline'}`} />
            {online ? 'Live' : 'Offline'}
          </div>
          <DateTime />
          <span className="user-avatar" aria-label="Signed-in user">DX</span>
        </div>
      </header>

      <nav className="main-nav" aria-label="Main">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) => `main-nav-link${isActive ? ' active' : ''}`}
          >
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="portal-body">
        <Outlet />
      </div>
    </div>
  );
}
