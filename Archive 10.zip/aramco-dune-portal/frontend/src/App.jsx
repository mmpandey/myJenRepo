import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ToastProvider } from './ToastContext';
import { SiteProvider } from './SiteContext';
import DesktopLayout from './components/DesktopLayout';
import Dashboard from './pages/Dashboard';
import Prediction from './pages/Prediction';
import Planning from './pages/Planning';
import ScheduleTeam from './pages/ScheduleTeam';
import Dispatch from './pages/Dispatch';
import WorkOrders from './pages/WorkOrders';
import Crews from './pages/Crews';
import Equipment from './pages/Equipment';
import CrewGate from './pages/CrewGate';
import CrewMobile from './pages/CrewMobile';

export default function App() {
  return (
    <ToastProvider>
      <SiteProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/crew" element={<CrewGate />} />
            <Route path="/crew/:crewId" element={<CrewMobile />} />
            <Route element={<DesktopLayout />}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/prediction" element={<Prediction />} />
              <Route path="/planning" element={<Planning />} />
              <Route path="/schedule" element={<ScheduleTeam />} />
              <Route path="/dispatch" element={<Dispatch />} />
              <Route path="/work-orders" element={<WorkOrders />} />
              <Route path="/crews" element={<Crews />} />
              <Route path="/equipment" element={<Equipment />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </SiteProvider>
    </ToastProvider>
  );
}
