const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000';

async function apiRequest(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  return res.json();
}

export const api = {
  getSummary: () => apiRequest('/api/dashboard/summary'),
  getAssets: (siteId) => apiRequest(`/api/assets/impacted${siteId ? `?site_id=${siteId}` : ''}`),
  getSites: () => apiRequest('/api/sites'),
  getLatestPrediction: (siteId) => apiRequest(`/api/sites/${siteId}/predictions/latest`),
  getPrediction: (id) => apiRequest(`/api/predictions/${id}`),
  runPrediction: (siteId, startDate, endDate) =>
    apiRequest(`/api/sites/${siteId}/predict`, { method: 'POST', body: JSON.stringify({ start_date: startDate, end_date: endDate }) }),
  // Sand Accumulation Prediction (AI backend / mock) — global, multi-site, 7-day run.
  runSiteDashboardPrediction: (startDate, endDate) =>
    apiRequest('/api/predictions/run', { method: 'POST', body: JSON.stringify({ start_date: startDate, end_date: endDate }) }),
  getPlan: (runId) => apiRequest(`/api/planning/plan${runId ? `?run_id=${runId}` : ''}`),
  getLatestPredictionRun: () => apiRequest('/api/predictions/runs/latest'),
  getPredictionRuns: (limit = 20) => apiRequest(`/api/predictions/runs?limit=${limit}`),
  getPredictionRun: (runId) => apiRequest(`/api/predictions/runs/${runId}`),
  getSiteRoutes: (siteId, limit = 5) => apiRequest(`/api/sites/${siteId}/routes?limit=${limit}`),
  getPredictionRoutes: (predictionId) => apiRequest(`/api/predictions/${predictionId}/routes`),
  getTeamPlan: (predictionId) => apiRequest(`/api/predictions/${predictionId}/team`),
  saveTeam: (predictionId, crewIds) =>
    apiRequest(`/api/predictions/${predictionId}/team`, { method: 'PUT', body: JSON.stringify({ crew_ids: crewIds }) }),
  getSiteLayers: (siteId) => apiRequest(`/api/sites/${siteId}/layers`),
  getEquipment: (params = {}) => {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null)).toString();
    return apiRequest(`/api/equipment${qs ? `?${qs}` : ''}`);
  },
  getEquipmentTypes: () => apiRequest('/api/equipment/types'),
  getEquipmentSchedules: (params = {}) => {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null)).toString();
    return apiRequest(`/api/equipment/schedules${qs ? `?${qs}` : ''}`);
  },
  createEquipmentSchedule: (body) => apiRequest('/api/equipment/schedules', { method: 'POST', body: JSON.stringify(body) }),
  setEquipmentScheduleStatus: (id, status) => apiRequest(`/api/equipment/schedules/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }),
  deleteEquipmentSchedule: (id) => apiRequest(`/api/equipment/schedules/${id}`, { method: 'DELETE' }),
  getEquipmentAvailability: (from, to, cls = '') => apiRequest(`/api/equipment/availability?from=${from}&to=${to}${cls ? `&class=${cls}` : ''}`),
  getEquipmentReport: () => apiRequest('/api/equipment/report'),
  getEquipmentSummary: () => apiRequest('/api/equipment/summary'),
  getEquipmentHistory: (id) => apiRequest(`/api/equipment/${id}/history`),
  createEquipment: (body) => apiRequest('/api/equipment', { method: 'POST', body: JSON.stringify(body) }),
  updateEquipment: (id, body) => apiRequest(`/api/equipment/${id}`, { method: 'PUT', body: JSON.stringify(body) }),
  deleteEquipment: (id) => apiRequest(`/api/equipment/${id}`, { method: 'DELETE' }),
  assignEquipment: (id, crewId) =>
    apiRequest(`/api/equipment/${id}`, { method: 'PATCH', body: JSON.stringify({ crew_id: crewId }) }),
  getPolygons: () => apiRequest('/api/forecasts/polygons'),
  getCrews: () => apiRequest('/api/crews'),
  getCrewDirectory: () => apiRequest('/api/crews/directory'),
  crewLogin: (crewId, accessCode) =>
    apiRequest('/api/crews/login', { method: 'POST', body: JSON.stringify({ crew_id: crewId, access_code: accessCode }) }),
  getCrewAccessCode: (crewId) => apiRequest(`/api/crews/${crewId}/access-code`),
  reportCrewLocation: (crewId, lat, lon, heading) =>
    apiRequest(`/api/crews/${crewId}/location`, { method: 'POST', body: JSON.stringify({ lat, lon, heading }) }),
  getCrewTrail: (crewId, limit = 30) => apiRequest(`/api/crews/${crewId}/trail?limit=${limit}`),
  getNearestCrews: (assetId) => apiRequest(`/api/crews/nearest?asset_id=${assetId}`),
  getWorkOrders: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return apiRequest(`/api/work-orders${qs ? `?${qs}` : ''}`);
  },
  createWorkOrder: (body) =>
    apiRequest('/api/work-orders', { method: 'POST', body: JSON.stringify(body) }),
  updateWorkOrderStatus: (id, status, note) =>
    apiRequest(`/api/work-orders/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status, note }) }),
  addWorkOrderNote: (id, note) =>
    apiRequest(`/api/work-orders/${id}/notes`, { method: 'POST', body: JSON.stringify({ note }) }),
  setWorkOrderFlag: (id, flagged, reason) =>
    apiRequest(`/api/work-orders/${id}/flag`, { method: 'PATCH', body: JSON.stringify({ flagged, reason }) }),
};

export { API_BASE };
