import L from 'leaflet';
import { PRIORITY_COLORS, RISK_COLORS } from './constants';

export function makeAssetIcon(priority) {
  const color = PRIORITY_COLORS[priority] || PRIORITY_COLORS.NONE;
  const pulse = priority === 'CRITICAL';
  return L.divIcon({
    className: '',
    html: `<div class="dune-marker${pulse ? ' pulse' : ''}" style="width:16px;height:16px;background:${color};color:${color};"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
    popupAnchor: [0, -8],
  });
}

export function makeCrewIcon(status, heading) {
  const color = status === 'AVAILABLE' ? '#0e9f9a' : status === 'DISPATCHED' ? '#d4a24e' : '#5b6479';
  const rotation = typeof heading === 'number' ? heading : 0;
  const pulse = status === 'DISPATCHED';

  // Top-down vehicle silhouette (pickup/utility truck): cab windshield + bed
  // rails, so it reads as a real vehicle rather than an abstract shape, and
  // rotates to face its actual direction of travel when a GPS heading exists.
  const truckSvg = `
    <svg viewBox="0 0 24 24" width="26" height="26" style="transform: rotate(${rotation}deg); transition: transform 0.6s ease;">
      <rect x="6.5" y="2.5" width="11" height="19" rx="2.5" fill="${color}" stroke="#0b1220" stroke-width="1.4"/>
      <rect x="8.3" y="4.3" width="7.4" height="4.6" rx="1.1" fill="#0b1220" opacity="0.55"/>
      <line x1="8" y1="12.2" x2="16" y2="12.2" stroke="#0b1220" stroke-width="0.9" opacity="0.45"/>
      <line x1="8" y1="14.6" x2="16" y2="14.6" stroke="#0b1220" stroke-width="0.9" opacity="0.45"/>
      <rect x="5.3" y="6" width="1.6" height="3.4" rx="0.6" fill="#0b1220" opacity="0.7"/>
      <rect x="17.1" y="6" width="1.6" height="3.4" rx="0.6" fill="#0b1220" opacity="0.7"/>
      <rect x="5.3" y="15.2" width="1.6" height="3.4" rx="0.6" fill="#0b1220" opacity="0.7"/>
      <rect x="17.1" y="15.2" width="1.6" height="3.4" rx="0.6" fill="#0b1220" opacity="0.7"/>
    </svg>`;

  return L.divIcon({
    className: '',
    html: `<div class="crew-vehicle-marker${pulse ? ' pulse' : ''}" style="color:${color};">${truckSvg}</div>`,
    iconSize: [26, 26],
    iconAnchor: [13, 13],
    popupAnchor: [0, -13],
  });
}

export function forecastStyle(feature) {
  const risk = feature.properties.risk_level;
  const color = RISK_COLORS[risk] || '#3fb68b';
  return { color, weight: 1.5, fillColor: color, fillOpacity: 0.16 };
}

export function routeLineFromCoords(crewLon, crewLat, assetLon, assetLat) {
  // Straight-line preview (used before an actual road route has been computed)
  return [
    [crewLat, crewLon],
    [assetLat, assetLon],
  ];
}
