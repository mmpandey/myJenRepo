import turfDistance from '@turf/distance';
import { point } from '@turf/helpers';

export const RISK_COLORS = {
  HIGH: '#e8742a',
  MEDIUM: '#d9a21b',
  LOW: '#2f9e73',
};

export const PRIORITY_COLORS = {
  CRITICAL: '#e5484d',
  HIGH: '#e8742a',
  MEDIUM: '#d9a21b',
  LOW: '#2f9e73',
  NONE: '#3fb68b',
};

export const ASSET_TYPES = ['PIPELINE', 'FACILITY', 'WELLHEAD', 'ROAD'];

export const STATUS_FLOW = { OPEN: 'DISPATCHED', DISPATCHED: 'IN_PROGRESS', IN_PROGRESS: 'COMPLETED' };

export const STATUS_LABEL = {
  OPEN: 'Open',
  DISPATCHED: 'Dispatched',
  IN_PROGRESS: 'In progress',
  COMPLETED: 'Completed',
  CANCELLED: 'Cancelled',
  ISSUE_REPORTED: 'Issue reported',
  ISSUE_CLEARED: 'Issue cleared',
};

// Basemap for every map: OpenStreetMap raster tiles (open data, no API key, no paid GIS platform).
// The public tile server is fine for development and light use. For production traffic, point VITE_TILE_URL at your
// own OSM tile server or a tile host you have a licence for (same {z}/{x}/{y} template), see OSM's tile usage policy.
export const TILE_URL = import.meta.env.VITE_TILE_URL || 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
export const TILE_ATTRIBUTION = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

export function titleCase(s) {
  if (!s) return '';
  return s.charAt(0) + s.slice(1).toLowerCase();
}

export function formatEta(minutes) {
  if (minutes == null) return null;
  if (minutes < 60) return `${minutes} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h}h ${m}m`;
}

export function crewMobileUrl(crewId) {
  return `${window.location.origin}/crew/${crewId}`;
}

export function crewAppUrl() {
  return `${window.location.origin}/crew`;
}

// Straight-line distance in meters (Turf.js great-circle distance) — used for the "you've arrived" geofence
// check on the crew's phone and for the progress bar, where an instant local answer matters more than a road route.
export function haversineMeters(lat1, lon1, lat2, lon2) {
  return turfDistance(point([lon1, lat1]), point([lon2, lat2]), { units: 'kilometers' }) * 1000;
}

export const CREW_SESSION_KEY = 'ddx_crew_session';

export function timeAgo(isoString) {
  if (!isoString) return null;
  const seconds = Math.floor((Date.now() - new Date(isoString).getTime()) / 1000);
  if (seconds < 10) return 'just now';
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h ago`;
}
