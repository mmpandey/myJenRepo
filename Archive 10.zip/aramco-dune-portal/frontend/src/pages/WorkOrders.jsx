import React, { useCallback, useEffect, useState } from 'react';
import { api } from '../api';
import { useSearchParams } from 'react-router-dom';
import { useToast } from '../ToastContext';
import { useSite } from '../SiteContext';
import { STATUS_FLOW, STATUS_LABEL, formatEta } from '../constants';
import { computeSlaStatus, computeRouteProgress, SLA_LABEL } from '../sla';

const TABS = ['ALL', 'FLAGGED', 'OPEN', 'DISPATCHED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'];

export default function WorkOrders() {
  const showToast = useToast();
  const [params, setParams] = useSearchParams();
  const { sites } = useSite();
  const siteFilter = params.get('site');
  const [workOrders, setWorkOrders] = useState([]);
  const [tab, setTab] = useState('ALL');
  const [expanded, setExpanded] = useState(() => new Set());

  const load = useCallback(async () => {
    try {
      const data = await api.getWorkOrders(siteFilter ? { site_id: siteFilter } : {});
      setWorkOrders(data);
    } catch (err) {
      showToast(err.message, true);
    }
  }, [showToast, siteFilter]);

  useEffect(() => {
    load();
    const id = setInterval(load, 15000);
    return () => clearInterval(id);
  }, [load]);

  const toggleExpanded = (id) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const advanceStatus = async (wo) => {
    const next = STATUS_FLOW[wo.status];
    if (!next) return;
    try {
      await api.updateWorkOrderStatus(wo.id, next);
      showToast(`Work order #${wo.id} marked ${STATUS_LABEL[next].toLowerCase()}`);
      load();
    } catch (err) {
      showToast(err.message, true);
    }
  };

  const cancelOrder = async (wo) => {
    try {
      await api.updateWorkOrderStatus(wo.id, 'CANCELLED');
      showToast(`Work order #${wo.id} cancelled`);
      load();
    } catch (err) {
      showToast(err.message, true);
    }
  };

  const acknowledgeIssue = async (wo) => {
    try {
      await api.setWorkOrderFlag(wo.id, false, null);
      showToast(`Issue on #${wo.id} acknowledged and cleared`);
      load();
    } catch (err) {
      showToast(err.message, true);
    }
  };

  const filtered = tab === 'ALL' ? workOrders
    : tab === 'FLAGGED' ? workOrders.filter((w) => w.flagged)
    : workOrders.filter((w) => w.status === tab);

  const countFor = (t) => (
    t === 'ALL' ? workOrders.length
    : t === 'FLAGGED' ? workOrders.filter((w) => w.flagged).length
    : workOrders.filter((w) => w.status === t).length
  );

  return (
    <div className="page page-work-orders">
      <div className="page-header-row">
        <h1 className="page-title">Work orders</h1>
        <select className="select-control" style={{ maxWidth: 320 }} value={siteFilter || ''} onChange={(e) => setParams(e.target.value ? { site: e.target.value } : {})}>
          <option value="">All sites</option>
          {sites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </div>

      <div className="status-tabbar">
        {TABS.map((t) => (
          <button key={t} className={`status-tab${tab === t ? ' active' : ''}${t === 'FLAGGED' ? ' status-tab-flagged' : ''}`} onClick={() => setTab(t)}>
            {t === 'ALL' ? 'All' : t === 'FLAGGED' ? 'Flagged' : STATUS_LABEL[t]} ({countFor(t)})
          </button>
        ))}
      </div>

      {filtered.length ? (
        <div className="wo-list wo-list-wide">
          {filtered.map((wo) => {
            const sla = computeSlaStatus(wo);
            const progress = computeRouteProgress(wo);
            return (
            <div className={`wo-card${wo.flagged ? ' wo-card-flagged' : ''}`} key={wo.id}>
              <div className="wo-top">
                <span className="wo-id">#{String(wo.id).padStart(4, '0')}</span>
                <span className={`badge badge-${wo.priority.toLowerCase()}`}>{wo.priority}</span>
              </div>
              <div className="wo-asset">{wo.asset_name} <span className="wo-detail-inline">({wo.asset_type})</span></div>

              {wo.flagged && (
                <div className="issue-banner">
                  <strong>Issue reported:</strong> {wo.flag_reason}
                  <button className="link-btn link-btn-light" onClick={() => acknowledgeIssue(wo)}>Acknowledge</button>
                </div>
              )}

              {wo.site_name && <div className="wo-detail">Site: {wo.site_code} · {wo.site_name}</div>}
              <div className="wo-detail">Status: {STATUS_LABEL[wo.status]}</div>
              <div className="wo-detail">Crew: {wo.crew_name || 'Unassigned'}{wo.crew_engine_id ? ` · Engine ${wo.crew_engine_id}` : ''}</div>
              {wo.distance_km != null && (
                <div className="wo-detail">Route: {wo.distance_km} km · ETA {formatEta(wo.eta_minutes)}</div>
              )}
              {progress && (
                <>
                  <div className="mini-progress-track"><div className="mini-progress-fill" style={{ width: `${progress.pct}%` }} /></div>
                  <div className="wo-detail-faint">{progress.pct}% of the way there · {progress.remainingKm} km remaining (approx)</div>
                </>
              )}
              {sla && (
                sla.phase === 'pending'
                  ? <div className={`sla-chip sla-${sla.level}`}>{SLA_LABEL[sla.level]} · {Math.round(sla.elapsedMin)} min elapsed (target {sla.targetMin} min)</div>
                  : <div className={`sla-chip ${sla.met ? 'sla-on_track' : 'sla-breached'}`}>{sla.met ? 'Met SLA' : 'Missed SLA'} · responded in {Math.round(sla.elapsedMin)} min</div>
              )}
              <div className="wo-detail">Opened: {new Date(wo.created_at).toLocaleString()}</div>

              {!['COMPLETED', 'CANCELLED'].includes(wo.status) && (
                <div className="wo-actions">
                  <button className="btn btn-primary" onClick={() => advanceStatus(wo)}>
                    Mark {STATUS_LABEL[STATUS_FLOW[wo.status]].toLowerCase()}
                  </button>
                  <button className="btn btn-ghost" onClick={() => cancelOrder(wo)}>Cancel</button>
                </div>
              )}

              <button className="link-btn" onClick={() => toggleExpanded(wo.id)}>
                {expanded.has(wo.id) ? 'Hide' : 'Show'} audit trail ({wo.events.length})
              </button>

              {expanded.has(wo.id) && (
                <ul className="audit-trail">
                  {wo.events.map((e, i) => (
                    <li key={i}>
                      <span className="audit-time">{new Date(e.created_at).toLocaleString()}</span>
                      <span className="audit-status">{STATUS_LABEL[e.status] || e.status}</span>
                      {e.note && <span className="audit-note">— {e.note}</span>}
                    </li>
                  ))}
                </ul>
              )}
            </div>
            );
          })}
        </div>
      ) : (
        <div className="empty-state"><span>No work orders in this view.</span></div>
      )}
    </div>
  );
}
