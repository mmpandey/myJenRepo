import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, Polyline, GeoJSON } from 'react-leaflet';
import L from 'leaflet';
import { api } from '../api';
import { useToast } from '../ToastContext';
import { STATUS_FLOW, STATUS_LABEL, formatEta, TILE_URL, TILE_ATTRIBUTION, CREW_SESSION_KEY, haversineMeters } from '../constants';
import { makeAssetIcon, makeCrewIcon, routeLineFromCoords } from '../mapUtils';
import { pushSupported, getPushStatus, enablePushForCrew } from '../push';
import { useLiveLocationReporting } from '../useLiveLocation';

// Short two-tone alert beep, synthesized with Web Audio so no external
// sound file is needed. Fails silently if the browser blocks autoplay.
function playAlertTone() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    [880, 660].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq;
      osc.type = 'sine';
      gain.gain.setValueAtTime(0.001, ctx.currentTime + i * 0.22);
      gain.gain.exponentialRampToValueAtTime(0.15, ctx.currentTime + i * 0.22 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.22 + 0.2);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + i * 0.22);
      osc.stop(ctx.currentTime + i * 0.22 + 0.22);
    });
  } catch (e) {
    // Web Audio unavailable — safe to ignore, push notification still covers this case
  }
}

function NotificationSetup({ crewId }) {
  const showToast = useToast();
  const [status, setStatus] = useState('checking');

  useEffect(() => {
    if (!pushSupported()) { setStatus('unsupported'); return; }
    getPushStatus().then(setStatus);
  }, []);

  const handleEnable = async () => {
    setStatus('working');
    try {
      await enablePushForCrew(crewId);
      setStatus('subscribed');
      showToast('Alerts enabled — you\'ll get a notification for new jobs, even with the app closed.');
    } catch (err) {
      setStatus('not-subscribed');
      showToast(err.message, true);
    }
  };

  if (status === 'unsupported' || status === 'checking') return null;

  if (status === 'subscribed') {
    return <div className="push-status push-status-on">🔔 Alerts on — you'll be notified of new jobs</div>;
  }

  if (status === 'denied') {
    return <div className="push-status push-status-off">🔕 Notifications blocked — enable them in your browser's site settings</div>;
  }

  return (
    <button className="btn btn-ghost btn-block push-enable-btn" onClick={handleEnable} disabled={status === 'working'}>
      {status === 'working' ? 'Enabling…' : '🔔 Enable alerts for new jobs'}
    </button>
  );
}

function LocationSharing({ status, enabled, onEnable }) {
  if (enabled) {
    if (status === 'active') return <div className="push-status push-status-on">📍 Sharing your location — dispatch can see you live</div>;
    if (status === 'denied') return <div className="push-status push-status-off">📍 Location blocked — enable it in your browser's site settings</div>;
    if (status === 'unsupported') return <div className="push-status push-status-off">📍 Location isn't supported on this device</div>;
    return <div className="push-status push-status-off">📍 Requesting location…</div>;
  }

  return (
    <button className="btn btn-ghost btn-block push-enable-btn" onClick={onEnable}>
      📍 Share my location with dispatch
    </button>
  );
}

function MiniRouteMap({ wo }) {
  if (wo.crew_lon == null || wo.asset_lon == null) return null;
  const bounds = L.latLngBounds([
    [wo.crew_lat, wo.crew_lon],
    [wo.asset_lat, wo.asset_lon],
  ]);
  return (
    <div className="mobile-route-map">
      <MapContainer bounds={bounds} boundsOptions={{ padding: [24, 24] }} scrollWheelZoom={false} dragging={false} style={{ height: '160px', width: '100%' }}>
        <TileLayer url={TILE_URL} attribution={TILE_ATTRIBUTION} />
        <Marker position={[wo.crew_lat, wo.crew_lon]} icon={makeCrewIcon('DISPATCHED')} />
        <Marker position={[wo.asset_lat, wo.asset_lon]} icon={makeAssetIcon(wo.priority)} />
        {wo.route_geometry ? (
          <GeoJSON data={wo.route_geometry} style={{ color: '#0e9f9a', weight: 4 }} />
        ) : (
          <Polyline
            positions={routeLineFromCoords(wo.crew_lon, wo.crew_lat, wo.asset_lon, wo.asset_lat)}
            pathOptions={{ color: '#d4a24e', weight: 2, dashArray: '6 8' }}
          />
        )}
      </MapContainer>
    </div>
  );
}

function ActiveJobCard({ wo, onAdvance, onLogNote, onSetFlag }) {
  const [note, setNote] = useState('');
  const [showIssueForm, setShowIssueForm] = useState(false);
  const [issueReason, setIssueReason] = useState('');
  const [busy, setBusy] = useState(false);

  const handleAdvance = async () => {
    setBusy(true);
    await onAdvance(wo, note.trim() || null);
    setNote('');
    setBusy(false);
  };

  const handleLogNote = async () => {
    if (!note.trim()) return;
    setBusy(true);
    await onLogNote(wo, note.trim());
    setNote('');
    setBusy(false);
  };

  const handleReportIssue = async () => {
    if (!issueReason.trim()) return;
    setBusy(true);
    await onSetFlag(wo, true, issueReason.trim());
    setIssueReason('');
    setShowIssueForm(false);
    setBusy(false);
  };

  const handleClearIssue = async () => {
    setBusy(true);
    await onSetFlag(wo, false, null);
    setBusy(false);
  };

  return (
    <div className={`mobile-card${wo.flagged ? ' mobile-card-flagged' : ''}`}>
      <div className="wo-top">
        <span className="wo-id">#{String(wo.id).padStart(4, '0')}</span>
        <span className={`badge badge-${wo.priority.toLowerCase()}`}>{wo.priority}</span>
      </div>
      <div className="wo-asset">{wo.asset_name}</div>
      <div className="wo-detail">{wo.recommended_action}</div>

      {wo.flagged && (
        <div className="issue-banner">
          <strong>Issue reported:</strong> {wo.flag_reason}
          <button className="link-btn link-btn-light" onClick={handleClearIssue} disabled={busy}>Mark resolved</button>
        </div>
      )}

      <MiniRouteMap wo={wo} />

      {wo.distance_km != null && (
        <div className="mobile-route-summary">
          <strong>{wo.distance_km} km</strong> · ETA <strong>{formatEta(wo.eta_minutes)}</strong>
        </div>
      )}

      <div className="field-label">Add a note (optional)</div>
      <textarea
        className="select-control mobile-textarea"
        placeholder="e.g. extra sand on the east side, may need more time…"
        value={note}
        onChange={(e) => setNote(e.target.value)}
        rows={2}
      />
      <div className="mobile-note-actions">
        <button className="btn btn-ghost" onClick={handleLogNote} disabled={busy || !note.trim()}>
          Log note only
        </button>
      </div>

      <button className="btn btn-primary btn-block btn-large" onClick={handleAdvance} disabled={busy}>
        Mark {STATUS_LABEL[STATUS_FLOW[wo.status]]}
      </button>

      {!wo.flagged && (
        showIssueForm ? (
          <div className="issue-form">
            <div className="field-label">What's the problem?</div>
            <textarea
              className="select-control mobile-textarea"
              placeholder="e.g. need extra equipment, site worse than expected…"
              value={issueReason}
              onChange={(e) => setIssueReason(e.target.value)}
              rows={2}
            />
            <div className="mobile-note-actions">
              <button className="btn btn-ghost" onClick={() => setShowIssueForm(false)} disabled={busy}>Cancel</button>
              <button className="btn btn-primary" onClick={handleReportIssue} disabled={busy || !issueReason.trim()}>Send</button>
            </div>
          </div>
        ) : (
          <button className="link-btn" onClick={() => setShowIssueForm(true)}>Report an issue</button>
        )
      )}
    </div>
  );
}

export default function CrewMobile({ crewIdProp, onLogout } = {}) {
  const params = useParams();
  const crewId = crewIdProp ?? params.crewId;
  const showToast = useToast();
  const [crew, setCrew] = useState(null);
  const [workOrders, setWorkOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [newAlert, setNewAlert] = useState(null);
  const [locationEnabled, setLocationEnabled] = useState(false);
  const [arrivalPrompt, setArrivalPrompt] = useState(null);
  const [celebrate, setCelebrate] = useState(false);
  const [tab, setTab] = useState('home');

  const { status: locationStatus, lastPosition } = useLiveLocationReporting(crewId, locationEnabled);
  const promptedIds = useRef(new Set());
  const knownActiveIds = useRef(null); // null = not yet initialized (first load)
  const titleFlashRef = useRef(null);
  const originalTitle = useRef(document.title);

  const load = useCallback(async () => {
    try {
      const [crews, wo] = await Promise.all([api.getCrews(), api.getWorkOrders({ crew_id: crewId })]);
      const match = crews.find((c) => String(c.id) === String(crewId));
      if (!match) {
        setNotFound(true);
      } else {
        setCrew(match);
        setWorkOrders(wo);

        const activeNow = wo.filter((w) => !['COMPLETED', 'CANCELLED'].includes(w.status));
        const activeIds = new Set(activeNow.map((w) => w.id));

        if (knownActiveIds.current !== null) {
          const newlyAssigned = activeNow.filter((w) => !knownActiveIds.current.has(w.id));
          if (newlyAssigned.length > 0) {
            playAlertTone();
            if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
            setNewAlert(
              newlyAssigned.length === 1
                ? `New job assigned: ${newlyAssigned[0].asset_name}`
                : `${newlyAssigned.length} new jobs assigned`
            );
          }
        }
        knownActiveIds.current = activeIds;
      }
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setLoading(false);
    }
  }, [crewId, showToast]);

  useEffect(() => {
    load();
    const id = setInterval(load, 8000);
    return () => clearInterval(id);
  }, [load]);

  // Flash the browser tab title while an unacknowledged alert is showing, so
  // it's noticeable even if the crew has switched to another tab.
  useEffect(() => {
    if (newAlert) {
      let flashOn = false;
      titleFlashRef.current = setInterval(() => {
        document.title = flashOn ? originalTitle.current : '🔴 New job assigned!';
        flashOn = !flashOn;
      }, 1000);
    } else {
      clearInterval(titleFlashRef.current);
      document.title = originalTitle.current;
    }
    return () => clearInterval(titleFlashRef.current);
  }, [newAlert]);

  // Geofence: proactively offer to mark a job "started" once the crew's own
  // GPS says they're actually at the asset — they shouldn't have to remember
  // to do this manually mid-task.
  useEffect(() => {
    if (!lastPosition) return;
    const ARRIVAL_THRESHOLD_M = 300;
    const dispatchedJobs = workOrders.filter((w) => w.status === 'DISPATCHED' && w.asset_lat != null);

    for (const wo of dispatchedJobs) {
      if (promptedIds.current.has(wo.id)) continue;
      const distance = haversineMeters(lastPosition.lat, lastPosition.lon, wo.asset_lat, wo.asset_lon);
      if (distance <= ARRIVAL_THRESHOLD_M) {
        promptedIds.current.add(wo.id);
        setArrivalPrompt(wo);
        if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
        break; // one prompt at a time
      }
    }
  }, [lastPosition, workOrders]);

  const advance = async (wo, note) => {
    const next = STATUS_FLOW[wo.status];
    if (!next) return;
    try {
      await api.updateWorkOrderStatus(wo.id, next, note);
      showToast(`Marked ${STATUS_LABEL[next].toLowerCase()}`);
      if (next === 'COMPLETED') {
        setCelebrate(true);
        if (navigator.vibrate) navigator.vibrate([80, 40, 80, 40, 160]);
        setTimeout(() => setCelebrate(false), 2500);
      }
      if (arrivalPrompt?.id === wo.id) setArrivalPrompt(null);
      load();
    } catch (err) {
      showToast(err.message, true);
    }
  };

  const logNote = async (wo, note) => {
    try {
      await api.addWorkOrderNote(wo.id, note);
      showToast('Note added to job history');
      load();
    } catch (err) {
      showToast(err.message, true);
    }
  };

  const setFlag = async (wo, flagged, reason) => {
    try {
      await api.setWorkOrderFlag(wo.id, flagged, reason);
      showToast(flagged ? 'Issue reported to dispatcher' : 'Issue marked resolved');
      load();
    } catch (err) {
      showToast(err.message, true);
    }
  };

  if (loading) {
    return <div className="mobile-shell"><div className="empty-state"><span>Loading your assignments…</span></div></div>;
  }

  if (notFound) {
    return (
      <div className="mobile-shell">
        <div className="empty-state">
          <span>Crew not found.</span>
          <span>Double check the link your dispatcher sent you.</span>
        </div>
      </div>
    );
  }

  const active = workOrders.filter((w) => !['COMPLETED', 'CANCELLED'].includes(w.status));
  const history = workOrders.filter((w) => ['COMPLETED', 'CANCELLED'].includes(w.status));
  const completedToday = history.filter((w) => {
    if (w.status !== 'COMPLETED') return false;
    const d = new Date(w.updated_at);
    const now = new Date();
    return d.toDateString() === now.toDateString();
  }).length;

  return (
    <div className="mobile-shell mobile-shell-tabbed">
      {celebrate && (
        <div className="celebrate-overlay">
          <div className="celebrate-badge">🎉<br />Nice work!</div>
        </div>
      )}

      <header className="mobile-header">
        <div className="brand-mark">DDX</div>
        <div>
          <div className="mobile-crew-name">{crew.name}</div>
          <div className="mobile-crew-meta">{crew.specialty} · {crew.status.replace('_', ' ')} · {crew.engine_id}</div>
        </div>
        {onLogout && (
          <button className="mobile-logout-btn" onClick={onLogout} title="Switch crew">⇄</button>
        )}
      </header>

      <div className="mobile-body mobile-body-tabbed">
        {tab === 'home' && (
          <>
            <div className="crew-home-card">
              <div className="crew-home-greeting">Welcome back, {crew.name.split(' ')[0]}</div>
              <div className="crew-home-sub">{crew.specialty} specialist · Engine {crew.engine_id}</div>
              <div className={`status-chip status-chip-${crew.status.toLowerCase()}`}>{crew.status.replace('_', ' ')}</div>
            </div>

            <div className="crew-home-stats">
              <div className="crew-home-stat">
                <div className="crew-home-stat-value">{active.length}</div>
                <div className="crew-home-stat-label">Active jobs</div>
              </div>
              <div className="crew-home-stat">
                <div className="crew-home-stat-value">{completedToday}</div>
                <div className="crew-home-stat-label">Completed today</div>
              </div>
              <div className="crew-home-stat">
                <div className="crew-home-stat-value">{history.filter((w) => w.status === 'COMPLETED').length}</div>
                <div className="crew-home-stat-label">Completed all-time</div>
              </div>
            </div>

            {active.length > 0 && (
              <button className="btn btn-primary btn-block btn-large" onClick={() => setTab('jobs')}>
                View my {active.length} active job{active.length !== 1 ? 's' : ''} →
              </button>
            )}

            <div className="mobile-section-title">Alerts &amp; sharing</div>
            <NotificationSetup crewId={crewId} />
            <LocationSharing status={locationStatus} enabled={locationEnabled} onEnable={() => setLocationEnabled(true)} />
          </>
        )}

        {tab === 'jobs' && (
          <>
            {newAlert && (
              <div className="new-job-alert" onClick={() => setNewAlert(null)}>
                🔔 {newAlert} — tap to dismiss
              </div>
            )}

            {arrivalPrompt && (
              <div className="arrival-prompt">
                <div>📍 Looks like you've arrived at <strong>{arrivalPrompt.asset_name}</strong>. Mark it started?</div>
                <div className="mobile-note-actions">
                  <button className="btn btn-ghost" onClick={() => setArrivalPrompt(null)}>Not yet</button>
                  <button className="btn btn-primary" onClick={() => advance(arrivalPrompt, null)}>Mark started</button>
                </div>
              </div>
            )}

            <div className="mobile-section-title">Your assignments ({active.length})</div>

            {active.length ? (
              active.map((wo) => (
                <ActiveJobCard key={wo.id} wo={wo} onAdvance={advance} onLogNote={logNote} onSetFlag={setFlag} />
              ))
            ) : (
              <div className="empty-state"><span>No active assignments right now.</span></div>
            )}
          </>
        )}

        {tab === 'history' && (
          <>
            <div className="mobile-section-title">Job history ({history.length})</div>
            {history.length ? (
              history.map((wo) => (
                <div className="mobile-card mobile-card-muted" key={wo.id}>
                  <div className="wo-top">
                    <span className="wo-id">#{String(wo.id).padStart(4, '0')}</span>
                    <span className={`badge badge-${wo.priority.toLowerCase()}`}>{wo.priority}</span>
                  </div>
                  <div className="wo-asset">{wo.asset_name}</div>
                  <div className="wo-detail">{STATUS_LABEL[wo.status]} · {new Date(wo.updated_at).toLocaleDateString()}</div>
                  {wo.distance_km != null && <div className="wo-detail-faint">{wo.distance_km} km driven</div>}
                </div>
              ))
            ) : (
              <div className="empty-state"><span>No completed jobs yet.</span></div>
            )}
          </>
        )}
      </div>

      <nav className="mobile-tabbar">
        <button className={`mobile-tab-btn${tab === 'home' ? ' active' : ''}`} onClick={() => setTab('home')}>
          <span className="mobile-tab-icon">🏠</span>Home
        </button>
        <button className={`mobile-tab-btn${tab === 'jobs' ? ' active' : ''}`} onClick={() => setTab('jobs')}>
          <span className="mobile-tab-icon">📋</span>Jobs
          {active.length > 0 && <span className="mobile-tab-badge">{active.length}</span>}
        </button>
        <button className={`mobile-tab-btn${tab === 'history' ? ' active' : ''}`} onClick={() => setTab('history')}>
          <span className="mobile-tab-icon">🕓</span>History
        </button>
      </nav>
    </div>
  );
}
