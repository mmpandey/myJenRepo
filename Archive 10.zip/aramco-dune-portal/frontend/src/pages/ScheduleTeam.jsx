import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { MapContainer, TileLayer, GeoJSON, CircleMarker, Tooltip, useMap } from 'react-leaflet';
import L from 'leaflet';
import turfBbox from '@turf/bbox';
import { featureCollection, point } from '@turf/helpers';
import { api } from '../api';
import { useToast } from '../ToastContext';
import { useSite } from '../SiteContext';
import { formatEta, TILE_URL, TILE_ATTRIBUTION } from '../constants';

const RISK_LABEL = { LOW: 'Low', MODERATE: 'Moderate', HIGH: 'High' };

function Coverage({ label, unit, required, assigned }) {
  const gap = Math.max(0, required - assigned);
  const pct = required ? Math.min(100, Math.round((assigned / required) * 100)) : 100;
  return (
    <div className="pred-card cover-card">
      <div className="pred-stat-label">{label}</div>
      <div className="cover-num">{assigned}<small> / {required} {unit}</small></div>
      <div className="cover-track"><div className={`cover-fill${gap ? ' short' : ''}`} style={{ width: `${pct}%` }} /></div>
      <div className={`cover-state${gap ? ' short' : ''}`}>{gap ? `Short by ${gap}` : assigned > required ? `Covered (+${assigned - required} spare)` : 'Covered'}</div>
    </div>
  );
}

function EquipmentChip({ unit, onRemove, busy }) {
  return (
    <span className={`eq-chip eq-${unit.equipment_class.toLowerCase()}`} title={`${unit.unit_code} · ${unit.equipment_type}`}>
      <b>{unit.equipment_class === 'HEAVY' ? 'H' : 'L'}</b> {unit.name}
      <button className="eq-x" aria-label={`Remove ${unit.name}`} disabled={busy} onClick={() => onRemove(unit)}>×</button>
    </span>
  );
}


const ROUTE_COLORS = ['#4f46e5', '#0d9488', '#d97706', '#db2777', '#0284c7'];

function FitRoutes({ bounds }) {
  const map = useMap();
  useEffect(() => { if (bounds) map.fitBounds(bounds, { padding: [30, 30], maxZoom: 13 }); }, [map, bounds]);
  return null;
}

// Crew -> site routes: nearest crews are ranked by PostGIS, the road path / distance / ETA come from OSRM.
function RoutesMap({ routes, site }) {
  const bounds = useMemo(() => {
    if (!routes?.site) return null;
    const pts = [point([routes.site.lon, routes.site.lat]), ...routes.routes.map((r) => point([r.from.lon, r.from.lat]))];
    const [w, s, e, n] = turfBbox(featureCollection(pts));
    return L.latLngBounds([s, w], [n, e]);
  }, [routes]);
  if (!routes) return null;
  return (
    <section className="pred-card">
      <h3 className="pred-card-title"><span className="pred-dot" /> Routes to {routes.site.name}</h3>
      <div className="st-routes">
        <div className="pred-map st-routes-map">
          <MapContainer center={[routes.site.lat, routes.site.lon]} zoom={11} scrollWheelZoom={false}>
            <TileLayer url={TILE_URL} attribution={TILE_ATTRIBUTION} />
            <FitRoutes bounds={bounds} />
            {routes.routes.map((r, i) => r.route_geometry && (
              <GeoJSON key={`${r.crew_id}-${r.distance_km}`} data={r.route_geometry}
                style={{ color: ROUTE_COLORS[i % ROUTE_COLORS.length], weight: r.in_team ? 5 : 3, opacity: r.in_team ? 0.9 : 0.55, dashArray: r.in_team ? undefined : '6 6' }} />
            ))}
            {routes.routes.map((r, i) => (
              <CircleMarker key={`c${r.crew_id}`} center={[r.from.lat, r.from.lon]} radius={7}
                pathOptions={{ color: '#fff', weight: 2, fillColor: ROUTE_COLORS[i % ROUTE_COLORS.length], fillOpacity: 1 }}>
                <Tooltip>{r.crew_name}</Tooltip>
              </CircleMarker>
            ))}
            <CircleMarker center={[routes.site.lat, routes.site.lon]} radius={9} pathOptions={{ color: '#fff', weight: 2, fillColor: '#dc2626', fillOpacity: 1 }}>
              <Tooltip permanent direction="top">{routes.site.name}</Tooltip>
            </CircleMarker>
          </MapContainer>
        </div>
        <table className="st-table st-route-table">
          <thead><tr><th>Crew</th><th>Distance</th><th>ETA</th></tr></thead>
          <tbody>
            {routes.routes.map((r, i) => (
              <tr key={r.crew_id}>
                <td><span className="st-swatch" style={{ background: ROUTE_COLORS[i % ROUTE_COLORS.length] }} />{r.crew_name}{r.in_team && <span className="st-team-tag">team</span>}</td>
                <td>{r.distance_km != null ? `${r.distance_km} km` : `${r.straight_line_km} km*`}</td>
                <td>{r.eta_minutes != null ? formatEta(r.eta_minutes) : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {routes.routes.some((r) => r.distance_km == null) && <p className="st-note">* straight-line distance — the routing service did not answer.</p>}
      </div>
    </section>
  );
}

export default function ScheduleTeam() {
  const showToast = useToast();
  const [params] = useSearchParams();
  const { siteId, site } = useSite();

  const [prediction, setPrediction] = useState(null);
  const [plan, setPlan] = useState(null);
  const [selected, setSelected] = useState(() => new Set());
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [poolTab, setPoolTab] = useState('HEAVY');
  const [routes, setRoutes] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      let pred = null;
      if (params.get('prediction')) pred = await api.getPrediction(params.get('prediction'));
      else if (siteId) pred = await api.getLatestPrediction(siteId);
      setPrediction(pred);
      if (pred) {
        const p = await api.getTeamPlan(pred.id);
        setPlan(p);
        setSelected(new Set(p.crews.filter((c) => c.selected).map((c) => c.id)));
        setDirty(false);
        api.getPredictionRoutes(pred.id).then(setRoutes).catch(() => setRoutes(null));
      } else {
        setPlan(null);
      }
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setLoading(false);
    }
  }, [params, siteId, showToast]);
  useEffect(() => { load(); }, [load]);

  // refresh crews/equipment after an equipment change without losing unsaved crew ticks
  const refreshPlan = async () => {
    const p = await api.getTeamPlan(prediction.id);
    setPlan(p);
  };

  const assign = async (unitId, crewId) => {
    setBusy(true);
    try {
      await api.assignEquipment(unitId, crewId);
      await refreshPlan();
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setBusy(false);
    }
  };

  const toggle = (id) => {
    setSelected((prev) => { const n = new Set(prev); if (n.has(id)) n.delete(id); else n.add(id); return n; });
    setDirty(true);
  };

  const save = async () => {
    setBusy(true);
    try {
      const p = await api.saveTeam(prediction.id, [...selected]);
      setPlan(p);
      api.getPredictionRoutes(prediction.id).then(setRoutes).catch(() => {});
      setDirty(false);
      showToast(p.covered ? 'Scheduling team saved. All requirements are covered.' : 'Scheduling team saved. Some requirements are still short.');
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setBusy(false);
    }
  };

  // live coverage from the ticked crews and their current equipment
  const live = useMemo(() => {
    if (!plan) return null;
    const picked = plan.crews.filter((c) => selected.has(c.id));
    return {
      people: picked.reduce((a, c) => a + c.headcount, 0),
      heavy: picked.reduce((a, c) => a + c.equipment.filter((e) => e.equipment_class === 'HEAVY').length, 0),
      light: picked.reduce((a, c) => a + c.equipment.filter((e) => e.equipment_class === 'LIGHT').length, 0),
      crews: picked.length,
    };
  }, [plan, selected]);

  const free = (plan?.equipment ?? []).filter((e) => !e.crew_id && e.status === 'AVAILABLE');
  const poolRows = (plan?.equipment ?? []).filter((e) => e.equipment_class === poolTab);
  const siteQ = prediction ? `?site=${prediction.site_id}` : siteId ? `?site=${siteId}` : '';

  return (
    <div className="pred-page">
      <section className="pred-bar st-bar">
        <div>
          <div className="pred-bar-label">Scheduling team</div>
          <div className="st-title">
            {prediction ? `${site?.name ?? `Site #${prediction.site_id}`} · ${prediction.window_start} → ${prediction.window_end}` : 'No prediction selected'}
            {prediction && <span className={`pred-chip pred-chip-${prediction.risk_level.toLowerCase()}`}>{RISK_LABEL[prediction.risk_level]} risk</span>}
          </div>
        </div>
        <div className="st-actions">
          <Link className="btn btn-ghost" to="/equipment">Manage equipment</Link>
          <Link className="btn btn-ghost" to="/prediction">← Back to prediction</Link>
          <button className="btn btn-primary" onClick={save} disabled={!plan || busy || !dirty}>{dirty ? 'Save scheduling team' : 'Saved'}</button>
        </div>
      </section>

      {!loading && !prediction && (
        <div className="empty-state"><span>There is no prediction to schedule yet.</span><Link className="link-btn" to="/prediction">Run a prediction first</Link></div>
      )}

      {plan && live && (
        <>
          <div className="st-cover">
            <Coverage label="People" unit="people" required={plan.required.people} assigned={live.people} />
            <Coverage label="Heavy equipment" unit="units" required={plan.required.heavy_units} assigned={live.heavy} />
            <Coverage label="Light equipment" unit="units" required={plan.required.light_units} assigned={live.light} />
          </div>
          <p className="st-note">
            Tick the crews that will work this site, then give them the equipment they need. Heavy equipment (dozers, loaders, graders, excavators) is limited to 2 units per crew.
            Crews are <b>not</b> dispatched automatically — assign jobs manually from Dispatch.
          </p>

          <div className="st-grid">
            <section className="pred-card">
              <h3 className="pred-card-title"><span className="pred-dot" /> Crews ({live.crews} selected)</h3>
              <div className="st-crews">
                {plan.crews.map((c) => {
                  const off = c.status === 'OFF_DUTY';
                  return (
                    <div key={c.id} className={`st-crew${selected.has(c.id) ? ' selected' : ''}${off ? ' off' : ''}`}>
                      <label className="st-crew-head">
                        <input type="checkbox" checked={selected.has(c.id)} disabled={off || busy} onChange={() => toggle(c.id)} />
                        <span className="st-crew-name">{c.name}</span>
                        <span className={`status-chip status-chip-${c.status.toLowerCase()}`}>{c.status.replace('_', ' ')}</span>
                      </label>
                      <div className="wo-detail">{c.specialty} · {c.headcount} people · {c.base_location}</div>
                      <div className="st-eq-list">
                        {c.equipment.length
                          ? c.equipment.map((u) => <EquipmentChip key={u.id} unit={u} busy={busy} onRemove={(x) => assign(x.id, null)} />)
                          : <span className="wo-detail-faint">No equipment assigned</span>}
                      </div>
                      {!off && (
                        <select className="select-control st-add" value="" disabled={busy || !free.length} onChange={(e) => e.target.value && assign(Number(e.target.value), c.id)}>
                          <option value="">{free.length ? '+ Add equipment…' : 'No free equipment'}</option>
                          <optgroup label="Heavy equipment">
                            {free.filter((e) => e.equipment_class === 'HEAVY').map((e) => <option key={e.id} value={e.id}>{e.name} ({e.unit_code})</option>)}
                          </optgroup>
                          <optgroup label="Light equipment">
                            {free.filter((e) => e.equipment_class === 'LIGHT').map((e) => <option key={e.id} value={e.id}>{e.name} ({e.unit_code})</option>)}
                          </optgroup>
                        </select>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>

            <section className="pred-card">
              <h3 className="pred-card-title"><span className="pred-dot" /> Equipment pool</h3>
              <div className="st-tabs">
                {['HEAVY', 'LIGHT'].map((t) => {
                  const all = plan.equipment.filter((e) => e.equipment_class === t);
                  return (
                    <button key={t} className={`st-tab${poolTab === t ? ' active' : ''}`} onClick={() => setPoolTab(t)}>
                      {t === 'HEAVY' ? 'Heavy' : 'Light'} ({all.filter((e) => !e.crew_id && e.status === 'AVAILABLE').length} free / {all.length})
                    </button>
                  );
                })}
              </div>
              <table className="st-table">
                <thead><tr><th>Unit</th><th>Type</th><th>Status</th><th>Assigned to</th></tr></thead>
                <tbody>
                  {poolRows.map((e) => (
                    <tr key={e.id}>
                      <td><div className="st-unit">{e.name}</div><div className="mono-value">{e.unit_code}</div></td>
                      <td>{e.equipment_type}</td>
                      <td><span className={`status-chip ${e.status === 'MAINTENANCE' ? 'status-chip-off_duty' : 'status-chip-available'}`}>{e.status === 'MAINTENANCE' ? 'Maintenance' : 'Available'}</span></td>
                      <td>
                        {e.status === 'MAINTENANCE' ? <span className="wo-detail-faint">—</span> : (
                          <select className="select-control" value={e.crew_id ?? ''} disabled={busy} onChange={(ev) => assign(e.id, ev.target.value ? Number(ev.target.value) : null)}>
                            <option value="">Unassigned (yard)</option>
                            {plan.crews.filter((c) => c.status !== 'OFF_DUTY').map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                          </select>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          </div>
        </>
      )}

      {plan && <RoutesMap routes={routes} />}

      <section className="pred-card st-next">
        <h3 className="pred-card-title"><span className="pred-dot" /> Continue to</h3>
        <div className="st-next-grid">
          <Link className="st-next-tile" to="/"><b>Dashboard</b><span>Operations overview, SLA and priorities</span></Link>
          <Link className="st-next-tile" to={`/dispatch${siteQ}`}><b>Dispatch</b><span>Assign crews to assets and route them manually</span></Link>
          <Link className="st-next-tile" to={`/work-orders${siteQ}`}><b>Work orders</b><span>Track status, SLA and the audit trail</span></Link>
          <Link className="st-next-tile" to="/crews"><b>Crews</b><span>Roster, live location and equipment</span></Link>
        </div>
      </section>
    </div>
  );
}
