import React, { useState } from 'react';
import CrewLogin from './CrewLogin';
import CrewMobile from './CrewMobile';
import { CREW_SESSION_KEY } from '../constants';

function loadSession() {
  try {
    const raw = localStorage.getItem(CREW_SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export default function CrewGate() {
  const [session, setSession] = useState(loadSession);

  const handleLogout = () => {
    localStorage.removeItem(CREW_SESSION_KEY);
    setSession(null);
  };

  if (!session) {
    return <CrewLogin onLoggedIn={setSession} />;
  }

  return <CrewMobile crewIdProp={session.id} onLogout={handleLogout} />;
}
