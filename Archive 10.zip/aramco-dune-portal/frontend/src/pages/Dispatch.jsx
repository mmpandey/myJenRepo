import React, { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import { MapContainer, TileLayer, GeoJSON, Marker, Popup, Polyline, Tooltip, useMap } from 'react-leaflet';
import L from 'leaflet';
import { api } from '../api';
import { useSearchParams } from 'react-router-dom';
import { useToast } from '../ToastContext';
import { useSite } from '../SiteContext';
import { ASSET_TYPES, RISK_COLORS, PRIORITY_COLORS, formatEta, timeAgo, TILE_URL, TILE_ATTRIBUTION } from '../constants';
import { makeAssetIcon, makeCrewIcon, forecastStyle, routeLineFromCoords } from '../mapUtils';
import { computeSlaStatus, computeRouteProgress, SLA_LABEL } from '../sla';

const POLL_MS = 10000;
const PLANNED_ROUTE_COLOR = '#4f46e5'; // matches the legend swatch

function FitToData({ bounds }) {
  const map = useMap();
  const fitted = useRef(false);
  useEffect(() => {
    if (bounds && !fitted.current) {
      map.fitBounds(bounds, { padding: [40, 40] });
      fitted.current = true;
    }
  }, [bounds, map]);
  return null;
}

export default function Dispatch() {
  const showToast = useToast();
  const [params, setParams] = useSearchParams();
  const { sites } = useSite();
  const siteFilter = params.get('site');
  const [assets, setAssets] = useState(null);
  const [polygons, setPolygons] = useState(null);
  const [crews, setCrews] = useState([]);
  const [activeOrders, setActiveOrders] = useState([]);
  const [trails, setTrails] = useState({}); // { [crewId]: [[lat,lon], ...] }
  const [typeFilters, setTypeFilters] = useState(() => new Set(ASSET_TYPES));
  const [showTrails, setShowTrails] = useState(true);

  const [selectedAsset, setSelectedAsset] = useState(null);
  const [suggestion, setSuggestion] = useState(null); // { recommended_priority, recommended_action, candidates }
  const [selectedCrewId, setSelectedCrewId] = useState(null);
  const [suggestionLoading, setSuggestionLoading] = useState(false);
  const [dispatching, setDispatching] = useState(false);

  const loadAll = useCallback(async () => {
    try {
      const [assetsData, polyData, crewsData, workOrdersData] = await Promise.all([
        api.getAssets(siteFilter),
        api.getPolygons(),
        api.getCrews(),
        api.getWorkOrders(siteFilter ? { site_id: siteFilter } : {}),
      ]);
      setAssets(assetsData);
      setPolygons(polyData);
      setCrews(crewsData);
      setActiveOrders(workOrdersData.filter((w) => ['DISPATCHED', 'IN_PROGRESS'].includes(w.status)));

      // Pull a fresh breadcrumb trail for every crew currently reporting a live
      // position, so the dispatcher can see where they've actually been, not
      // just where they are this instant.
      const liveCrews = crewsData.filter((c) => c.has_live_location);
      const trailResults = await Promise.all(
        liveCrews.map((c) => api.getCrewTrail(c.id, 25).catch(() => []))
      );
      const nextTrails = {};
      liveCrews.forEach((c, i) => {
        nextTrails[c.id] = trailResults[i].map((p) => [p.lat, p.lon]);
      });
      setTrails(nextTrails);
    } catch (err) {
      showToast(err.message, true);
    }
  }, [showToast, siteFilter]);

  useEffect(() => {
    setSelectedAsset(null);
    loadAll();
    const id = setInterval(loadAll, POLL_MS);
    return () => clearInterval(id);
  }, [loadAll]);

  // Everything the dispatcher needs in view: the site's assets plus every active job
  // (crew position, destination asset and the planned road route). Without the active
  // jobs a crew based far from the site, and most of its planned route, sat off-screen.
  const bounds = useMemo(() => {
    const pts = (assets?.features || []).map((f) => [f.geometry.coordinates[1], f.geometry.coordinates[0]]);
    activeOrders.forEach((wo) => {
      if (wo.crew_lat != null && wo.crew_lon != null) pts.push([Number(wo.crew_lat), Number(wo.crew_lon)]);
      if (wo.asset_lat != null && wo.asset_lon != null) pts.push([Number(wo.asset_lat), Number(wo.asset_lon)]);
      const line = wo.route_geometry?.coordinates;
      if (Array.isArray(line)) line.forEach((c) => pts.push([c[1], c[0]]));
    });
    return pts.length ? L.latLngBounds(pts) : null;
  }, [assets, activeOrders]);

  const mapRef = useRef(null);
  const fitToJobs = () => {
    if (bounds && mapRef.current) mapRef.current.fitBounds(bounds, { padding: [40, 40] });
  };

  // Live GPS status, so an empty "actual path" is explained rather than just blank.
  const liveCrewCount = crews.filter((c) => c.has_live_location).length;
  const pathCount = Object.values(trails).filter((pts) => pts.length > 1).length;

  const visibleFeatures = useMemo(() => {
    if (!assets?.features) return [];
    return assets.features.filter((f) => typeFilters.has(f.properties.asset_type));
  }, [assets, typeFilters]);

  const toggleType = (type) => {
    setTypeFilters((prev) => {
      const next = new Set(prev);
      if (next.has(type)) next.delete(type); else next.add(type);
      return next;
    });
  };

  const selectAsset = async (assetProps) => {
    setSelectedAsset(assetProps);
    setSuggestion(null);
    setSelectedCrewId(null);
    setSuggestionLoading(true);
    try {
      const data = await api.getNearestCrews(assetProps.id);
      setSuggestion(data);
      if (data.candidates.length) setSelectedCrewId(data.candidates[0].id);
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setSuggestionLoading(false);
    }
  };

  const selectedCrew = suggestion?.candidates.find((c) => c.id === selectedCrewId);

  const [prioritizeFastest, setPrioritizeFastest] = useState(false);

  const fastestCandidateId = useMemo(() => {
    if (!suggestion?.candidates.length) return null;
    return suggestion.candidates.reduce((best, c) => {
      const cDist = c.road_distance_km ?? c.straight_line_km;
      const bestDist = best.road_distance_km ?? best.straight_line_km;
      return cDist < bestDist ? c : best;
    }).id;
  }, [suggestion]);

  const orderedCandidates = useMemo(() => {
    if (!suggestion?.candidates.length) return [];
    if (!prioritizeFastest) return suggestion.candidates;
    return [...suggestion.candidates].sort((a, b) => {
      const aDist = a.road_distance_km ?? a.straight_line_km;
      const bDist = b.road_distance_km ?? b.straight_line_km;
      return aDist - bDist;
    });
  }, [suggestion, prioritizeFastest]);

  const previewLine = useMemo(() => {
    if (!selectedAsset || !selectedCrew) return null;
    const [lon, lat] = [selectedAsset.lon, selectedAsset.lat];
    return routeLineFromCoords(selectedCrew.lon, selectedCrew.lat, lon, lat);
  }, [selectedAsset, selectedCrew]);

  const handleDispatch = async () => {
    if (!selectedAsset) return;
    setDispatching(true);
    try {
      const wo = await api.createWorkOrder({
        asset_id: selectedAsset.id,
        crew_id: selectedCrewId || null,
      });
      showToast(
        wo.distance_km
          ? `Work order #${wo.id} created — ${wo.distance_km} km, ~${formatEta(wo.eta_minutes)} ETA`
          : `Work order #${wo.id} created for ${selectedAsset.name}`
      );
      setSelectedAsset(null);
      loadAll();
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setDispatching(false);
    }
  };

  return (
    <>
      <aside className="rail rail-left">
        <div className="panel-heading">Site</div>
        <select className="select-control" value={siteFilter || ''} onChange={(e) => setParams(e.target.value ? { site: e.target.value } : {})}>
          <option value="">All sites</option>
          {sites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>

        <div className="panel-heading">Show asset types</div>
        <div className="filter-list">
          {ASSET_TYPES.map((type) => (
            <label className="filter-row" key={type}>
              <input type="checkbox" checked={typeFilters.has(type)} onChange={() => toggleType(type)} />
              {type.charAt(0) + type.slice(1).toLowerCase()}
            </label>
          ))}
        </div>

        <div className="panel-heading">Forecast risk legend</div>
        <div className="legend">
          <div className="legend-row"><span className="legend-swatch" style={{ background: RISK_COLORS.HIGH }} /> High encroachment risk</div>
          <div className="legend-row"><span className="legend-swatch" style={{ background: RISK_COLORS.MEDIUM }} /> Medium encroachment risk</div>
          <div className="legend-row"><span className="legend-swatch" style={{ background: RISK_COLORS.LOW }} /> Low / no forecast risk</div>
        </div>

        <div className="panel-heading">Crew vehicles</div>
        <div className="legend">
          <div className="legend-row"><span className="legend-swatch" style={{ background: '#0e9f9a' }} /> Available</div>
          <div className="legend-row"><span className="legend-swatch" style={{ background: '#d4a24e' }} /> Dispatched (en route)</div>
          <div className="legend-row"><span className="legend-swatch" style={{ background: '#5b6479' }} /> Off duty</div>
        </div>

        <div className="panel-heading">Route lines</div>
        <div className="legend">
          <div className="legend-row"><span className="legend-line legend-line-dashed" /> Planned route</div>
          <div className="legend-row"><span className="legend-line legend-line-solid" /> Actual path driven (live GPS)</div>
        </div>

        <label className="filter-row">
          <input type="checkbox" checked={showTrails} onChange={(e) => setShowTrails(e.target.checked)} />
          Show live GPS trails
        </label>
        {showTrails && pathCount === 0 && (
          <div className="wo-detail-faint">
            {liveCrewCount
              ? 'Live GPS received. The actual path appears after a second position update.'
              : 'No crew is sharing live GPS yet. The actual path appears once a crew phone shares its location.'}
          </div>
        )}

        <div className="panel-heading">Active jobs on map</div>
        {activeOrders.length > 0 && (
          <button type="button" className="btn btn-ghost btn-block" style={{ marginBottom: 8 }} onClick={fitToJobs}>Fit map to jobs</button>
        )}
        {activeOrders.length ? (
          <div className="active-routes-list">
            {activeOrders.map((wo) => {
              const sla = computeSlaStatus(wo);
              const progress = computeRouteProgress(wo);
              return (
                <div className="active-route-item-card" key={wo.id}>
                  <div className="active-route-item">
                    <span className="legend-swatch" style={{ background: PRIORITY_COLORS[wo.priority] }} />
                    <span>{wo.crew_name || 'Unassigned'} → {wo.asset_name}</span>
                  </div>
                  {progress && (
                    <div className="mini-progress-track">
                      <div className="mini-progress-fill" style={{ width: `${progress.pct}%` }} />
                    </div>
                  )}
                  {progress && <div className="wo-detail-faint">{progress.remainingKm} km remaining (approx)</div>}
                  {!wo.route_geometry && <div className="wo-detail-faint">Road route unavailable: straight line shown</div>}
                  {sla && sla.phase === 'pending' && (
                    <div className={`sla-chip sla-${sla.level}`}>{SLA_LABEL[sla.level]}</div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="wo-detail-faint">No active jobs right now.</div>
        )}
      </aside>

      <main className="map-stage">
        <MapContainer ref={mapRef} center={[26.31, 49.99]} zoom={12} scrollWheelZoom>
          <TileLayer url={TILE_URL} attribution={TILE_ATTRIBUTION} />

          {polygons && <GeoJSON data={polygons} style={forecastStyle} />}

          {visibleFeatures.map((f) => {
            const [lon, lat] = f.geometry.coordinates;
            const p = f.properties;
            return (
              <Marker
                key={`asset-${p.id}`}
                position={[lat, lon]}
                icon={makeAssetIcon(p.recommended_priority)}
                eventHandlers={{ click: () => selectAsset({ ...p, lon, lat }) }}
              >
                <Popup>
                  <div className="popup-title">{p.name}</div>
                  <div className="popup-row">Forecast risk: {p.risk_level}</div>
                  <div className="popup-row">Recommended priority: {p.recommended_priority}</div>
                </Popup>
              </Marker>
            );
          })}

          {/* Planned route: the road route computed at dispatch time (dashed,
              muted) — what the crew was told to take. */}
          {activeOrders.map((wo) => (
            wo.route_geometry ? (
              <React.Fragment key={`route-${wo.id}`}>
                <GeoJSON data={wo.route_geometry} style={{ color: '#ffffff', weight: 8, opacity: 0.85 }} />
                <GeoJSON data={wo.route_geometry} style={{ color: PLANNED_ROUTE_COLOR, weight: 4, opacity: 0.95, dashArray: '10 8' }}>
                  <Tooltip sticky>Planned: {wo.crew_name} → {wo.asset_name} ({wo.priority})</Tooltip>
                </GeoJSON>
              </React.Fragment>
            ) : wo.crew_lon != null && wo.asset_lon != null ? (
              <React.Fragment key={`route-preview-${wo.id}`}>
                <Polyline positions={routeLineFromCoords(wo.crew_lon, wo.crew_lat, wo.asset_lon, wo.asset_lat)} pathOptions={{ color: '#ffffff', weight: 8, opacity: 0.85 }} />
                <Polyline
                  positions={routeLineFromCoords(wo.crew_lon, wo.crew_lat, wo.asset_lon, wo.asset_lat)}
                  pathOptions={{ color: PLANNED_ROUTE_COLOR, weight: 4, dashArray: '10 8', opacity: 0.95 }}
                >
                  <Tooltip sticky>Planned: {wo.crew_name} → {wo.asset_name} (road route unavailable, straight line shown)</Tooltip>
                </Polyline>
              </React.Fragment>
            ) : null
          ))}

          {/* Actual path taken: the crew's real GPS breadcrumb trail (solid,
              bright) — this is genuinely where they drove, not a plan. */}
          {showTrails && Object.entries(trails).map(([crewId, points]) => (
            points.length > 1 && (
              <React.Fragment key={`trail-${crewId}`}>
                <Polyline positions={points} pathOptions={{ color: '#ffffff', weight: 8, opacity: 0.85 }} />
                <Polyline positions={points} pathOptions={{ color: '#0e9f9a', weight: 4.5, opacity: 1 }}>
                  <Tooltip sticky>Actual path driven (live GPS)</Tooltip>
                </Polyline>
              </React.Fragment>
            )
          ))}

          {crews.map((c) => (
            c.lon != null && (
              <Marker key={`crew-${c.id}`} position={[c.lat, c.lon]} icon={makeCrewIcon(c.status, c.live_heading)}>
                <Popup>
                  <div className="popup-title">{c.name}</div>
                  <div className="popup-row">{c.specialty} · {c.status}</div>
                  <div className="popup-row">Engine: {c.engine_id}</div>
                  <div className="popup-row">
                    {c.has_live_location ? `📍 Live · ${timeAgo(c.last_ping_at)}` : '📍 Base location (no live GPS)'}
                  </div>
                  <div className="popup-row">{c.open_work_orders} open work order(s)</div>
                </Popup>
              </Marker>
            )
          ))}

          {previewLine && (
            <Polyline positions={previewLine} pathOptions={{ color: '#ffffff', weight: 2, dashArray: '4 6', opacity: 0.6 }} />
          )}

          <FitToData key={siteFilter || 'all'} bounds={bounds} />
        </MapContainer>
      </main>

      <aside className="rail rail-right">
        <div className="tab-body" style={{ paddingTop: 16 }}>
          {!selectedAsset ? (
            <div className="empty-state">
              <span>No asset selected.</span>
              <span>Click a marker on the map. The nearest available crew and shortest route will be suggested automatically.</span>
            </div>
          ) : (
            <div className="asset-card">
              <div className="asset-card-title">{selectedAsset.name}</div>
              <div><span className={`badge badge-${(suggestion?.recommended_priority || selectedAsset.recommended_priority).toLowerCase()}`}>
                {suggestion?.recommended_priority || selectedAsset.recommended_priority} priority
              </span></div>

              <div className="field-label">Recommended action</div>
              <div className="recommendation-box">{suggestion?.recommended_action || selectedAsset.recommended_action}</div>

              <div className="panel-heading">Nearest available crews</div>
              <div className="ranking-explainer">
                Ranked by matching specialty first (a crew needs the right skill to do the job correctly), then by real driving distance. Toggle below to sort by arrival time only.
              </div>
              {suggestion && suggestion.routing_source === 'straight_line' && suggestion.candidates.length > 0 && (
                <div className="routing-fallback-note">
                  Live road-routing service unavailable — ranked by straight-line distance instead.
                </div>
              )}
              {suggestion?.candidates.length > 1 && (
                <label className="filter-row sort-toggle">
                  <input
                    type="checkbox"
                    checked={prioritizeFastest}
                    onChange={(e) => setPrioritizeFastest(e.target.checked)}
                  />
                  Sort by fastest arrival, ignore specialty
                </label>
              )}
              {suggestionLoading ? (
                <div className="empty-state"><span>Finding nearest available crew…</span></div>
              ) : orderedCandidates.length ? (
                <div className="crew-candidate-list">
                  {orderedCandidates.map((c) => {
                    const isSpecialtyMatch = c.specialty === suggestion.suggested_crew_type;
                    const isFastest = c.id === fastestCandidateId;
                    return (
                      <label className={`crew-candidate${selectedCrewId === c.id ? ' selected' : ''}`} key={c.id}>
                        <input
                          type="radio"
                          name="crew-candidate"
                          checked={selectedCrewId === c.id}
                          onChange={() => setSelectedCrewId(c.id)}
                        />
                        <div className="crew-candidate-body">
                          <div className="crew-candidate-top">
                            <span className="crew-candidate-name">{c.name}</span>
                            {isSpecialtyMatch && <span className="badge badge-low">Right specialty</span>}
                            {c.in_scheduling_team && <span className="badge badge-team">In scheduling team</span>}
                            {isFastest && <span className="badge badge-medium">Fastest arrival</span>}
                          </div>
                          <div className="wo-detail">
                            {c.specialty} · {c.road_distance_km != null
                              ? `${c.road_distance_km} km by road (~${c.road_eta_minutes} min)`
                              : `${c.straight_line_km} km (straight-line est.)`} · {c.open_work_orders} active job(s)
                          </div>
                          {(c.equipment || []).length > 0 && (
                            <div className="eq-inline">
                              {c.equipment.map((u) => <span key={u.id} className={`eq-chip eq-${u.equipment_class.toLowerCase()}`}><b>{u.equipment_class === 'HEAVY' ? 'H' : 'L'}</b> {u.equipment_type}</span>)}
                            </div>
                          )}
                          <div className="wo-detail wo-detail-faint">
                            Engine {c.engine_id} · {c.has_live_location ? `📍 live, ${timeAgo(c.last_ping_at)}` : '📍 base location'}
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              ) : (
                <div className="empty-state"><span>No available crews right now — all are dispatched or off duty.</span></div>
              )}

              <button
                className="btn btn-primary btn-block"
                onClick={handleDispatch}
                disabled={dispatching || !suggestion?.candidates.length}
              >
                {dispatching ? 'Dispatching…' : 'Dispatch nearest crew'}
              </button>
              <button className="btn btn-ghost btn-block" onClick={() => setSelectedAsset(null)}>
                Clear selection
              </button>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
