import React, { useEffect, useState } from 'react';
import { api } from '../api';
import { CREW_SESSION_KEY } from '../constants';

export default function CrewLogin({ onLoggedIn }) {
  const [directory, setDirectory] = useState(null);
  const [selected, setSelected] = useState(null);
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.getCrewDirectory().then(setDirectory).catch(() => setDirectory([]));
  }, []);

  const handlePinDigit = (digit) => {
    if (pin.length >= 4) return;
    setError('');
    setPin(pin + digit);
  };

  const handleBackspace = () => setPin(pin.slice(0, -1));

  const handleSubmit = async () => {
    setBusy(true);
    setError('');
    try {
      const crew = await api.crewLogin(selected.id, pin);
      localStorage.setItem(CREW_SESSION_KEY, JSON.stringify(crew));
      onLoggedIn(crew);
    } catch (err) {
      setError(err.message);
      setPin('');
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (pin.length === 4 && selected) handleSubmit();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pin]);

  if (!directory) {
    return <div className="mobile-shell"><div className="empty-state"><span>Loading crew list…</span></div></div>;
  }

  if (!selected) {
    return (
      <div className="mobile-shell">
        <header className="mobile-header">
          <div className="brand-mark">DDX</div>
          <div>
            <div className="mobile-crew-name">Dune Dynamix</div>
            <div className="mobile-crew-meta">Select your crew to continue</div>
          </div>
        </header>
        <div className="mobile-body">
          <div className="mobile-section-title">Who are you?</div>
          <div className="crew-picker-list">
            {directory.map((c) => (
              <button key={c.id} className="crew-picker-item" onClick={() => setSelected(c)}>
                <span className="crew-picker-name">{c.name}</span>
                <span className="crew-picker-specialty">{c.specialty}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-shell">
      <header className="mobile-header">
        <div className="brand-mark">DDX</div>
        <div>
          <div className="mobile-crew-name">{selected.name}</div>
          <div className="mobile-crew-meta">Enter your 4-digit PIN</div>
        </div>
      </header>
      <div className="mobile-body">
        <div className="pin-dots">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className={`pin-dot${i < pin.length ? ' filled' : ''}`} />
          ))}
        </div>
        {error && <div className="pin-error">{error}</div>}

        <div className="pin-pad">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'].map((key, i) => {
            if (key === '') return <div key={i} />;
            if (key === '⌫') {
              return (
                <button key={i} className="pin-key pin-key-action" onClick={handleBackspace} disabled={busy}>⌫</button>
              );
            }
            return (
              <button key={i} className="pin-key" onClick={() => handlePinDigit(key)} disabled={busy || pin.length >= 4}>
                {key}
              </button>
            );
          })}
        </div>

        <button className="link-btn" onClick={() => { setSelected(null); setPin(''); setError(''); }}>
          ← Not {selected.name}? Go back
        </button>
      </div>
    </div>
  );
}
