import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, CircleMarker, Popup, GeoJSON, Polyline, Polygon, Tooltip, useMap } from 'react-leaflet';
import L from 'leaflet';
import turfBbox from '@turf/bbox';
import { featureCollection, point } from '@turf/helpers';
import { api } from '../api';
import { useToast } from '../ToastContext';
import { useSite } from '../SiteContext';
import { TILE_URL, TILE_ATTRIBUTION } from '../constants';

// ---------------------------------------------------------------------------
// Sand Accumulation Prediction — Prediction Module Enhancement ("Final Prompt").
// Backed by the external AI Prediction Backend (POST /api/site-dashboard/production
// on the backend, see backend/sandSiteDashboard.js), with prediction.json as the
// automatic fallback when that backend is unreachable — no UI change either way.
// One run covers every site at once; search/select a site to drill into its
// current/predicted zone, dune movement, and trend.
//
// IMPORTANT (spec requirement 11): the API's per-site "schedule" object is
// never read anywhere in this file or in backend/server.js — Scheduling Team /
// Crews / Dispatch / Work Orders / Equipment keep their existing, independent
// logic untouched. The "Scheduling team" card below is the SAME feature that
// existed before this integration, operating on the original single-site
// sand_predictions flow via the legacy site picker — it does not read AI data.
// ---------------------------------------------------------------------------

const RISK = {
  LOW: { color: '#2f9e73', label: 'Low' },
  MODERATE: { color: '#e0a21b', label: 'Moderate' },
  HIGH: { color: '#dc3545', label: 'High' },
  UNAVAILABLE: { color: '#8a94ad', label: 'Unavailable' },
};
const RISK_RANK = { HIGH: 3, MODERATE: 2, LOW: 1, UNAVAILABLE: 0 };
const normalizeRisk = (r) => {
  const k = String(r || '').toUpperCase();
  return RISK[k] ? k : 'UNAVAILABLE';
};
const riskRank = (s) => RISK_RANK[normalizeRisk(s.risk_level)] ?? 0;

const todayISO = () => new Date().toISOString().slice(0, 10);
const addDaysISO = (iso, d) => new Date(new Date(iso).getTime() + d * 86400000).toISOString().slice(0, 10);
const fmt = (v, d = 2, suffix = '') => (v == null || Number.isNaN(Number(v)) ? '—' : `${Number(v).toFixed(d)}${suffix}`);
const fmtInt = (v) => (v == null ? '—' : Math.round(Number(v)).toLocaleString());

function titleWords(key) {
  return key.split('_').map((w) => (w === 'and' ? '&' : w[0].toUpperCase() + w.slice(1))).join(' ');
}
// e.g. mean_wind_speed_ms -> "Mean Wind Speed (m/s)"
function envLabel(key) {
  const unitMap = { ms: 'm/s', deg: '°', c: '°C', pct: '%', km2: 'km²' };
  const parts = key.split('_');
  const last = parts[parts.length - 1];
  const unit = unitMap[last];
  const words = (unit ? parts.slice(0, -1) : parts).join('_');
  return unit ? `${titleWords(words)} (${unit})` : titleWords(key);
}

// Destination point from a start lat/lon, a bearing (deg, 0=N clockwise) and a distance (km).
// Flat-earth approximation — plenty accurate for a short visual arrow, not meant for navigation.
function destinationPoint(lat, lon, bearingDeg, distanceKm) {
  const bearing = (bearingDeg * Math.PI) / 180;
  const dLat = (distanceKm / 111.32) * Math.cos(bearing);
  const dLon = (distanceKm / (111.32 * Math.cos((lat * Math.PI) / 180) || 1)) * Math.sin(bearing);
  return [lat + dLat, lon + dLon];
}

// Dune-movement vector: shaft + arrowhead. intensity_pct drives length, thickness and
// transparency (color intensity), per spec section 9.
function DuneMovementArrow({ lat, lon, directionDeg, intensityPct }) {
  if (lat == null || lon == null || directionDeg == null) return null;
  const pct = Math.max(0, Math.min(100, Number(intensityPct) || 0));
  const lengthKm = 0.22 + (pct / 100) * 0.85;
  const weight = 2 + (pct / 100) * 6;
  const opacity = 0.4 + (pct / 100) * 0.6;
  const color = '#d13438';
  const tip = destinationPoint(lat, lon, directionDeg, lengthKm);
  const left = destinationPoint(tip[0], tip[1], directionDeg + 150, lengthKm * 0.22);
  const right = destinationPoint(tip[0], tip[1], directionDeg - 150, lengthKm * 0.22);
  return (
    <>
      <Polyline positions={[[lat, lon], tip]} pathOptions={{ color, weight, opacity }} />
      <Polygon positions={[tip, left, right]} pathOptions={{ color, fillColor: color, fillOpacity: opacity, weight: 0 }}>
        <Tooltip direction="top" offset={[0, -4]} opacity={1}>
          <div className="popup-title">Dune Movement</div>
          <div className="popup-row">Direction: {directionDeg.toFixed(1)}&deg;</div>
          <div className="popup-row">Intensity: {pct.toFixed(1)}%</div>
        </Tooltip>
      </Polygon>
    </>
  );
}

// Hands the Leaflet map instance up to the page so it can be zoomed programmatically.
function MapHandle({ onMap }) {
  const map = useMap();
  useEffect(() => { onMap(map); }, [map, onMap]);
  return null;
}

function SiteMarker({ site, selected, onSelect }) {
  if (site.lat == null || site.lon == null) return null;
  const risk = RISK[normalizeRisk(site.risk_level)];
  return (
    <CircleMarker
      center={[site.lat, site.lon]}
      radius={selected ? 13 : 10}
      pathOptions={{ color: selected ? '#232F3E' : '#ffffff', weight: selected ? 3 : 2.5, fillColor: risk.color, fillOpacity: 0.95 }}
      eventHandlers={{ click: () => onSelect(site.site_name) }}
    >
      <Popup>
        <div className="popup-title">{site.site_name}</div>
        <div className="popup-row">Lat: {site.lat.toFixed(4)}, Lon: {site.lon.toFixed(4)}</div>
        <div className="popup-row">Predicted accumulation</div>
        <div className="popup-big">{fmt(site.predicted_accumulation_m, 3, ' m')}</div>
        <div className="popup-row">{risk.label} risk &middot; {fmt(site.confidence_pct, 0, '%')} confidence</div>
      </Popup>
    </CircleMarker>
  );
}

// Site dropdown (spec section 7). A plain native <select> rather than a custom
// combobox: it's compact (saves UI space), every browser already gives it
// type-ahead (typing jumps to a matching option) and keyboard navigation for
// free, and it scales to hundreds of sites with no extra code or dependency.
function SiteSearchSelect({ sites, value, onChange }) {
  return (
    <select
      className="pred-select"
      value={value || ''}
      onChange={(e) => onChange(e.target.value || null)}
      disabled={!sites.length}
      aria-label="Select site"
    >
      {!sites.length && <option value="">No sites yet — run a prediction</option>}
      {sites.map((s) => {
        const risk = RISK[normalizeRisk(s.risk_level)];
        return <option key={s.site_name} value={s.site_name}>{s.site_name} &middot; {risk.label}</option>;
      })}
    </select>
  );
}

function AvailableModels({ run }) {
  const sand = run.sand_model || {};
  const env = run.environmental_model || {};
  const envEntries = Object.entries(env).filter(([k, v]) => k !== 'type' && typeof v !== 'object');
  return (
    <section className="pred-card">
      <h3 className="pred-card-title"><span className="pred-dot" /> Available Models</h3>
      <div className="model-card">
        <div className="model-card-head"><b>Sand Model</b><span className="pred-stat-label">{sand.type || '—'}</span></div>
        <p className="model-card-desc">{sand.description || '—'}</p>
      </div>
      <div className="model-card">
        <div className="model-card-head"><b>Environmental Model</b><span className="pred-stat-label">{env.type || '—'}</span></div>
        <div className="env-grid">
          {envEntries.map(([k, v]) => (
            <div key={k} className="pred-stat">
              <div className="pred-stat-label">{envLabel(k)}</div>
              <div className="pred-stat-val">{typeof v === 'number' ? v.toFixed(2) : String(v)}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Predicted Accumulation Trend (spec section 10). Consumes site.accumulation_trend
// ([{date, value}, ...]) directly when the API provides it; until then, synthesizes a
// 2-point start->end trend from this run's own numbers so the chart is never empty —
// swapping in a full series later needs no UI change (same shape, just more points).
function TrendChart({ site, run }) {
  const hasApiSeries = Array.isArray(site.accumulation_trend) && site.accumulation_trend.length >= 2;
  const series = useMemo(() => {
    if (hasApiSeries) return site.accumulation_trend.map((p) => ({ date: p.date, value: Number(p.value) }));
    const baseline = (site.predicted_accumulation_m != null && site.net_accumulation_m != null)
      ? site.predicted_accumulation_m - site.net_accumulation_m : 0;
    return [
      { date: run.start_date, value: baseline },
      { date: run.end_date, value: site.predicted_accumulation_m ?? baseline },
    ];
  }, [site, run, hasApiSeries]);

  const W = 820, H = 190, PL = 48, PR = 14, PT = 12, PB = 26;
  const vals = series.map((p) => p.value);
  const spread = Math.max(...vals) - Math.min(...vals);
  const pad = Math.max(0.01, spread * 0.2);
  const lo = Math.min(...vals) - pad;
  const hi = Math.max(...vals) + pad;
  const x = (i) => PL + (series.length > 1 ? (i / (series.length - 1)) * (W - PL - PR) : (W - PL - PR) / 2);
  const y = (v) => PT + (1 - (v - lo) / (hi - lo || 1)) * (H - PT - PB);
  const line = series.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
  const ticks = [0, 0.5, 1].map((f) => lo + f * (hi - lo));

  return (
    <section className="pred-card">
      <div className="pred-card-head">
        <h3 className="pred-card-title"><span className="pred-dot" /> Predicted accumulation trend</h3>
        {!hasApiSeries && <span className="pred-stat-label">start → end (full daily series not yet returned by the API)</span>}
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="trend-svg" role="img" aria-label={`Predicted sand accumulation for ${site.site_name}`}>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={PL} x2={W - PR} y1={y(t)} y2={y(t)} stroke="#e8ecf5" />
            <text x={PL - 6} y={y(t) + 3} textAnchor="end" fontSize="10" fill="#8a94ad">{t.toFixed(3)}</text>
          </g>
        ))}
        <path d={line} fill="none" stroke="#4f46e5" strokeWidth="2.4" />
        {series.map((p, i) => <circle key={`${p.date}-${i}`} cx={x(i)} cy={y(p.value)} r="3.2" fill="#4f46e5" />)}
        {series.map((p, i) => <text key={`${p.date}-lbl-${i}`} x={x(i)} y={H - 8} textAnchor="middle" fontSize="10" fill="#8a94ad">{p.date.slice(5)}</text>)}
      </svg>
    </section>
  );
}

const KPI_ICON = { MAE: '▤', RMSE: '≈', 'R²': '▲', BIAS: '±' };

// Scheduling Team — spec section 11: must NOT use anything from the prediction API.
// This is the same feature that existed before this integration (people / heavy /
// light equipment, sized by the original single-site sand_predictions engine).
// It has no site picker, date range, or "Run Prediction" button of its own — it
// simply follows whichever site is selected above, so the whole page always shows
// one consistent site. Every top-level Run Prediction click automatically
// (re)computes this number for every site returned by the AI backend via the
// original, untouched prediction.js engine (see syncLegacySiteAndAsset() in
// server.js) — this card only displays the result, it never calls the AI API.
function LegacySchedulingTeam({ selectedSiteName }) {
  const navigate = useNavigate();
  const { sites: masterSites, setSiteId } = useSite();
  const [prediction, setPrediction] = useState(null);

  const legacySite = masterSites.find((s) => s.name === selectedSiteName) || null;
  const siteId = legacySite?.id ?? null;

  // Keep the shared site context pointed at the same site, so Dispatch / Work Orders /
  // Crews links elsewhere stay consistent with what's selected on this page.
  useEffect(() => { if (siteId) setSiteId(siteId); }, [siteId, setSiteId]);

  const load = useCallback(async () => {
    if (!siteId) { setPrediction(null); return; }
    try {
      setPrediction(await api.getLatestPrediction(siteId));
    } catch {
      // secondary widget — stay quiet on load failure, the main page already surfaces connectivity errors
    }
  }, [siteId]);
  useEffect(() => { load(); }, [load]);

  const res = prediction?.resources;

  return (
    <section className="pred-card">
      <h3 className="pred-card-title"><span className="pred-dot" /> Scheduling team</h3>
      <div className="pred-stat-label" style={{ marginBottom: 8 }}>Existing crew / equipment planning &mdash; refreshed automatically by Run Prediction above</div>

      {!selectedSiteName && <div className="pred-stat-label">Select a site above to see its scheduling requirement.</div>}
      {selectedSiteName && !legacySite && <div className="pred-stat-label">Syncing&hellip; press Run Prediction above if this doesn't update.</div>}

      <div className="team-people pred-gap-top"><span className="team-icon">👥</span><b>{res ? `${res.people} People` : '— People'}</b></div>
      <div className="pred-two">
        <div className="team-tile"><div className="team-num">{res ? res.heavy_units : '–'}<small> {res?.heavy_units === 1 ? 'Unit' : 'Units'}</small></div><div className="pred-stat-label">Heavy equipment</div></div>
        <div className="team-tile"><div className="team-num">{res ? res.light_units : '–'}<small> {res?.light_units === 1 ? 'Unit' : 'Units'}</small></div><div className="pred-stat-label">Light equipment</div></div>
      </div>
      <button className="btn btn-primary btn-block pred-gap-top" disabled={!prediction} onClick={() => navigate(`/schedule?prediction=${prediction.id}`)}>
        Schedule team
      </button>
      <div className="team-links" aria-label="Go to">
        <Link to="/">Dashboard</Link>
        <Link to={siteId ? `/dispatch?site=${siteId}` : '/dispatch'}>Dispatch</Link>
        <Link to={siteId ? `/work-orders?site=${siteId}` : '/work-orders'}>Work orders</Link>
        <Link to="/crews">Crews</Link>
      </div>
    </section>
  );
}

export default function Prediction() {
  const showToast = useToast();
  const { reloadSites } = useSite();

  const [start, setStart] = useState(todayISO());
  const end = useMemo(() => addDaysISO(start, 7), [start]);

  const [run, setRun] = useState(null);
  const [selectedSite, setSelectedSite] = useState(null);
  const [running, setRunning] = useState(false);
  const [loading, setLoading] = useState(true);
  const [map, setMap] = useState(null);

  const pickDefaultSite = (r) => {
    if (!r?.sites?.length) return;
    setSelectedSite([...r.sites].sort((a, b) => riskRank(b) - riskRank(a))[0].site_name);
  };

  const loadLatest = useCallback(async () => {
    setLoading(true);
    try {
      const latest = await api.getLatestPredictionRun();
      setRun(latest);
      pickDefaultSite(latest);
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setLoading(false);
    }
  }, [showToast]);
  useEffect(() => { loadLatest(); }, [loadLatest]);

  const runPrediction = async () => {
    setRunning(true);
    try {
      const r = await api.runSiteDashboardPrediction(start, end);
      setRun(r);
      pickDefaultSite(r);
      // The backend also upserted/refreshed the legacy sites this run touched (and their
      // Scheduling Team numbers) — reload the shared site list so that's visible right away.
      reloadSites();
      showToast(`Prediction complete — ${r.sites.length} site${r.sites.length === 1 ? '' : 's'} (source: ${r.source === 'mock' ? 'mock data' : 'AI backend'})`);
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setRunning(false);
    }
  };

  const sites = run?.sites ?? [];
  const site = sites.find((s) => s.site_name === selectedSite) || null;

  // Zoom the map to whichever site is selected (search dropdown, list click, or marker click) — spec section 7.
  // Skipped right after a brand-new run: the MapContainer below is keyed by run.run_id, so a new run
  // remounts it entirely (a fresh Leaflet instance, already framed by its own `bounds` prop) — calling
  // flyTo() on the very same render can race that teardown/mount and throw inside Leaflet's animation
  // code (reading a DOM pane that no longer exists). The try/catch is a second, unconditional safety net:
  // a failed flyTo here is harmless (the map is already reasonably framed either way), a crashed page isn't.
  const lastFlyToRunId = useRef(null);
  useEffect(() => {
    const isNewRun = lastFlyToRunId.current !== (run?.run_id ?? null);
    lastFlyToRunId.current = run?.run_id ?? null;
    if (isNewRun || !map || !map._loaded || !site || site.lat == null || site.lon == null) return;
    try {
      map.flyTo([site.lat, site.lon], Math.max(map.getZoom(), 13), { duration: 0.6 });
    } catch {
      // see comment above — never let a map-animation race crash the page
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map, site?.site_name, run?.run_id]);

  const bounds = useMemo(() => {
    const pts = sites.filter((s) => s.lat != null && s.lon != null).map((s) => point([s.lon, s.lat]));
    if (!pts.length) return null;
    const [minX, minY, maxX, maxY] = turfBbox(featureCollection(pts));
    return L.latLngBounds([[minY, minX], [maxY, maxX]]);
  }, [sites]);
  const reset = () => { if (map && bounds) map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 }); };

  const metrics = run?.model_metrics || {};
  const kpis = [['MAE', metrics.MAE], ['RMSE', metrics.RMSE], ['R²', metrics.R2], ['BIAS', metrics.BIAS]];

  return (
    <div className="pred-page">
      <section className="pred-bar">
        <div className="pred-window">
          <span className="pred-bar-label">Prediction window (always 7 days)</span>
          <div className="pred-window-row">
            <input type="date" className="pred-date" value={start} onChange={(e) => setStart(e.target.value)} aria-label="Window start" />
            <span className="pred-to">&rarr;</span>
            <input type="date" className="pred-date" value={end} disabled aria-label="Window end (auto, start + 7 days)" />
            <button className="btn btn-primary pred-run" onClick={runPrediction} disabled={running}>
              {running ? 'Running…' : 'Run Prediction'}
            </button>
          </div>
        </div>

        <label className="pred-site">
          <span className="pred-bar-label">Site</span>
          <SiteSearchSelect sites={sites} value={selectedSite} onChange={setSelectedSite} />
        </label>
      </section>

      {run && (
        <div className="pred-subhead">
          Run #{run.run_id} &middot; {run.start_date} &rarr; {run.end_date} &middot; source: {run.source === 'mock' ? 'Mock data (prediction.json)' : 'AI Prediction Backend'}
        </div>
      )}

      <div className="pred-grid">
        <div className="pred-main">
          <section className="pred-map">
            <MapContainer
              center={site ? [site.lat, site.lon] : sites[0] ? [sites[0].lat, sites[0].lon] : [26.31, 49.99]}
              bounds={bounds || undefined}
              boundsOptions={{ padding: [50, 50], maxZoom: 14 }}
              zoom={12}
              scrollWheelZoom
              key={run?.run_id || 'none'}
            >
              <TileLayer url={TILE_URL} attribution={TILE_ATTRIBUTION} />
              <MapHandle onMap={setMap} />
              {sites.map((s) => <SiteMarker key={s.site_name} site={s} selected={s.site_name === selectedSite} onSelect={setSelectedSite} />)}
              {site?.current_zone && (
                <GeoJSON key={`cur-${site.site_name}`} data={site.current_zone} style={{ color: '#4f46e5', weight: 2, dashArray: '6 6', fillOpacity: 0.06 }} />
              )}
              {site?.predicted_zone && (
                <GeoJSON key={`prz-${site.site_name}`} data={site.predicted_zone} style={{ color: '#e8742a', weight: 2, fillOpacity: 0.14 }} />
              )}
              {site && <DuneMovementArrow lat={site.lat} lon={site.lon} directionDeg={site.dune_direction_deg} intensityPct={site.dune_intensity_pct} />}
            </MapContainer>
            <button className="map-btn" onClick={reset}>Reset to overview</button>
            <div className="map-legend">
              <div className="map-legend-title">Site risk</div>
              {Object.entries(RISK).map(([k, v]) => <div key={k}><i style={{ background: v.color }} />{v.label}</div>)}
              <div className="map-legend-sep"><i className="lg-dash" />Current zone</div>
              <div><i className="lg-box" />Predicted zone</div>
            </div>
            {!loading && !sites.length && <div className="map-empty">No prediction yet. Choose a start date and press Run Prediction.</div>}
          </section>

          {run && <AvailableModels run={run} />}
          {site && <TrendChart site={site} run={run} />}
        </div>

        <aside className="pred-side">
          <section className="pred-card">
            <h3 className="pred-card-title"><span className="pred-dot" /> Risk summary</h3>
            <div className="risk-tiles risk-tiles-4">
              {['LOW', 'MODERATE', 'HIGH', 'UNAVAILABLE'].map((k) => (
                <div key={k} className={`risk-tile risk-tile-${k.toLowerCase()}`}>
                  <div className="risk-tile-num">{run ? (run.risk_summary?.[k.toLowerCase()] ?? 0) : '–'}</div>
                  <div className="risk-tile-label">{RISK[k].label}</div>
                </div>
              ))}
            </div>
          </section>

          {site && (
            <section className="pred-card">
              <div className="pred-card-head">
                <h3 className="pred-card-title"><span className="pred-dot" /> {site.site_name}</h3>
                <span className={`pred-chip pred-chip-${normalizeRisk(site.risk_level).toLowerCase()}`}>{RISK[normalizeRisk(site.risk_level)].label} Risk</span>
              </div>

              <div className="pred-two">
                <div className="pred-stat"><div className="pred-stat-label">Coordinates</div><div className="pred-stat-val">{site.lat != null ? `${site.lat.toFixed(4)}° N, ${site.lon.toFixed(4)}° E` : '—'}</div></div>
                <div className="pred-stat"><div className="pred-stat-label">Total area</div><div className="pred-stat-val">{fmt(site.total_area_km2, 4, ' km²')}</div></div>
              </div>

              <div className="pred-stat-label pred-gap">Prediction</div>
              <div className="pred-depth">
                <div><div className="pred-depth-num">{fmt(site.predicted_accumulation_m, 3)}<small> m</small></div><div className="pred-stat-label">Predicted accum.</div></div>
                <div className="pred-arrow">&rarr;</div>
                <div><div className="pred-depth-num">{fmt(site.net_accumulation_m, 3)}<small> m</small></div><div className="pred-stat-label">Net accum.</div></div>
              </div>
              <div className="pred-two pred-gap-top">
                <div className="pred-stat"><div className="pred-stat-label">Sand deposition</div><div className="pred-stat-val">{fmtInt(site.sand_deposition_m3)} m&sup3;</div></div>
                <div className="pred-stat"><div className="pred-stat-label">Deposition range</div><div className="pred-stat-val">{fmtInt(site.sand_deposition_low_m3)}&ndash;{fmtInt(site.sand_deposition_high_m3)} m&sup3;</div></div>
              </div>
              <div className="conf-head pred-gap-top"><span>Confidence</span><b>{fmt(site.confidence_pct, 1, '%')}</b></div>
              <div className="conf-track"><div className="conf-marker" style={{ left: `${site.confidence_pct ?? 50}%` }} /></div>

              <div className="pred-stat-label pred-gap">Dune movement</div>
              <div className="pred-two">
                <div className="pred-stat"><div className="pred-stat-label">Direction</div><div className="pred-stat-val">{fmt(site.dune_direction_deg, 1, '°')}</div></div>
                <div className="pred-stat"><div className="pred-stat-label">Intensity</div><div className="pred-stat-val">{fmt(site.dune_intensity_pct, 1, '%')}</div></div>
              </div>
            </section>
          )}

          <LegacySchedulingTeam selectedSiteName={selectedSite} />
        </aside>
      </div>

      {run && (
        <section className="pred-metrics">
          {kpis.map(([label, val]) => (
            <div className="metric" key={label}>
              <span className="metric-ico">{KPI_ICON[label]}</span>
              <div><div className="metric-val">{val == null ? '—' : Number(val).toFixed(4)}</div><div className="metric-label">{label}</div></div>
            </div>
          ))}
        </section>
      )}
    </div>
  );
}
