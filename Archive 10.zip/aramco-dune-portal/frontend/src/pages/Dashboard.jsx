import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api';
import { PRIORITY_COLORS, STATUS_LABEL } from '../constants';
import { computeSlaStatus } from '../sla';

function TrendBars({ trend }) {
  const max = Math.max(1, ...trend.map((d) => d.count));
  return (
    <div className="trend-bars">
      {trend.map((d) => {
        const date = new Date(d.day);
        const label = date.toLocaleDateString('en-GB', { weekday: 'short' });
        return (
          <div className="trend-col" key={d.day}>
            <div className="trend-bar-track">
              <div className="trend-bar-fill" style={{ height: `${(d.count / max) * 100}%` }} />
            </div>
            <div className="trend-count">{d.count}</div>
            <div className="trend-label">{label}</div>
          </div>
        );
      })}
    </div>
  );
}

function PriorityBreakdown({ breakdown }) {
  const total = Object.values(breakdown).reduce((a, b) => a + b, 0);
  if (total === 0) {
    return <div className="empty-state"><span>No open work orders right now.</span></div>;
  }
  return (
    <div className="priority-breakdown">
      <div className="priority-bar">
        {Object.entries(breakdown).filter(([, v]) => v > 0).map(([priority, count]) => (
          <div
            key={priority}
            style={{ width: `${(count / total) * 100}%`, background: PRIORITY_COLORS[priority] }}
            title={`${priority}: ${count}`}
          />
        ))}
      </div>
      <div className="priority-legend-row">
        {Object.entries(breakdown).map(([priority, count]) => (
          <div className="priority-legend-item" key={priority}>
            <span className="legend-swatch" style={{ background: PRIORITY_COLORS[priority] }} />
            {priority} ({count})
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [workOrders, setWorkOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reportOpen, setReportOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const [summaryData, woData] = await Promise.all([api.getSummary(), api.getWorkOrders()]);
      setSummary(summaryData);
      setWorkOrders(woData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, 20000);
    return () => clearInterval(id);
  }, [load]);

  const topOpen = workOrders.filter((w) => !['COMPLETED', 'CANCELLED'].includes(w.status)).slice(0, 5);

  const resolvedSlas = workOrders.map(computeSlaStatus).filter((s) => s && s.phase === 'resolved');
  const slaMetCount = resolvedSlas.filter((s) => s.met).length;
  const slaPct = resolvedSlas.length ? Math.round((100 * slaMetCount) / resolvedSlas.length) : null;

  return (
    <div className="page page-dashboard">
      <div className="page-header-row">
        <h1 className="page-title">Operations overview</h1>
        <button className="btn btn-ghost" onClick={() => setReportOpen(true)}>
          Generate situation report
        </button>
      </div>

      {loading && !summary ? (
        <div className="empty-state"><span>Loading dashboard…</span></div>
      ) : (
        <>
          <div className="kpi-grid kpi-grid-wide kpi-grid-eight">
            <div className="kpi-card">
              <div className="kpi-value">{summary?.total_assets ?? '—'}</div>
              <div className="kpi-label">Monitored assets</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-value warn">{summary?.high_risk_zones ?? '—'}</div>
              <div className="kpi-label">High-risk zones</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-value accent">{summary?.open_work_orders ?? '—'}</div>
              <div className="kpi-label">Open work orders</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-value">{summary?.available_crews ?? '—'}</div>
              <div className="kpi-label">Crews available</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-value">{summary?.equipment ? `${summary.equipment.HEAVY.free}/${summary.equipment.HEAVY.total}` : '—'}</div>
              <div className="kpi-label">Heavy equipment free</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-value">{summary?.equipment ? `${summary.equipment.LIGHT.free}/${summary.equipment.LIGHT.total}` : '—'}</div>
              <div className="kpi-label">Light equipment free</div>
            </div>
            <div className={`kpi-card${summary?.flagged_open ? ' kpi-card-alert' : ''}`}>
              <div className="kpi-value critical">{summary?.flagged_open ?? '—'}</div>
              <div className="kpi-label">Issues flagged by crews</div>
            </div>
            <div className={`kpi-card${slaPct != null && slaPct < 80 ? ' kpi-card-alert' : ''}`}>
              <div className={`kpi-value${slaPct != null && slaPct < 80 ? ' critical' : ''}`}>{slaPct != null ? `${slaPct}%` : '—'}</div>
              <div className="kpi-label">SLA compliance ({resolvedSlas.length} resolved)</div>
            </div>
          </div>

          <div className="dashboard-grid">
            <div className="dash-panel">
              <div className="panel-heading">Open work orders by priority</div>
              <PriorityBreakdown breakdown={summary?.priority_breakdown || { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 }} />
            </div>

            <div className="dash-panel">
              <div className="panel-heading">Work orders opened, last 7 days</div>
              <TrendBars trend={summary?.trend_7day || []} />
            </div>
          </div>

          <div className="dash-panel">
            <div className="panel-heading">Highest-priority open work orders</div>
            {topOpen.length ? (
              <div className="wo-list">
                {topOpen.map((wo) => (
                  <div className="wo-card wo-card-compact" key={wo.id}>
                    <div className="wo-top">
                      <span className="wo-id">#{String(wo.id).padStart(4, '0')}</span>
                      <span className={`badge badge-${wo.priority.toLowerCase()}`}>{wo.priority}</span>
                    </div>
                    <div className="wo-asset">{wo.asset_name}</div>
                    <div className="wo-detail">Status: {STATUS_LABEL[wo.status]} · Crew: {wo.crew_name || 'Unassigned'}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="empty-state"><span>No open work orders. All clear.</span></div>
            )}
          </div>
        </>
      )}

      {reportOpen && summary && (
        <div className="report-overlay" onClick={() => setReportOpen(false)}>
          <div className="report-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="report-header">
              <div>
                <div className="report-title">Dune Dynamix — Situation Report</div>
                <div className="report-subtitle">Generated {new Date().toLocaleString()}</div>
              </div>
              <div className="report-actions no-print">
                <button className="btn btn-ghost" onClick={() => setReportOpen(false)}>Close</button>
                <button className="btn btn-primary" onClick={() => window.print()}>Print / Save PDF</button>
              </div>
            </div>

            <div className="report-kpis">
              <div><strong>{summary.total_assets}</strong> monitored assets</div>
              <div><strong>{summary.high_risk_zones}</strong> high-risk zones</div>
              <div><strong>{summary.open_work_orders}</strong> open work orders</div>
              <div><strong>{summary.available_crews}</strong> crews available</div>
            </div>

            <div className="report-section-title">Priority breakdown (open work orders)</div>
            <ul className="report-list">
              {Object.entries(summary.priority_breakdown).map(([p, c]) => (
                <li key={p}>{p}: {c}</li>
              ))}
            </ul>

            <div className="report-section-title">Top open work orders</div>
            <table className="report-table">
              <thead>
                <tr><th>ID</th><th>Asset</th><th>Priority</th><th>Status</th><th>Crew</th></tr>
              </thead>
              <tbody>
                {topOpen.map((wo) => (
                  <tr key={wo.id}>
                    <td>#{String(wo.id).padStart(4, '0')}</td>
                    <td>{wo.asset_name}</td>
                    <td>{wo.priority}</td>
                    <td>{STATUS_LABEL[wo.status]}</td>
                    <td>{wo.crew_name || 'Unassigned'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
