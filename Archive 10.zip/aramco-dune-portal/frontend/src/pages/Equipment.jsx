import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { useToast } from '../ToastContext';
import { useSite } from '../SiteContext';

const EQUIPMENT_TYPES = {
  HEAVY: ['Bulldozer', 'Wheel loader', 'Motor grader', 'Excavator', 'Dump truck', 'Compactor'],
  LIGHT: ['Pickup', 'Skid-steer', 'Water bowser', 'Trailer', 'ATV', 'Generator', 'Sweeper'],
};
const todayISO = () => new Date().toISOString().slice(0, 10);
const plusDays = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
const EMPTY = { unit_code: '', name: '', equipment_class: 'HEAVY', equipment_type: 'Bulldozer', make_model: '', status: 'AVAILABLE', last_service_on: '', next_service_due: '', notes: '' };
const STATUS_LABEL = { AVAILABLE: 'Available', MAINTENANCE: 'Maintenance', RETIRED: 'Retired' };

const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
const fmtDateTime = (d) => (d ? new Date(d).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');

function Modal({ title, onClose, children }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="modal-overlay" role="dialog" aria-modal="true" aria-label={title} onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head"><h3>{title}</h3><button className="modal-x" aria-label="Close" onClick={onClose}>×</button></div>
        {children}
      </div>
    </div>
  );
}

function FleetTile({ label, s }) {
  return (
    <div className="pred-card fleet-tile">
      <div className="pred-stat-label">{label} equipment</div>
      <div className="fleet-num">{s.total}<small> units</small></div>
      <div className="fleet-row">
        <span><b>{s.free}</b> free</span><span><b>{s.assigned}</b> on crews</span>
        <span className={s.maintenance ? 'warn' : ''}><b>{s.maintenance}</b> maintenance</span>
        <span className={s.service_overdue ? 'bad' : ''}><b>{s.service_overdue}</b> service overdue</span>
      </div>
    </div>
  );
}


// ---- Schedule tab: availability finder + bookings ----
function SchedulePanel({ crews, sites, onBook, reloadKey }) {
  const showToast = useToast();
  const [win, setWin] = useState({ from: todayISO(), to: plusDays(7), cls: '' });
  const [avail, setAvail] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [site, setSite] = useState('');

  const loadBookings = useCallback(async () => {
    try { setBookings(await api.getEquipmentSchedules({ site_id: site, status: '', from: todayISO() })); } catch (err) { showToast(err.message, true); }
  }, [site, showToast]);
  useEffect(() => { loadBookings(); }, [loadBookings, reloadKey]);

  const find = async () => {
    try { setAvail(await api.getEquipmentAvailability(win.from, win.to, win.cls)); } catch (err) { showToast(err.message, true); }
  };
  const setStatus = async (b, status) => {
    try { await api.setEquipmentScheduleStatus(b.id, status); loadBookings(); } catch (err) { showToast(err.message, true); }
  };
  const del = async (b) => {
    if (!window.confirm('Delete this booking?')) return;
    try { await api.deleteEquipmentSchedule(b.id); loadBookings(); } catch (err) { showToast(err.message, true); }
  };

  return (
    <>
      <section className="pred-card">
        <h3 className="pred-card-title"><span className="pred-dot" /> Find available equipment</h3>
        <div className="eq-filters">
          <label className="eq-inline">From<input type="date" className="pred-date" value={win.from} onChange={(e) => setWin((w) => ({ ...w, from: e.target.value }))} /></label>
          <label className="eq-inline">To<input type="date" className="pred-date" value={win.to} min={win.from} onChange={(e) => setWin((w) => ({ ...w, to: e.target.value }))} /></label>
          <select className="pred-select" value={win.cls} onChange={(e) => setWin((w) => ({ ...w, cls: e.target.value }))} aria-label="Class">
            <option value="">Heavy and light</option><option value="HEAVY">Heavy</option><option value="LIGHT">Light</option>
          </select>
          <button className="btn btn-primary" onClick={find}>Check availability</button>
        </div>
        {avail && (
          <div className="table-scroll">
            <table className="st-table">
              <thead><tr><th>Unit</th><th>Type</th><th>Crew now</th><th /></tr></thead>
              <tbody>
                {avail.units.map((u) => (
                  <tr key={u.id}><td><div className="st-unit">{u.name}</div><div className="mono-value">{u.unit_code}</div></td><td>{u.equipment_type}</td><td>{u.crew_name || 'Yard'}</td>
                    <td><button className="link-btn" onClick={() => onBook(u, avail.from, avail.to)}>Book for these dates</button></td></tr>
                ))}
                {!avail.units.length && <tr><td colSpan={4} className="empty-cell">Nothing is free for {avail.from} to {avail.to}.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="pred-card">
        <h3 className="pred-card-title"><span className="pred-dot" /> Bookings</h3>
        <div className="eq-filters">
          <select className="pred-select" value={site} onChange={(e) => setSite(e.target.value)} aria-label="Site">
            <option value="">All sites</option>{sites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        <div className="table-scroll">
          <table className="st-table">
            <thead><tr><th>Unit</th><th>Dates</th><th>Site</th><th>Crew</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b.id} className={b.status === 'CANCELLED' ? 'row-muted' : ''}>
                  <td><div className="st-unit">{b.equipment_name}</div><div className="mono-value">{b.unit_code}</div></td>
                  <td>{fmtDate(b.start_date)} – {fmtDate(b.end_date)}{b.purpose && <div className="wo-detail-faint">{b.purpose}</div>}</td>
                  <td>{b.site_name || '—'}</td><td>{b.crew_name || '—'}</td>
                  <td><span className={`status-chip ${b.status === 'SCHEDULED' ? 'status-chip-dispatched' : b.status === 'COMPLETED' ? 'status-chip-available' : 'status-chip-off_duty'}`}>{b.status.toLowerCase()}</span></td>
                  <td><div className="row-actions">
                    {b.status === 'SCHEDULED' && <button className="link-btn" onClick={() => setStatus(b, 'COMPLETED')}>Complete</button>}
                    {b.status === 'SCHEDULED' && <button className="link-btn" onClick={() => setStatus(b, 'CANCELLED')}>Cancel</button>}
                    <button className="link-btn danger" onClick={() => del(b)}>Delete</button>
                  </div></td>
                </tr>
              ))}
              {!bookings.length && <tr><td colSpan={6} className="empty-cell">No current or upcoming bookings.</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

// ---- Report tab ----
function ReportPanel() {
  const showToast = useToast();
  const [r, setR] = useState(null);
  useEffect(() => { api.getEquipmentReport().then(setR).catch((err) => showToast(err.message, true)); }, [showToast]);
  if (!r) return <div className="empty-state"><span>Loading report…</span></div>;
  const count = (cls, st) => r.by_status.find((x) => x.equipment_class === cls && x.status === st)?.units ?? 0;
  return (
    <div className="eq-report">
      <section className="pred-card">
        <h3 className="pred-card-title"><span className="pred-dot" /> Fleet status</h3>
        <table className="st-table"><thead><tr><th>Class</th><th>Available</th><th>Maintenance</th><th>Retired</th></tr></thead>
          <tbody>{['HEAVY', 'LIGHT'].map((c) => <tr key={c}><td>{c === 'HEAVY' ? 'Heavy' : 'Light'}</td><td>{count(c, 'AVAILABLE')}</td><td>{count(c, 'MAINTENANCE')}</td><td>{count(c, 'RETIRED')}</td></tr>)}</tbody></table>
      </section>
      <section className="pred-card">
        <h3 className="pred-card-title"><span className="pred-dot" /> Service due (next 30 days or overdue)</h3>
        <table className="st-table"><thead><tr><th>Unit</th><th>Due</th><th>Days left</th></tr></thead>
          <tbody>{r.service_due.map((u) => <tr key={u.id}><td>{u.name} <span className="mono-value">{u.unit_code}</span></td><td>{fmtDate(u.next_service_due)}</td><td className={u.days_left < 0 ? 'svc-overdue' : ''}>{u.days_left < 0 ? `${-u.days_left} overdue` : u.days_left}</td></tr>)}
            {!r.service_due.length && <tr><td colSpan={3} className="empty-cell">Nothing due.</td></tr>}</tbody></table>
      </section>
      <section className="pred-card">
        <h3 className="pred-card-title"><span className="pred-dot" /> Utilisation, last 30 days (booked days)</h3>
        <table className="st-table"><thead><tr><th>Unit</th><th>Booked days</th></tr></thead>
          <tbody>{r.utilisation_30d.slice(0, 12).map((u) => <tr key={u.id}><td>{u.name} <span className="mono-value">{u.unit_code}</span></td><td>{u.booked_days_30d}</td></tr>)}</tbody></table>
      </section>
      <section className="pred-card">
        <h3 className="pred-card-title"><span className="pred-dot" /> Equipment per crew and bookings per site</h3>
        <table className="st-table"><thead><tr><th>Crew</th><th>Heavy</th><th>Light</th></tr></thead>
          <tbody>{r.by_crew.map((c) => <tr key={c.crew_id}><td>{c.crew_name}</td><td>{c.heavy}</td><td>{c.light}</td></tr>)}</tbody></table>
        <table className="st-table" style={{ marginTop: 12 }}><thead><tr><th>Site</th><th>Bookings</th><th>Units</th></tr></thead>
          <tbody>{r.by_site.map((s) => <tr key={s.site_id}><td>{s.site_name}</td><td>{s.bookings}</td><td>{s.units}</td></tr>)}
            {!r.by_site.length && <tr><td colSpan={3} className="empty-cell">No bookings.</td></tr>}</tbody></table>
      </section>
    </div>
  );
}

export default function Equipment() {
  const showToast = useToast();
  const { sites, siteId } = useSite();
  const [tab, setTab] = useState('fleet');
  const [booking, setBooking] = useState(null); // { unit, start_date, end_date, site_id, crew_id, purpose }
  const [bookKey, setBookKey] = useState(0);
  const [typeList, setTypeList] = useState(EQUIPMENT_TYPES);
  const [rows, setRows] = useState([]);
  const [summary, setSummary] = useState(null);
  const [crews, setCrews] = useState([]);
  const [filters, setFilters] = useState({ class: '', status: '', crew_id: '', q: '' });
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);      // null | { id?, ...fields }
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [history, setHistory] = useState(null); // { unit, rows }

  const load = useCallback(async () => {
    try {
      const [list, sum, crewList] = await Promise.all([api.getEquipment(filters), api.getEquipmentSummary(), api.getCrews()]);
      setRows(list); setSummary(sum); setCrews(crewList);
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setLoading(false);
    }
  }, [filters, showToast]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { api.getEquipmentTypes().then(setTypeList).catch(() => {}); }, []);

  const openBook = (unit, from, to) => setBooking({ unit, start_date: from || todayISO(), end_date: to || plusDays(3), site_id: siteId || '', crew_id: unit.crew_id || '', purpose: '' });
  const saveBooking = async (ev) => {
    ev.preventDefault();
    try {
      await api.createEquipmentSchedule({ equipment_id: booking.unit.id, site_id: booking.site_id ? Number(booking.site_id) : null, crew_id: booking.crew_id ? Number(booking.crew_id) : null, start_date: booking.start_date, end_date: booking.end_date, purpose: booking.purpose });
      showToast(`${booking.unit.unit_code} booked`);
      setBooking(null); setBookKey((k) => k + 1); load();
    } catch (err) { showToast(err.message, true); }
  };

  const setFilter = (k, v) => setFilters((f) => ({ ...f, [k]: v }));

  const openCreate = () => { setErrors({}); setForm({ ...EMPTY }); };
  const openEdit = (u) => {
    setErrors({});
    setForm({
      id: u.id, unit_code: u.unit_code, name: u.name, equipment_class: u.equipment_class, equipment_type: u.equipment_type,
      make_model: u.make_model || '', status: u.status, last_service_on: u.last_service_on || '', next_service_due: u.next_service_due || '', notes: u.notes || '',
      crew_id: u.crew_id,
    });
  };

  const validate = (f) => {
    const e = {};
    if (!f.unit_code.trim()) e.unit_code = 'Unit code is required';
    if (!f.name.trim()) e.name = 'Name is required';
    if (!f.equipment_type.trim()) e.equipment_type = 'Type is required';
    if (f.last_service_on && f.next_service_due && f.next_service_due < f.last_service_on) e.next_service_due = 'Cannot be before the last service date';
    return e;
  };

  const save = async (ev) => {
    ev.preventDefault();
    const e = validate(form);
    setErrors(e);
    if (Object.keys(e).length) return;
    setSaving(true);
    try {
      const { id, crew_id: _crew, ...body } = form;
      const payload = { ...body, last_service_on: body.last_service_on || null, next_service_due: body.next_service_due || null };
      if (id) await api.updateEquipment(id, payload); else await api.createEquipment(payload);
      showToast(id ? 'Equipment updated' : 'Equipment added');
      setForm(null);
      load();
    } catch (err) {
      showToast(err.message, true);
    } finally {
      setSaving(false);
    }
  };

  const assign = async (u, crewId) => {
    try {
      await api.assignEquipment(u.id, crewId ? Number(crewId) : null);
      showToast(crewId ? `${u.unit_code} assigned` : `${u.unit_code} returned to the yard`);
      load();
    } catch (err) { showToast(err.message, true); }
  };

  const setStatus = async (u, status) => {
    try {
      await api.updateEquipment(u.id, { status });
      showToast(`${u.unit_code}: ${STATUS_LABEL[status].toLowerCase()}`);
      load();
    } catch (err) { showToast(err.message, true); }
  };

  const remove = async (u) => {
    if (!window.confirm(`Delete ${u.unit_code} (${u.name})? Its assignment history is deleted too. Use Retire to keep the record.`)) return;
    try { await api.deleteEquipment(u.id); showToast(`${u.unit_code} deleted`); load(); } catch (err) { showToast(err.message, true); }
  };

  const showHistory = async (u) => {
    try { setHistory({ unit: u, rows: await api.getEquipmentHistory(u.id) }); } catch (err) { showToast(err.message, true); }
  };

  const crewOptions = useMemo(() => crews.filter((c) => c.status !== 'OFF_DUTY'), [crews]);
  const types = typeList[form?.equipment_class] || [];
  const field = (k) => ({ value: form?.[k] ?? '', onChange: (e) => setForm((f) => ({ ...f, [k]: e.target.value })) });

  return (
    <div className="pred-page">
      <section className="pred-bar st-bar">
        <div>
          <div className="pred-bar-label">Fleet</div>
          <div className="st-title">Heavy &amp; light equipment</div>
        </div>
        <div className="st-actions">
          <Link className="btn btn-ghost" to="/schedule">Scheduling team</Link>
          <button className="btn btn-primary" onClick={openCreate}>+ Add equipment</button>
        </div>
      </section>

      <div className="st-tabs">
        {[['fleet', 'Fleet'], ['schedule', 'Schedule'], ['report', 'Report']].map(([k, l]) => <button key={k} className={`st-tab${tab === k ? ' active' : ''}`} onClick={() => setTab(k)}>{l}</button>)}
      </div>

      {tab === 'schedule' && <SchedulePanel crews={crews} sites={sites} onBook={openBook} reloadKey={bookKey} />}
      {tab === 'report' && <ReportPanel />}

      {tab === 'fleet' && summary && (
        <div className="fleet-grid">
          <FleetTile label="Heavy" s={summary.HEAVY} />
          <FleetTile label="Light" s={summary.LIGHT} />
        </div>
      )}

      {tab === 'fleet' && <section className="pred-card">
        <div className="eq-filters">
          <input className="pred-select" placeholder="Search code, name or type…" value={filters.q} onChange={(e) => setFilter('q', e.target.value)} aria-label="Search equipment" />
          <select className="pred-select" value={filters.class} onChange={(e) => setFilter('class', e.target.value)} aria-label="Class">
            <option value="">All classes</option><option value="HEAVY">Heavy</option><option value="LIGHT">Light</option>
          </select>
          <select className="pred-select" value={filters.status} onChange={(e) => setFilter('status', e.target.value)} aria-label="Status">
            <option value="">Any status</option>{Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select className="pred-select" value={filters.crew_id} onChange={(e) => setFilter('crew_id', e.target.value)} aria-label="Crew">
            <option value="">Any crew</option><option value="none">Unassigned (yard)</option>{crews.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>

        <div className="table-scroll">
          <table className="st-table eq-table">
            <thead><tr><th>Unit</th><th>Class / type</th><th>Status</th><th>Assigned to</th><th>Service</th><th>Actions</th></tr></thead>
            <tbody>
              {rows.map((u) => (
                <tr key={u.id} className={u.status === 'RETIRED' ? 'row-muted' : ''}>
                  <td><div className="st-unit">{u.name}</div><div className="mono-value">{u.unit_code}{u.make_model ? ` · ${u.make_model}` : ''}</div></td>
                  <td><span className={`eq-chip eq-${u.equipment_class.toLowerCase()}`}><b>{u.equipment_class === 'HEAVY' ? 'H' : 'L'}</b>{u.equipment_class === 'HEAVY' ? 'Heavy' : 'Light'}</span><div className="wo-detail">{u.equipment_type}</div></td>
                  <td><span className={`status-chip ${u.status === 'AVAILABLE' ? 'status-chip-available' : u.status === 'MAINTENANCE' ? 'status-chip-dispatched' : 'status-chip-off_duty'}`}>{STATUS_LABEL[u.status]}</span></td>
                  <td>
                    {u.status === 'AVAILABLE' ? (
                      <select className="select-control" value={u.crew_id ?? ''} onChange={(e) => assign(u, e.target.value)} aria-label={`Assign ${u.unit_code}`}>
                        <option value="">Unassigned (yard)</option>
                        {crewOptions.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    ) : <span className="wo-detail-faint">Not assignable</span>}
                    {u.assigned_since && <div className="wo-detail-faint">since {fmtDate(u.assigned_since)}</div>}
                  </td>
                  <td>
                    <div className="wo-detail">Last {fmtDate(u.last_service_on)}</div>
                    <div className={u.service_overdue ? 'svc-overdue' : 'wo-detail'}>Next {fmtDate(u.next_service_due)}{u.service_overdue ? ' · overdue' : ''}</div>
                    {u.next_booking && <div className="wo-detail-faint">Booked from {fmtDate(u.next_booking)}</div>}
                  </td>
                  <td>
                    <div className="row-actions">
                      <button className="link-btn" onClick={() => openEdit(u)}>Edit</button>
                      <button className="link-btn" onClick={() => showHistory(u)}>History</button>
                      {u.status === 'AVAILABLE' && <button className="link-btn" onClick={() => openBook(u)}>Schedule</button>}
                      {u.status === 'AVAILABLE' && <button className="link-btn" onClick={() => setStatus(u, 'MAINTENANCE')}>Maintenance</button>}
                      {u.status !== 'AVAILABLE' && <button className="link-btn" onClick={() => setStatus(u, 'AVAILABLE')}>Return to service</button>}
                      {u.status !== 'RETIRED' && <button className="link-btn" onClick={() => setStatus(u, 'RETIRED')}>Retire</button>}
                      <button className="link-btn danger" disabled={!!u.crew_id} title={u.crew_id ? 'Release from the crew first' : ''} onClick={() => remove(u)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
              {!rows.length && <tr><td colSpan={6} className="empty-cell">{loading ? 'Loading…' : 'No equipment matches these filters.'}</td></tr>}
            </tbody>
          </table>
        </div>
      </section>}

      {form && (
        <Modal title={form.id ? `Edit ${form.unit_code}` : 'Add equipment'} onClose={() => setForm(null)}>
          <form className="modal-form" onSubmit={save} noValidate>
            <label>Unit code<input {...field('unit_code')} placeholder="HVY-D9-07" />{errors.unit_code && <span className="field-error">{errors.unit_code}</span>}</label>
            <label>Name<input {...field('name')} placeholder="CAT D9 Bulldozer" />{errors.name && <span className="field-error">{errors.name}</span>}</label>
            <label>Class
              <select value={form.equipment_class} onChange={(e) => setForm((f) => ({ ...f, equipment_class: e.target.value, equipment_type: (typeList[e.target.value] || [])[0] || '' }))}>
                <option value="HEAVY">Heavy equipment</option><option value="LIGHT">Light equipment</option>
              </select>
            </label>
            <label>Type
              <input list="eq-types" {...field('equipment_type')} />
              <datalist id="eq-types">{types.map((t) => <option key={t} value={t} />)}</datalist>
              {errors.equipment_type && <span className="field-error">{errors.equipment_type}</span>}
            </label>
            <label>Make / model<input {...field('make_model')} /></label>
            <label>Status
              <select {...field('status')}>{Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
            </label>
            <label>Last service<input type="date" {...field('last_service_on')} /></label>
            <label>Next service due<input type="date" {...field('next_service_due')} />{errors.next_service_due && <span className="field-error">{errors.next_service_due}</span>}</label>
            <label className="span-2">Notes<textarea rows={2} {...field('notes')} /></label>
            {form.id && form.status !== 'AVAILABLE' && form.crew_id && <p className="span-2 wo-detail-faint">Saving as {STATUS_LABEL[form.status].toLowerCase()} releases this unit from its crew.</p>}
            <div className="modal-actions span-2">
              <button type="button" className="btn btn-ghost" onClick={() => setForm(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : form.id ? 'Save changes' : 'Add equipment'}</button>
            </div>
          </form>
        </Modal>
      )}

      {history && (
        <Modal title={`${history.unit.unit_code} — assignment history`} onClose={() => setHistory(null)}>
          {history.rows.length ? (
            <table className="st-table">
              <thead><tr><th>Crew</th><th>Assigned</th><th>Released</th><th>Days</th><th>Note</th></tr></thead>
              <tbody>{history.rows.map((h) => (
                <tr key={h.id}><td>{h.crew_name}</td><td>{fmtDateTime(h.assigned_at)}</td><td>{h.released_at ? fmtDateTime(h.released_at) : <b>current</b>}</td><td>{h.days}</td><td className="wo-detail-faint">{h.release_note || ''}</td></tr>
              ))}</tbody>
            </table>
          ) : <p className="wo-detail-faint">This unit has never been assigned to a crew.</p>}
        </Modal>
      )}
      {booking && (
        <Modal title={`Schedule ${booking.unit.unit_code}`} onClose={() => setBooking(null)}>
          <form className="modal-form" onSubmit={saveBooking}>
            <label>Start<input type="date" required value={booking.start_date} onChange={(e) => setBooking((b) => ({ ...b, start_date: e.target.value }))} /></label>
            <label>End<input type="date" required min={booking.start_date} value={booking.end_date} onChange={(e) => setBooking((b) => ({ ...b, end_date: e.target.value }))} /></label>
            <label>Site
              <select value={booking.site_id} onChange={(e) => setBooking((b) => ({ ...b, site_id: e.target.value }))}>
                <option value="">No site</option>{sites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </label>
            <label>Crew
              <select value={booking.crew_id} onChange={(e) => setBooking((b) => ({ ...b, crew_id: e.target.value }))}>
                <option value="">No crew</option>{crewOptions.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </label>
            <label className="span-2">Purpose<input value={booking.purpose} maxLength={200} onChange={(e) => setBooking((b) => ({ ...b, purpose: e.target.value }))} /></label>
            <div className="modal-actions span-2">
              <button type="button" className="btn btn-ghost" onClick={() => setBooking(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Book</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
