import React, { useCallback, useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { api } from '../api';
import { useToast } from '../ToastContext';
import { crewAppUrl, timeAgo, TILE_URL, TILE_ATTRIBUTION } from '../constants';
import { makeCrewIcon } from '../mapUtils';

function PinReveal({ crewId }) {
  const [pin, setPin] = useState(null);
  const [loading, setLoading] = useState(false);

  const reveal = async () => {
    setLoading(true);
    try {
      const { access_code } = await api.getCrewAccessCode(crewId);
      setPin(access_code);
    } catch {
      setPin('—');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pin-reveal-row">
      <span className="field-label">Crew PIN:</span>
      <span className="mono-value">{pin ?? '••••'}</span>
      <button className="link-btn" onClick={() => (pin ? setPin(null) : reveal())} disabled={loading}>
        {loading ? '…' : pin ? 'Hide' : 'Show'}
      </button>
    </div>
  );
}

export default function Crews() {
  const showToast = useToast();
  const [crews, setCrews] = useState([]);
  const [linkCopied, setLinkCopied] = useState(false);

  const load = useCallback(async () => {
    try {
      setCrews(await api.getCrews());
    } catch (err) {
      showToast(err.message, true);
    }
  }, [showToast]);

  useEffect(() => {
    load();
    const id = setInterval(load, 15000);
    return () => clearInterval(id);
  }, [load]);

  const copyAppLink = async () => {
    const url = crewAppUrl();
    try {
      await navigator.clipboard.writeText(url);
      setLinkCopied(true);
      showToast('App link copied — share it with all crews once.');
      setTimeout(() => setLinkCopied(false), 2000);
    } catch {
      showToast(url);
    }
  };

  const bounds = crews.length
    ? L.latLngBounds(crews.filter((c) => c.lon != null).map((c) => [c.lat, c.lon]))
    : null;

  return (
    <div className="page page-crews">
      <h1 className="page-title">Crews</h1>

      <div className="shared-link-banner">
        <div>
          <div className="shared-link-label">One link for every crew</div>
          <div className="shared-link-url">{crewAppUrl()}</div>
          <div className="shared-link-hint">
            Send this once to the whole team (SMS, WhatsApp, or a printed card). Each person picks their
            name and enters their own PIN below to see their own jobs — no per-crew links to manage.
          </div>
        </div>
        <button className="btn btn-primary" onClick={copyAppLink}>
          {linkCopied ? 'Copied' : 'Copy link'}
        </button>
      </div>

      <div className="crews-layout">
        <div className="crews-map-wrap">
          <MapContainer center={[26.31, 49.99]} zoom={11} scrollWheelZoom style={{ height: '100%', width: '100%' }}>
            <TileLayer url={TILE_URL} attribution={TILE_ATTRIBUTION} />
            {crews.map((c) => c.lon != null && (
              <Marker key={c.id} position={[c.lat, c.lon]} icon={makeCrewIcon(c.status)}>
                <Popup>
                  <div className="popup-title">{c.name}</div>
                  <div className="popup-row">Engine: {c.engine_id}</div>
                  <div className="popup-row">
                    {c.has_live_location ? `Live position · ${timeAgo(c.last_ping_at)}` : 'Base location (no live GPS yet)'}
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>

        <div className="crews-roster">
          {crews.map((c) => (
            <div className="crew-roster-card" key={c.id}>
              <div className="crew-roster-top">
                <span className="crew-roster-name">{c.name}</span>
                <span className={`status-chip status-chip-${c.status.toLowerCase()}`}>{c.status.replace('_', ' ')}</span>
              </div>
              <div className="wo-detail">{c.specialty} specialist · {c.base_location}</div>
              <div className="wo-detail">Engine ID: <span className="mono-value">{c.engine_id}</span></div>
              <div className="wo-detail">{c.open_work_orders} active work order(s)</div>
              <div className="wo-detail">{c.headcount} people</div>
              <div className="eq-inline">
                {(c.equipment || []).length
                  ? c.equipment.map((u) => (
                      <span key={u.id} className={`eq-chip eq-${u.equipment_class.toLowerCase()}`} title={`${u.unit_code} · ${u.equipment_type}`}>
                        <b>{u.equipment_class === 'HEAVY' ? 'H' : 'L'}</b> {u.name}
                      </span>
                    ))
                  : <span className="wo-detail-faint">No equipment assigned</span>}
              </div>
              <div className={`wo-detail location-freshness${c.has_live_location ? ' location-live' : ''}`}>
                {c.has_live_location ? `📍 Live location · updated ${timeAgo(c.last_ping_at)}` : '📍 No live location reported yet'}
              </div>

              <PinReveal crewId={c.id} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
