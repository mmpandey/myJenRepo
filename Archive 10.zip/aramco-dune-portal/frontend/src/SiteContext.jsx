import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from './api';

const SiteContext = createContext(null);
const STORAGE_KEY = 'ddx_site_id';

// The selected site ties the pages together: Prediction runs for it, and the Scheduling Team,
// Dispatch and Work Orders pages open filtered to it. Remembered across reloads.
export function SiteProvider({ children }) {
  const [sites, setSites] = useState([]);
  const [siteId, setSiteIdState] = useState(() => {
    try { const v = localStorage.getItem(STORAGE_KEY); return v ? Number(v) : null; } catch { return null; }
  });

  const reloadSites = useCallback(async () => {
    try { setSites(await api.getSites()); } catch { /* pages surface connectivity errors themselves */ }
  }, []);
  useEffect(() => { reloadSites(); }, [reloadSites]);

  const setSiteId = useCallback((id) => {
    setSiteIdState(id);
    try { if (id) localStorage.setItem(STORAGE_KEY, String(id)); else localStorage.removeItem(STORAGE_KEY); } catch { /* storage unavailable */ }
  }, []);

  const value = useMemo(
    () => ({ sites, siteId, site: sites.find((s) => s.id === siteId) || null, setSiteId, reloadSites }),
    [sites, siteId, setSiteId, reloadSites]
  );
  return <SiteContext.Provider value={value}>{children}</SiteContext.Provider>;
}

export const useSite = () => useContext(SiteContext);
