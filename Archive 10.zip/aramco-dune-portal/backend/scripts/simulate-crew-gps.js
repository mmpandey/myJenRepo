#!/usr/bin/env node
// ---------------------------------------------------------------------------
// Demo helper: simulate a crew phone reporting live GPS along its dispatched job,
// so the "Actual path driven" line appears on the Dispatch map without a phone.
//
//   node scripts/simulate-crew-gps.js [crewId] [--api http://localhost:5000]
//                                     [--steps 20] [--interval 1500]
//
// - Picks the first DISPATCHED / IN_PROGRESS work order (or the one for crewId).
// - Walks the planned road route (or a straight line if no road route was stored)
//   from the crew's current position to the asset, posting one GPS point per step
//   to POST /api/crews/:id/location - exactly what the crew app does.
// - It only reports positions. It never changes a work order's status.
// ---------------------------------------------------------------------------
const args = process.argv.slice(2);
const flag = (name, fallback) => {
  const i = args.indexOf(name);
  return i >= 0 && args[i + 1] ? args[i + 1] : fallback;
};
const API = (flag('--api', process.env.API_URL || 'http://localhost:5000')).replace(/\/$/, '');
const STEPS = Math.max(2, Number(flag('--steps', 20)));
const INTERVAL = Math.max(100, Number(flag('--interval', 1500)));
const crewArg = args.find((a, i) => /^\d+$/.test(a) && !args[i - 1]?.startsWith('--'));

const toRad = (d) => (d * Math.PI) / 180;
const km = (a, b) => { // a, b = [lon, lat]
  const dLat = toRad(b[1] - a[1]); const dLon = toRad(b[0] - a[0]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a[1])) * Math.cos(toRad(b[1])) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(h));
};
const bearing = (a, b) => {
  const y = Math.sin(toRad(b[0] - a[0])) * Math.cos(toRad(b[1]));
  const x = Math.cos(toRad(a[1])) * Math.sin(toRad(b[1])) - Math.sin(toRad(a[1])) * Math.cos(toRad(b[1])) * Math.cos(toRad(b[0] - a[0]));
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
};

// Evenly spaced points along a polyline of [lon, lat].
function resample(line, n) {
  const cum = [0];
  for (let i = 1; i < line.length; i++) cum.push(cum[i - 1] + km(line[i - 1], line[i]));
  const total = cum[cum.length - 1] || 1e-9;
  const out = [];
  for (let k = 0; k < n; k++) {
    const target = (total * k) / (n - 1);
    let i = 1;
    while (i < cum.length - 1 && cum[i] < target) i++;
    const seg = cum[i] - cum[i - 1] || 1e-9;
    const t = Math.min(1, Math.max(0, (target - cum[i - 1]) / seg));
    out.push([line[i - 1][0] + (line[i][0] - line[i - 1][0]) * t, line[i - 1][1] + (line[i][1] - line[i - 1][1]) * t]);
  }
  return out;
}

async function http(path, options) {
  const res = await fetch(`${API}${path}`, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (!res.ok) throw new Error(`${options?.method || 'GET'} ${path} -> HTTP ${res.status}`);
  return res.json();
}

(async () => {
  const orders = await http('/api/work-orders');
  const wo = orders.find((w) => ['DISPATCHED', 'IN_PROGRESS'].includes(w.status) && w.crew_id && (!crewArg || w.crew_id === Number(crewArg)));
  if (!wo) {
    console.error('No dispatched work order with a crew was found. Dispatch a job from the Dispatch page first.');
    process.exit(1);
  }
  const start = [Number(wo.crew_lon), Number(wo.crew_lat)];
  const end = [Number(wo.asset_lon), Number(wo.asset_lat)];
  const road = wo.route_geometry?.coordinates;
  const line = Array.isArray(road) && road.length > 1 ? road : [start, end];
  const points = resample(line, STEPS);
  console.log(`Crew ${wo.crew_name} -> ${wo.asset_name}: ${STEPS} GPS points along the ${Array.isArray(road) && road.length > 1 ? 'planned road route' : 'straight line (no road route stored)'}, one every ${INTERVAL} ms.`);
  for (let i = 0; i < points.length; i++) {
    const heading = Math.round(bearing(points[Math.max(0, i - 1)], points[Math.min(points.length - 1, i + 1)]));
    await http(`/api/crews/${wo.crew_id}/location`, { method: 'POST', body: JSON.stringify({ lat: points[i][1], lon: points[i][0], heading }) });
    process.stdout.write(`\r  point ${i + 1}/${points.length}`);
    if (i < points.length - 1) await new Promise((r) => setTimeout(r, INTERVAL));
  }
  console.log('\nDone. The crew is now at the asset; status was not changed.');
})().catch((err) => { console.error(`\n${err.message}`); process.exit(1); });
