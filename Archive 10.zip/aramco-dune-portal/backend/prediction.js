// ---------------------------------------------------------------------------
// Sand accumulation prediction engine (pure functions, no DB access).
//
// Three models project the site's sand depth over the prediction window:
//   - Physics-only : wind drift potential x sediment supply, no seasonality
//   - CNN-LSTM     : data-driven proxy — shamal seasonal cycle + weekly gust pattern + momentum
//   - Hybrid       : 50/50 blend; this is the ensemble the portal acts on
// The site result is then spread over its assets ("blocks") by asset type and by
// how strongly each is hit by the mapped dune-forecast zones, giving a per-block
// risk class, and sized into a scheduling team: people + HEAVY and LIGHT equipment.
//
// The models are deterministic stand-ins so the portal works without an ML service.
// To plug in a real model, replace runSandPrediction() and keep the returned shape.
// ---------------------------------------------------------------------------

const MS_DAY = 86400000;
const DEPTH_FACTOR = 0.3;           // dune-front migration (m/yr) -> sand depth gained (m/yr)
const HIGH_AT_M = 1.2;              // predicted depth (m) at/above which a block/site is HIGH risk
const MODERATE_AT_M = 0.7;          // ... MODERATE risk
const TYPE_SENSITIVITY = { PIPELINE: 1.0, WELLHEAD: 1.1, FACILITY: 0.9, ROAD: 0.8 };

// Team sizing (tunable)
const HEAVY_NET_M = 0.25;           // net accumulation one heavy unit (dozer/loader) can clear per window
const LIGHT_PER_NET_M = 30;         // light units (pickup/skid-steer/bowser/ATV) per metre of net accumulation
const BASE_PEOPLE = 2;              // supervisor + safety officer
const PEOPLE_PER_HEAVY = 3;         // operator + spotter + support
const LIGHT_PER_PERSON = 2;         // one person covers two light units

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const round = (v, d = 3) => Math.round(v * 10 ** d) / 10 ** d;
const isoDay = (d) => d.toISOString().slice(0, 10);

function dayOfYear(date) {
  return Math.floor((date.getTime() - Date.UTC(date.getUTCFullYear(), 0, 0)) / MS_DAY);
}
// Shamal (NW wind) season peaks around early-mid July in the Eastern Province
const seasonalFactor = (date) => 1 + 0.35 * Math.sin((2 * Math.PI * (dayOfYear(date) - 100)) / 365);

function riskClass(depthM) {
  if (depthM >= HIGH_AT_M) return 'HIGH';
  if (depthM >= MODERATE_AT_M) return 'MODERATE';
  return 'LOW';
}

/**
 * @param {object} p
 * @param {{baseline_accum_m:number, wind_drift_potential:number, sand_supply_index:number}} p.site
 * @param {Array<{id:number,name:string,asset_type:string,lat:number,lon:number,zone_rate:number|null}>} p.assets
 * @param {string|Date} p.startDate
 * @param {number} p.windowDays 1..180
 */
function runSandPrediction({ site, assets, startDate, windowDays }) {
  const days = clamp(Math.round(Number(windowDays) || 30), 1, 180);
  const start = new Date(startDate);
  const current = Number(site.baseline_accum_m);
  const maxRate = Math.max(1, ...assets.map((a) => Number(a.zone_rate) || 0));
  // site-wide forward rate: the worst mapped zone sets the migration pressure (default 5 m/yr when nothing is mapped)
  const rate = maxRate > 1 ? maxRate : 5;

  const d0 = (rate / 365) * DEPTH_FACTOR;
  const wind = clamp(Number(site.wind_drift_potential) / 300, 0.5, 2);
  const supply = clamp(Number(site.sand_supply_index), 0.1, 1);

  let cPhys = current;
  let cMl = current;
  let cHyb = current;
  let peakDaily = 0;
  const series = [{ date: isoDay(start), predicted: round(current), lower: round(current), upper: round(current), physics: round(current), cnn_lstm: round(current) }];

  for (let t = 1; t <= days; t += 1) {
    const day = new Date(start.getTime() + (t - 1) * MS_DAY);
    const physics = d0 * wind * (0.6 + 0.4 * supply);
    const ml = d0 * seasonalFactor(day) * (1 + 0.12 * Math.sin((2 * Math.PI * t) / 7)) * (1 + 0.002 * t) * (0.85 + 0.3 * supply);
    const hybrid = 0.5 * physics + 0.5 * ml;
    cPhys += physics; cMl += ml; cHyb += hybrid;
    peakDaily = Math.max(peakDaily, hybrid);
    const band = 1.645 * 0.9 * d0 * Math.sqrt(t) + 0.25 * Math.abs(cPhys - cMl);
    series.push({
      date: isoDay(new Date(start.getTime() + t * MS_DAY)),
      predicted: round(cHyb), lower: round(Math.max(current, cHyb - band)), upper: round(cHyb + band),
      physics: round(cPhys), cnn_lstm: round(cMl),
    });
  }

  const net = cHyb - current;
  const spread = Math.max(cPhys, cMl, cHyb) - Math.min(cPhys, cMl, cHyb);
  const disagreement = net > 0 ? Math.min(spread / net, 1) : 1;
  const confidence = Math.round(clamp(96 - 45 * disagreement - 0.1 * days - 6 * (1 - supply), 35, 97));
  const last = series[series.length - 1];
  const bandEnd = (last.upper - last.lower) / 2;

  // ---- per block (asset) results
  const assetResults = assets.map((a) => {
    const zone = a.zone_rate ? clamp(Number(a.zone_rate) / maxRate, 0.45, 1) : 0.6;
    const f = (TYPE_SENSITIVITY[a.asset_type] ?? 1) * zone;
    const cur = current * f;
    const pred = cur + net * f;
    return {
      asset_id: a.id, name: a.name, asset_type: a.asset_type, lat: a.lat, lon: a.lon,
      current_m: round(cur, 2), predicted_m: round(pred, 2),
      low_m: round(Math.max(cur, pred - bandEnd * f), 2), high_m: round(pred + bandEnd * f, 2),
      risk: riskClass(pred),
    };
  });
  const riskCounts = { LOW: 0, MODERATE: 0, HIGH: 0 };
  assetResults.forEach((r) => { riskCounts[r.risk] += 1; });

  // ---- resources for the scheduling team
  const heavy = clamp(Math.ceil(net / HEAVY_NET_M), 1, 6);
  const light = clamp(Math.ceil(net * LIGHT_PER_NET_M), 1, 12);
  const people = BASE_PEOPLE + PEOPLE_PER_HEAVY * heavy + Math.ceil(light / LIGHT_PER_PERSON);

  const preds = assetResults.map((r) => r.predicted_m);
  return {
    window_start: isoDay(start),
    window_end: isoDay(new Date(start.getTime() + days * MS_DAY)),
    window_days: days,
    current_accum_m: round(current),
    predicted_accum_m: round(cHyb),
    net_accum_m: round(net),
    risk_level: riskClass(cHyb),
    confidence_pct: confidence,
    risk_counts: riskCounts,
    asset_results: assetResults,
    model_results: [
      { key: 'cnn_lstm', label: 'CNN-LSTM', predicted_accum_m: round(cMl), net_accum_m: round(cMl - current) },
      { key: 'physics', label: 'Physics-only', predicted_accum_m: round(cPhys), net_accum_m: round(cPhys - current) },
      { key: 'hybrid', label: 'Hybrid', predicted_accum_m: round(cHyb), net_accum_m: round(net) },
    ],
    series,
    metrics: {
      mean_predicted_m: round(preds.length ? preds.reduce((a, b) => a + b, 0) / preds.length : cHyb, 2),
      peak_predicted_m: round(preds.length ? Math.max(...preds) : cHyb, 2),
      avg_daily_rate_mm: round((net / days) * 1000, 1),
      band_m: round(bandEnd, 2),
    },
    resources: { people, heavy_units: heavy, light_units: light },
  };
}

module.exports = { runSandPrediction, riskClass, HIGH_AT_M, MODERATE_AT_M };
