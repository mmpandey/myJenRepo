// ---------------------------------------------------------------------------
// Operational planning / decision support.
//
// Turns one stored prediction run (prediction_sites: risk, sand volume,
// dune movement, confidence) into answers to four questions:
//   1. What is going to happen?          -> forecast digest
//   2. Which site needs attention first? -> priority score, rank and tier
//   3. When should the team go?          -> capacity-constrained day-by-day schedule
//   4. Who and what should be deployed?  -> crew, equipment and vehicle recommendation
//
// Scheduling is OURS. The prediction API's own schedule / team / equipment /
// scheduling objects are never read: only the prediction numbers are inputs,
// and crews, equipment and bookings come from this application's tables.
// Everything here is pure and deterministic (no I/O) so it can be tested alone.
// ---------------------------------------------------------------------------
const num = (v, d) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number(v));

const CONFIG = {
  shiftStart: process.env.PLAN_SHIFT_START || '07:00', // crews leave the depot
  shiftHours: num(process.env.PLAN_SHIFT_HOURS, 10),   // length of a working day, travel included
  speedKmh: num(process.env.PLAN_SPEED_KMH, 60),       // average road speed
  detour: num(process.env.PLAN_DETOUR_FACTOR, 1.3),    // road distance = straight line x detour
  heavyM3PerHour: num(process.env.PLAN_HEAVY_M3_PER_HOUR, 40), // sand moved per heavy unit per hour
  lightM3PerHour: num(process.env.PLAN_LIGHT_M3_PER_HOUR, 15), // light-equipment-only job
  minChunkHours: 1.5,                                   // smallest slice of a job worth driving out for
  volumeRefM3: num(process.env.PLAN_VOLUME_REF_M3, 500), // deposition that earns the full volume score
  tiers: { p1: 60, p2: 40, p3: 20 },                    // score thresholds
};

const RISK_POINTS = { HIGH: 40, MODERATE: 24, LOW: 8 };
const TIER = {
  P1: { label: 'Act now', rank: 1, deadlineDays: 1 },
  P2: { label: 'Plan this week', rank: 2, deadlineDays: 3 },
  P3: { label: 'Routine, when capacity allows', rank: 3, deadlineDays: null },
  P4: { label: 'Monitor only', rank: 4, deadlineDays: null },
};

const round = (v, d = 1) => Math.round(v * 10 ** d) / 10 ** d;
const iso = (d) => d.toISOString().slice(0, 10);
const addDays = (isoDate, n) => iso(new Date(new Date(`${isoDate}T00:00:00Z`).getTime() + n * 86400000));
const normRisk = (r) => String(r || '').trim().toUpperCase();

function haversineKm(a, b) {
  const R = 6371, rad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * rad, dLon = (b.lon - a.lon) * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
const roadKm = (a, b, c) => haversineKm(a, b) * c.detour;
const travelH = (a, b, c) => roadKm(a, b, c) / c.speedKmh;
const clock = (startHHMM, offsetH) => {
  const [h, m] = startHHMM.split(':').map(Number);
  const t = Math.round((h * 60 + m + offsetH * 60));
  return `${String(Math.floor(t / 60) % 24).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`;
};
const compass = (deg) => ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round((((deg % 360) + 360) % 360) / 45) % 8];

// ---- 2. priority --------------------------------------------------------
function scoreSite(s, cfg) {
  const risk = normRisk(s.risk_level);
  const vol = Number(s.sand_deposition_expected_m3 ?? s.sand_deposition_m3 ?? 0) || 0;
  const intensity = Number(s.dune_intensity_pct ?? 0) || 0;
  const conf = Number(s.confidence_pct ?? 0) || 0;
  const net = Number(s.net_accumulation_m ?? 0) || 0;
  const parts = [
    { key: 'risk', points: RISK_POINTS[risk] ?? 0, max: 40, text: `${risk || 'Unknown'} risk` },
    { key: 'volume', points: 25 * Math.min(1, vol / cfg.volumeRefM3), max: 25, text: `${Math.round(vol)} m³ expected` },
    { key: 'movement', points: 15 * Math.min(1, intensity / 100), max: 15, text: `dune movement ${round(intensity)}%` },
    { key: 'confidence', points: 10 * Math.min(1, conf / 100), max: 10, text: `${round(conf)}% confidence` },
    { key: 'growth', points: (net > 0 ? 5 : 0) + (s.observed_movement_detected ? 5 : 0), max: 10,
      text: [net > 0 ? 'depth still rising' : null, s.observed_movement_detected ? 'movement observed' : null].filter(Boolean).join(', ') },
  ];
  const score = round(parts.reduce((a, p) => a + p.points, 0));
  const tier = score >= cfg.tiers.p1 ? 'P1' : score >= cfg.tiers.p2 ? 'P2' : score >= cfg.tiers.p3 ? 'P3' : 'P4';
  return { score, tier, parts: parts.map((p) => ({ ...p, points: round(p.points) })), vol, risk };
}

// ---- 4. what to send ----------------------------------------------------
// Rule table: how much equipment a job of this size needs. A crew may hold at
// most 2 heavy units (same rule as the Equipment page), so the table stops at 2
// and bigger jobs simply take more working hours.
function deploymentRule(vol, risk) {
  let heavy, light, items;
  if (vol < 100) { heavy = 0; light = 3; items = ['Skid-steer', 'Sweeper', 'Pickup']; }
  else if (vol < 300) { heavy = 1; light = 1; items = ['Bulldozer', 'Pickup']; }
  else { heavy = 2; light = 1; items = ['Bulldozer', 'Wheel loader', 'Pickup']; }
  if (risk === 'HIGH') { light += 1; items = [...items, 'ATV (survey)']; }
  return { heavy, light, items, people: 1 + heavy + light }; // supervisor + one operator / driver per unit
}
function workHours(vol, rule, cfg) {
  const rate = rule.heavy > 0 ? rule.heavy * cfg.heavyM3PerHour : cfg.lightM3PerHour;
  return Math.max(1, Math.ceil((vol / rate) * 4) / 4);
}

// ---- main ---------------------------------------------------------------
function buildPlan({ run, sites, crews, equipment = [], bookings = [], trend = [], legacy = {}, config = {} }) {
  const cfg = { ...CONFIG, ...config };
  const start = String(run.start_date).slice(0, 10), end = String(run.end_date).slice(0, 10);
  const days = Math.max(1, Math.round((new Date(end) - new Date(start)) / 86400000));

  // 2. rank
  const ranked = sites
    .filter((s) => s.lat != null && s.lon != null)
    .map((s) => {
      const sc = scoreSite(s, cfg);
      const rule = deploymentRule(sc.vol, sc.risk);
      const ids = legacy[s.site_name] || {};
      return {
        site_name: s.site_name, lat: Number(s.lat), lon: Number(s.lon), risk: sc.risk, score: sc.score, tier: sc.tier,
        tier_label: TIER[sc.tier].label, volume_m3: round(sc.vol), confidence_pct: s.confidence_pct == null ? null : Number(s.confidence_pct),
        intensity_pct: s.dune_intensity_pct == null ? null : Number(s.dune_intensity_pct),
        direction_deg: s.dune_direction_deg == null ? null : Number(s.dune_direction_deg),
        range_m3: { low: s.sand_deposition_low_m3 == null ? null : Number(s.sand_deposition_low_m3), high: s.sand_deposition_high_m3 == null ? null : Number(s.sand_deposition_high_m3) },
        score_parts: sc.parts, reasons: sc.parts.filter((p) => p.points > 0).sort((a, b) => b.points - a.points).slice(0, 3).map((p) => p.text),
        deployment: { ...rule, work_hours: workHours(sc.vol, rule, cfg) },
        target_by: TIER[sc.tier].deadlineDays == null ? (TIER[sc.tier].rank <= 3 ? end : null) : addDays(start, TIER[sc.tier].deadlineDays),
        site_id: ids.site_id ?? null, asset_id: ids.asset_id ?? null,
      };
    })
    .sort((a, b) => b.score - a.score || b.volume_m3 - a.volume_m3 || a.site_name.localeCompare(b.site_name, undefined, { numeric: true }))
    .map((s, i) => ({ ...s, rank: i + 1 }));

  // 3. schedule: crew by crew, day by day, highest tier first, nearest job next
  const crewList = crews
    .filter((c) => c.status !== 'OFF_DUTY' && c.lat != null && c.lon != null)
    .map((c) => ({ ...c, firstDay: c.status === 'DISPATCHED' ? 1 : 0, lat: Number(c.lat), lon: Number(c.lon) }));
  const jobs = new Map(ranked.filter((s) => s.tier !== 'P4').map((s) => [s.site_name, { s, left: s.deployment.work_hours, first: null, last: null }]));
  const stops = [];
  const dayRows = [];
  for (let d = 0; d < days; d++) {
    const date = addDays(start, d);
    let usedHours = 0, crewsWorking = 0, capacity = 0;
    for (const crew of crewList) {
      if (d < crew.firstDay) continue;
      capacity += cfg.shiftHours;
      let pos = { lat: crew.lat, lon: crew.lon }, used = 0, n = 0;
      for (;;) {
        const open = [...jobs.values()].filter((j) => j.left > 0 && !(j.busyDate === date && j.busyCrew !== crew.id)); // one crew per site per day
        if (!open.length) break;
        // tiers in order, nearest-adjusted score first inside a tier, until something fits
        const order = open.sort((a, b) => TIER[a.s.tier].rank - TIER[b.s.tier].rank
          || (-a.s.score + 0.15 * haversineKm(pos, a.s)) - (-b.s.score + 0.15 * haversineKm(pos, b.s)));
        let picked = null;
        for (const j of order) {
          const tin = travelH(pos, j.s, cfg), tback = travelH(j.s, crew, cfg);
          const room = cfg.shiftHours - used - tin - tback;
          if (room >= j.left) { picked = { j, tin, tback, work: j.left }; break; }
          // a job is only split across shifts when this crew could never finish it in one go
          const fresh = cfg.shiftHours - travelH(crew, j.s, cfg) - tback;
          if (used === 0 && j.left > fresh && room >= cfg.minChunkHours) { picked = { j, tin, tback, work: Math.floor(Math.min(room, j.left) * 4) / 4 }; break; }
        }
        if (!picked) break;
        const { j, tin, work } = picked;
        const arrive = used + tin;
        stops.push({
          date, day: d + 1, crew_id: crew.id, crew_name: crew.name, site_name: j.s.site_name, rank: j.s.rank, tier: j.s.tier,
          depart: clock(cfg.shiftStart, used), arrive: clock(cfg.shiftStart, arrive), finish: clock(cfg.shiftStart, arrive + work),
          travel_km: round(roadKm(pos, j.s, cfg)), travel_h: round(tin, 2), work_h: round(work, 2), finishes_site: work >= j.left,
          order: n + 1,
        });
        j.busyDate = date; j.busyCrew = crew.id; j.first = j.first || date; j.left = round(j.left - work, 2); if (j.left <= 0.001) { j.left = 0; j.last = date; }
        used = arrive + work; pos = { lat: j.s.lat, lon: j.s.lon }; n += 1;
      }
      if (n) {
        const back = travelH(pos, crew, cfg);
        used += back; crewsWorking += 1; usedHours += used;
      }
    }
    dayRows.push({ date, day: d + 1, crews_working: crewsWorking, hours_used: round(usedHours), hours_capacity: round(capacity), utilisation_pct: capacity ? Math.round((usedHours / capacity) * 100) : 0 });
  }

  // 4b. crew-level deployment: what each crew needs vs what it holds, filled from the yard
  const bookedIds = new Set(bookings.map((b) => b.equipment_id));
  const yard = { HEAVY: [], LIGHT: [] };
  equipment.filter((e) => !e.crew_id && e.status === 'AVAILABLE' && !bookedIds.has(e.id)).forEach((e) => yard[e.equipment_class]?.push(e));
  const siteByName = new Map(ranked.map((s) => [s.site_name, s]));
  const crewPlans = crewList.map((c) => {
    const mine = stops.filter((s) => s.crew_id === c.id);
    const needHeavy = Math.max(0, ...mine.map((s) => siteByName.get(s.site_name).deployment.heavy));
    const needLight = Math.max(0, ...mine.map((s) => siteByName.get(s.site_name).deployment.light));
    const own = equipment.filter((e) => e.crew_id === c.id && e.status === 'AVAILABLE');
    const haveHeavy = own.filter((e) => e.equipment_class === 'HEAVY').length;
    const haveLight = own.filter((e) => e.equipment_class === 'LIGHT').length;
    const pull = (cls, n) => yard[cls].splice(0, Math.max(0, n)).map((e) => ({ id: e.id, unit_code: e.unit_code, name: e.name, type: e.type_name || null }));
    const addHeavy = pull('HEAVY', Math.min(needHeavy - haveHeavy, 2 - haveHeavy));
    const addLight = pull('LIGHT', needLight - haveLight);
    const hours = mine.reduce((a, s) => a + s.work_h + s.travel_h, 0);
    const peopleNeeded = Math.max(0, ...mine.map((s) => siteByName.get(s.site_name).deployment.people));
    return {
      crew_id: c.id, crew_name: c.name, status: c.status, specialty: c.specialty, base: c.base_location, headcount: c.headcount,
      stops: mine.length, sites: [...new Set(mine.map((s) => s.site_name))].length, busy_hours: round(hours),
      people_needed: peopleNeeded, understaffed: mine.length > 0 && c.headcount < peopleNeeded,
      equipment: { heavy_needed: needHeavy, heavy_have: haveHeavy, light_needed: needLight, light_have: haveLight,
        add_from_yard: [...addHeavy, ...addLight],
        shortfall_heavy: Math.max(0, needHeavy - haveHeavy - addHeavy.length), shortfall_light: Math.max(0, needLight - haveLight - addLight.length),
        assigned: own.map((e) => ({ id: e.id, unit_code: e.unit_code, name: e.name, class: e.equipment_class })) },
      first_stop: mine.sort((a, b) => a.day - b.day || a.order - b.order)[0] || null,
    };
  });

  // site results (when / who)
  const sitesOut = ranked.map((s) => {
    const j = jobs.get(s.site_name);
    const mine = stops.filter((x) => x.site_name === s.site_name);
    const scheduled = mine.length > 0;
    const complete = j ? j.left === 0 : false;
    const crewNames = [...new Set(mine.map((x) => x.crew_name))];
    return {
      ...s,
      plan: s.tier === 'P4' ? { status: 'MONITOR', note: 'Below the action threshold: watch the next forecast.' }
        : !scheduled ? { status: 'UNSCHEDULED', remaining_h: j.left, note: 'No crew hours left in this window.' }
        : { status: complete ? 'SCHEDULED' : 'PARTIAL', first_date: j.first, last_date: j.last, crews: crewNames,
            remaining_h: j.left, on_time: s.target_by ? j.first <= s.target_by : true, travel_km: mine[0].travel_km,
            note: complete ? null : 'Part of the work does not fit in this window.' },
    };
  });

  // 1. forecast digest
  const risk = run.risk_summary || {};
  const env = run.environmental_model || {};
  const volTotal = ranked.reduce((a, s) => a + s.volume_m3, 0);
  const action = sitesOut.filter((s) => s.tier !== 'P4');
  const peak = trend.length ? trend.reduce((m, t) => (Number(t.volume_m3) > Number(m.volume_m3) ? t : m), trend[0]) : null;
  const dir = env.dominant_wind_direction_deg ?? (ranked.find((s) => s.direction_deg != null) || {}).direction_deg ?? null;
  const unsched = sitesOut.filter((s) => s.plan.status === 'UNSCHEDULED' || s.plan.status === 'PARTIAL');
  const hoursNeeded = round([...jobs.values()].reduce((a, j) => a + j.s.deployment.work_hours, 0));
  const hoursLeft = round([...jobs.values()].reduce((a, j) => a + j.left, 0));
  const capacityH = dayRows.reduce((a, d) => a + d.hours_capacity, 0);
  const top = ranked[0];
  const firstDay = dayRows.find((d) => d.crews_working > 0);
  const answers = {
    what: `${risk.high ?? 0} High, ${risk.moderate ?? 0} Moderate and ${risk.low ?? 0} Low risk sites. About ${Math.round(volTotal).toLocaleString('en-US')} m³ of sand is expected to deposit between ${start} and ${end}`
      + (dir != null ? `, driven by wind from ${Math.round(dir)}° (${compass(dir)})` : '') + '.',
    first: top ? `${top.site_name} comes first (score ${top.score}, ${top.tier_label.toLowerCase()}); ${action.length} of ${ranked.length} sites need action in this window.` : 'No sites in this run.',
    when: firstDay ? `Crews start on ${firstDay.date}; ${action.length - unsched.length} of ${action.length} sites fit the ${days}-day window${unsched.length ? `, ${unsched.length} need more crew time` : ''}.` : 'No crew is available to schedule.',
    who: `${crewList.length} crew${crewList.length === 1 ? '' : 's'} available; ${crewPlans.filter((c) => c.equipment.add_from_yard.length).length} need units added from the yard${crewPlans.some((c) => c.equipment.shortfall_heavy || c.equipment.shortfall_light) ? ', and some equipment is short' : ''}.`,
  };
  return {
    run: { run_id: run.run_id, start_date: start, end_date: end, source: run.source, created_date: run.created_date },
    assumptions: {
      shift: `${cfg.shiftStart} for ${cfg.shiftHours} h, travel included`, speed_kmh: cfg.speedKmh, detour_factor: cfg.detour,
      heavy_m3_per_hour: cfg.heavyM3PerHour, light_m3_per_hour: cfg.lightM3PerHour, volume_ref_m3: cfg.volumeRefM3, tiers: cfg.tiers,
      note: 'Travel is a straight-line estimate x detour factor; the real road route and ETA are fetched when a crew is dispatched. Crews, equipment and bookings come from this application; the prediction API schedule is ignored.',
    },
    forecast: {
      sites: ranked.length, risk_summary: { low: risk.low ?? 0, moderate: risk.moderate ?? 0, high: risk.high ?? 0, unavailable: risk.unavailable ?? 0 },
      total_volume_m3: round(volTotal), sites_with_observed_movement: sites.filter((s) => s.observed_movement_detected).length,
      wind: { direction_deg: dir, compass: dir == null ? null : compass(dir), mean_speed_ms: env.mean_wind_speed_ms ?? null, max_gust_ms: env.max_wind_gust_ms ?? null, transport_hours_pct: env.sand_transport_active_hours_pct ?? null },
      trend: trend.map((t) => ({ date: String(t.date).slice(0, 10), volume_m3: Number(t.volume_m3) })), peak_day: peak ? String(peak.date).slice(0, 10) : null,
      tiers: Object.fromEntries(['P1', 'P2', 'P3', 'P4'].map((t) => [t, sitesOut.filter((s) => s.tier === t).length])),
    },
    answers,
    sites: sitesOut, schedule: { days: dayRows, stops }, crews: crewPlans,
    crew_bases: Object.fromEntries(crewList.map((c) => [c.id, { lat: c.lat, lon: c.lon }])),
    capacity: { hours_needed: hoursNeeded, hours_scheduled: round(hoursNeeded - hoursLeft), hours_unscheduled: hoursLeft, hours_capacity: round(capacityH),
      extra_crew_days: Math.ceil(hoursLeft / Math.max(1, cfg.shiftHours - 4)), unscheduled_sites: unsched.length },
  };
}

module.exports = { buildPlan, scoreSite, deploymentRule, CONFIG };
