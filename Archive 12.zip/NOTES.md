# Planning-driven decision support: delivery notes (2026-11-11)

Built on the `aramco-dune-portal` code in `files111126.zip` (previous 8 rounds kept unchanged).

## What was added
- **Planning page** `/planning` answering: what will happen / which site first / when to go / who and what to send.
- **`backend/planning.js`**: priority scoring, tiers, capacity-constrained crew schedule, equipment and vehicle recommendation (pure, deterministic).
- **`GET /api/planning/plan`**: computed on demand from the latest run + current crews, equipment, bookings. No schema change.
- **Prediction API scheduling ignored:** `schedule` (per site) and `scheduling` (top level) are dropped as soon as the response arrives, so they are never stored or shown.
- **Mock updated** to the 53-site sample from `modal-output.json`, schedule objects removed.
- `docs/PLANNING.md` has the rules and API.

## Tested
Against PostgreSQL-compatible PGlite with PostGIS (not stock PostgreSQL): schema loads, Run Prediction stores 53 sites and no scheduling data, planning endpoint returns 53 ranked sites, bad/unknown run id give 400/404, a work order created from a plan row returns 201. Frontend builds, and the Planning page renders with zero console errors in a browser (the map tile server is reachable only with internet).

## Please note
- The prompt document ended after "ignore schedule/team/equipment fields", so the four questions were taken as the full requirement. If the client sent more detail (for example exact scoring weights or crew rates), send it and the rules in `planning.js` can be changed in one place.
- Rates, shift length, speed and score weights are **assumptions** (see docs/PLANNING.md).
- The sample prediction has no High risk site, so nothing reaches P1 in the demo; scores top out near 48.
- Sample crews are about 150 km from the sample sites, so travel takes much of each shift and some sites do not fit in 7 days. That is a data property, and the page shows it as extra crew-days needed.


## Update 2026-11-12: API schedule, people and equipment now used
- Prediction API `scheduling`, per-site `schedule`, crew resources and routes are kept and used by `/api/planning/plan` (see docs/PLANNING.md, last section). The earlier "ignored" behaviour is removed.
- Ranking (score, P1-P4) is still computed here. Local scheduler stays as fallback when the API sends no `scheduling`.
- Added `Synthetic Crew 1-6` (6 people, 1 bulldozer, 1 wheel loader, 2 pickups each) to `database/schema.sql` so API crews map to real crews and equipment. Earlier 8 extra crews kept.
- Planning page: schedule table from the API, crew cards show API kit vs actual equipment, map shows the API's full road route for the selected crew.
- Tested on PGlite+PostGIS: 53 of 53 sites scheduled by the API plan, 3 crews matched, no equipment shortfall. Not tested on stock PostgreSQL or the live API.
