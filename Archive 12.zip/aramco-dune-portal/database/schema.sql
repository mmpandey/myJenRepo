-- ============================================================================
-- Saudi Aramco - Dune Dynamix Program
-- Phase 4: Integration & Decision Support Portal
-- PostgreSQL / PostGIS schema — v2 (routing, audit trail, workload)
-- ============================================================================
CREATE EXTENSION IF NOT EXISTS postgis;

DROP TABLE IF EXISTS prediction_sites CASCADE;
DROP TABLE IF EXISTS prediction_runs CASCADE;
DROP TABLE IF EXISTS prediction_crews CASCADE;
DROP TABLE IF EXISTS equipment_schedules CASCADE;
DROP TABLE IF EXISTS equipment_assignments CASCADE;
DROP TABLE IF EXISTS equipment CASCADE;
DROP TABLE IF EXISTS equipment_types CASCADE;
DROP TABLE IF EXISTS sand_predictions CASCADE;
DROP TABLE IF EXISTS crew_location_pings CASCADE;
DROP TABLE IF EXISTS push_subscriptions CASCADE;
DROP TABLE IF EXISTS work_order_events CASCADE;
DROP TABLE IF EXISTS work_orders CASCADE;
DROP TABLE IF EXISTS assets CASCADE;
DROP TABLE IF EXISTS sites CASCADE;
DROP TABLE IF EXISTS dune_forecasts CASCADE;
DROP TABLE IF EXISTS crews CASCADE;

-- ----------------------------------------------------------------------------
-- 0. Sites — the unit a user selects on the Prediction page. The three numeric
--    parameters feed the prediction engine (backend/prediction.js).
-- ----------------------------------------------------------------------------
CREATE TABLE sites (
    id                   SERIAL PRIMARY KEY,
    code                 VARCHAR(20) UNIQUE NOT NULL,
    name                 VARCHAR(120) NOT NULL,
    region               VARCHAR(80),
    geom                 GEOMETRY(Point, 4326) NOT NULL,
    baseline_accum_m     NUMERIC(5,2) NOT NULL DEFAULT 0.5,   -- sand depth measured today (m)
    wind_drift_potential NUMERIC(6,1) NOT NULL DEFAULT 300,
    sand_supply_index    NUMERIC(3,2) NOT NULL DEFAULT 0.5,   -- 0 armoured surface .. 1 loose dune sand
    sort_order           INT                                  -- display order of the master list
);

-- ----------------------------------------------------------------------------
-- 1. Infrastructure assets (pipelines, wellheads, gathering stations, roads)
-- ----------------------------------------------------------------------------
CREATE TABLE assets (
    id          SERIAL PRIMARY KEY,
    site_id     INT REFERENCES sites(id),
    name        VARCHAR(120) NOT NULL,
    asset_type  VARCHAR(50) NOT NULL CHECK (asset_type IN ('PIPELINE', 'FACILITY', 'WELLHEAD', 'ROAD')),
    criticality VARCHAR(20) NOT NULL DEFAULT 'STANDARD' CHECK (criticality IN ('STANDARD', 'CRITICAL')),
    geom        GEOMETRY(Point, 4326) NOT NULL,
    UNIQUE (site_id, name)   -- lets the AI-backend sync upsert a representative asset per site, never duplicate it
);

-- ----------------------------------------------------------------------------
-- 2. Phase 3 dune-movement forecast polygons (risk zones), carried into Phase 4
-- ----------------------------------------------------------------------------
CREATE TABLE dune_forecasts (
    id             SERIAL PRIMARY KEY,
    forecast_date  DATE NOT NULL DEFAULT CURRENT_DATE,
    risk_level     VARCHAR(20) NOT NULL CHECK (risk_level IN ('HIGH', 'MEDIUM', 'LOW')),
    encroach_rate_m_per_yr NUMERIC(6,2),   -- dune migration rate feeding the business rules
    geom           GEOMETRY(Polygon, 4326) NOT NULL
);

-- ----------------------------------------------------------------------------
-- 3. Mitigation crews available for dispatch — geolocated for routing, with a
--    vehicle engine ID, a live GPS position, and a simple access PIN so crews
--    can identify themselves from one shared app URL instead of unique links.
-- ----------------------------------------------------------------------------
CREATE TABLE crews (
    id             SERIAL PRIMARY KEY,
    name           VARCHAR(120) NOT NULL,
    specialty      VARCHAR(50) NOT NULL CHECK (specialty IN ('PIPELINE', 'FACILITY', 'WELLHEAD', 'GENERAL')),
    status         VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE', 'DISPATCHED', 'OFF_DUTY')),
    base_location  VARCHAR(120),
    geom           GEOMETRY(Point, 4326),      -- home base / depot, used until a live GPS ping arrives
    engine_id      VARCHAR(40) NOT NULL,       -- vehicle engine ID, for asset/fleet traceability
    access_code    CHAR(4) NOT NULL,           -- PIN a crew enters to identify themselves at the shared URL
    live_lat       DOUBLE PRECISION,           -- most recent GPS position reported by the crew's phone
    live_lon       DOUBLE PRECISION,
    live_heading   DOUBLE PRECISION,           -- direction of travel in degrees (0=N), when the phone's GPS provides one
    last_ping_at   TIMESTAMP,                  -- when that position was last reported; NULL = never reported
    headcount      INT NOT NULL DEFAULT 3      -- people on the crew; used to size the scheduling team
);

-- ----------------------------------------------------------------------------
-- 3a. Equipment. HEAVY (dozers, loaders, graders, excavators) and LIGHT (pickups,
--     skid-steers, water bowsers, trailers, ATVs). Created and managed on the
--     Equipment page, assigned to one crew at a time from the Equipment or
--     Scheduling Team pages; crew_id NULL means it sits in the yard.
--     Service dates drive the "service overdue" flag; every assignment change is
--     recorded in equipment_assignments so usage can be tracked.
-- ----------------------------------------------------------------------------
-- Reference table: the equipment types offered on the Equipment form (per class).
CREATE TABLE equipment_types (
    id              SERIAL PRIMARY KEY,
    equipment_class VARCHAR(10) NOT NULL CHECK (equipment_class IN ('HEAVY', 'LIGHT')),
    type_name       VARCHAR(50) NOT NULL,
    UNIQUE (equipment_class, type_name)
);

CREATE TABLE equipment (
    id               SERIAL PRIMARY KEY,
    unit_code        VARCHAR(30) UNIQUE NOT NULL,
    name             VARCHAR(120) NOT NULL,
    equipment_class  VARCHAR(10) NOT NULL CHECK (equipment_class IN ('HEAVY', 'LIGHT')),
    equipment_type   VARCHAR(50) NOT NULL,
    make_model       VARCHAR(120),
    status           VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE', 'MAINTENANCE', 'RETIRED')),
    last_service_on  DATE,
    next_service_due DATE,
    notes            TEXT,
    crew_id          INT REFERENCES crews(id) ON DELETE SET NULL,
    created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE equipment_assignments (
    id           SERIAL PRIMARY KEY,
    equipment_id INT NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    crew_id      INT REFERENCES crews(id) ON DELETE SET NULL,
    crew_name    VARCHAR(120) NOT NULL,        -- snapshot, survives crew renames / deletes
    assigned_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    released_at  TIMESTAMP,                    -- NULL = currently assigned
    release_note VARCHAR(200)
);

-- Equipment scheduling: a unit is booked for a date range (optionally for a crew and a site).
-- Bookings of the same unit may not overlap (checked by the API inside a transaction).
CREATE TABLE equipment_schedules (
    id           SERIAL PRIMARY KEY,
    equipment_id INT NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    crew_id      INT REFERENCES crews(id) ON DELETE SET NULL,
    site_id      INT REFERENCES sites(id) ON DELETE SET NULL,
    start_date   DATE NOT NULL,
    end_date     DATE NOT NULL,
    purpose      VARCHAR(200),
    status       VARCHAR(20) NOT NULL DEFAULT 'SCHEDULED' CHECK (status IN ('SCHEDULED', 'COMPLETED', 'CANCELLED')),
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (end_date >= start_date)
);

-- ----------------------------------------------------------------------------
-- 3b. Recent GPS breadcrumb trail per crew — a rolling window (trimmed on
--     write), not a full history table. Powers the fading trail line behind
--     a moving crew on the dispatcher's map.
-- ----------------------------------------------------------------------------
CREATE TABLE crew_location_pings (
    id          SERIAL PRIMARY KEY,
    crew_id     INT NOT NULL REFERENCES crews(id) ON DELETE CASCADE,
    lat         DOUBLE PRECISION NOT NULL,
    lon         DOUBLE PRECISION NOT NULL,
    recorded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------------------------
-- 3c. Prediction runs. One row per "Run Prediction" for a site; stores the model
--     comparison, the trend series, per-asset (block) results and the resources
--     the scheduling team needs (people, heavy and light equipment units).
-- ----------------------------------------------------------------------------
CREATE TABLE sand_predictions (
    id                SERIAL PRIMARY KEY,
    site_id           INT NOT NULL REFERENCES sites(id),
    run_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    window_start      DATE NOT NULL,
    window_end        DATE NOT NULL,
    window_days       INT NOT NULL,
    current_accum_m   NUMERIC(6,3) NOT NULL,
    predicted_accum_m NUMERIC(6,3) NOT NULL,
    net_accum_m       NUMERIC(6,3) NOT NULL,
    risk_level        VARCHAR(20) NOT NULL CHECK (risk_level IN ('HIGH', 'MODERATE', 'LOW')),
    confidence_pct    INT NOT NULL,
    risk_counts       JSONB NOT NULL,   -- {LOW, MODERATE, HIGH} assets/blocks
    asset_results     JSONB NOT NULL,   -- per asset: current / predicted / range / risk
    model_results     JSONB NOT NULL,   -- CNN-LSTM, Physics-only, Hybrid
    series            JSONB NOT NULL,   -- daily trend with uncertainty band
    metrics           JSONB NOT NULL,
    resources         JSONB NOT NULL    -- {people, heavy_units, light_units}
);

-- Crews chosen for a prediction's scheduling team (manual — nothing is dispatched from here)
CREATE TABLE prediction_crews (
    prediction_id INT NOT NULL REFERENCES sand_predictions(id) ON DELETE CASCADE,
    crew_id       INT NOT NULL REFERENCES crews(id) ON DELETE CASCADE,
    added_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (prediction_id, crew_id)
);

-- ----------------------------------------------------------------------------
-- 3d. Sand Accumulation Prediction — AI backend integration (Prediction page v2).
--     One row per "Run Prediction" click in prediction_runs (the run-level
--     risk summary, model metrics, and model descriptors), and one row per
--     site returned by that run in prediction_sites, upserted on
--     (site_name, window_start, window_end) so clicking Run Prediction again
--     for the same window updates in place instead of creating duplicates.
--     Independent of sites/assets above: these sites come from the external
--     AI Prediction Backend (or the prediction.json mock), not the 70-site
--     master list, and are not necessarily the same places.
--     IMPORTANT: the API response's per-site "schedule" object (team,
--     equipment, status) is deliberately never read or stored anywhere here —
--     per the "Final Prompt" spec, scheduling/crew/equipment/dispatch stays
--     entirely on the existing sand_predictions / crews / equipment tables
--     above, untouched by this integration.
-- ----------------------------------------------------------------------------
CREATE TABLE prediction_runs (
    run_id              SERIAL PRIMARY KEY,
    start_date          DATE NOT NULL,
    end_date            DATE NOT NULL,
    created_date        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status              VARCHAR(20) NOT NULL DEFAULT 'COMPLETED' CHECK (status IN ('RUNNING', 'COMPLETED', 'FAILED')),
    source              VARCHAR(10) NOT NULL DEFAULT 'api' CHECK (source IN ('api', 'mock')),
    risk_summary        JSONB,      -- {low, moderate, high, unavailable}
    model_metrics       JSONB,      -- {MAE, RMSE, R2, BIAS, ...}
    sand_model          JSONB,      -- {type, description}
    environmental_model JSONB,      -- {type, mean_wind_speed_ms, ...}
    raw_response        JSONB       -- full AI-backend/mock payload, kept for audit/debugging
);

CREATE TABLE prediction_sites (
    id                           SERIAL PRIMARY KEY,
    run_id                       INT NOT NULL REFERENCES prediction_runs(run_id) ON DELETE CASCADE,
    site_name                    VARCHAR(120) NOT NULL,
    risk_level                   VARCHAR(20),
    lat                          DOUBLE PRECISION,
    lon                          DOUBLE PRECISION,
    total_area_km2               NUMERIC(10,4),
    predicted_accumulation_m     NUMERIC(8,4),
    net_accumulation_m           NUMERIC(8,4),
    sand_deposition_m3           NUMERIC(12,2),
    sand_deposition_low_m3       NUMERIC(12,2),
    sand_deposition_expected_m3  NUMERIC(12,2),
    sand_deposition_high_m3      NUMERIC(12,2),
    confidence_pct                NUMERIC(5,2),
    dune_direction_deg           NUMERIC(6,2),
    dune_intensity_pct           NUMERIC(6,2),
    current_zone                 GEOMETRY(Polygon, 4326),
    predicted_zone                GEOMETRY(Polygon, 4326),
    accumulation_trend           JSONB,       -- [{date, value}, ...] — future-ready passthrough, not required by the API yet
    window_start                 DATE NOT NULL,   -- the run's own window (the API's "schedule" object is intentionally never read — see server.js)
    window_end                   DATE NOT NULL,
    created_at                   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (site_name, window_start, window_end)
);

-- ----------------------------------------------------------------------------
-- 4. Work orders: the output of the decision-support / business-rules engine.
--    Now carries the computed route from crew base to asset.
-- ----------------------------------------------------------------------------
CREATE TABLE work_orders (
    id                 SERIAL PRIMARY KEY,
    asset_id           INT NOT NULL REFERENCES assets(id),
    crew_id            INT REFERENCES crews(id),
    status             VARCHAR(20) NOT NULL DEFAULT 'OPEN'
                        CHECK (status IN ('OPEN', 'DISPATCHED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')),
    priority           VARCHAR(20) NOT NULL CHECK (priority IN ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW')),
    recommended_action TEXT,
    route_geometry     JSONB,          -- GeoJSON LineString from crew base to asset
    distance_km        NUMERIC(6,2),
    eta_minutes        INT,
    site_id            INT REFERENCES sites(id),
    flagged            BOOLEAN NOT NULL DEFAULT false,   -- crew-raised issue awaiting dispatcher attention
    flag_reason        TEXT,
    created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------------------------
-- 5. Work order audit trail — one row per status transition
-- ----------------------------------------------------------------------------
CREATE TABLE work_order_events (
    id            SERIAL PRIMARY KEY,
    work_order_id INT NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
    status        VARCHAR(20) NOT NULL,
    note          TEXT,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------------------------
-- 6. Web Push subscriptions — lets a crew's phone receive a real notification
--    even when the app tab is closed, once they tap "Enable alerts."
-- ----------------------------------------------------------------------------
CREATE TABLE push_subscriptions (
    id         SERIAL PRIMARY KEY,
    crew_id    INT NOT NULL REFERENCES crews(id) ON DELETE CASCADE,
    endpoint   TEXT NOT NULL UNIQUE,
    p256dh     TEXT NOT NULL,
    auth       TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Spatial indexes
CREATE INDEX idx_sites_geom ON sites USING GIST (geom);
CREATE INDEX idx_sites_sort ON sites (sort_order);
CREATE INDEX idx_assets_site ON assets (site_id);
CREATE INDEX idx_equipment_crew ON equipment (crew_id);
CREATE INDEX idx_equipment_schedules_unit ON equipment_schedules (equipment_id, start_date, end_date);
CREATE INDEX idx_equipment_schedules_site ON equipment_schedules (site_id);
CREATE INDEX idx_equipment_class_status ON equipment (equipment_class, status);
CREATE INDEX idx_equipment_assignments_equipment ON equipment_assignments (equipment_id, assigned_at DESC);
CREATE UNIQUE INDEX uq_equipment_open_assignment ON equipment_assignments (equipment_id) WHERE released_at IS NULL;
CREATE INDEX idx_sand_predictions_site ON sand_predictions (site_id, run_at DESC);
CREATE INDEX idx_prediction_runs_created ON prediction_runs (created_date DESC);
CREATE INDEX idx_prediction_sites_run ON prediction_sites (run_id);
CREATE INDEX idx_prediction_sites_name ON prediction_sites (site_name);
CREATE INDEX idx_prediction_sites_current_zone ON prediction_sites USING GIST (current_zone);
CREATE INDEX idx_prediction_sites_predicted_zone ON prediction_sites USING GIST (predicted_zone);
CREATE INDEX idx_work_orders_site ON work_orders (site_id);
CREATE INDEX idx_assets_geom ON assets USING GIST (geom);
CREATE INDEX idx_dune_forecasts_geom ON dune_forecasts USING GIST (geom);
CREATE INDEX idx_crews_geom ON crews USING GIST (geom);
CREATE INDEX idx_work_orders_asset ON work_orders (asset_id);
CREATE INDEX idx_work_orders_status ON work_orders (status);
CREATE INDEX idx_work_order_events_wo ON work_order_events (work_order_id);
CREATE INDEX idx_push_subscriptions_crew ON push_subscriptions (crew_id);
CREATE INDEX idx_crew_location_pings_crew ON crew_location_pings (crew_id, recorded_at);

-- ============================================================================
-- Sample data - Eastern Province, Saudi Arabia (Abqaiq / Ghawar / Safaniya area)
-- ============================================================================
-- sites / assets / dune_forecasts are intentionally NOT seeded here (2026-11-09).
-- They are populated dynamically from the AI Prediction Backend (or the
-- prediction.json mock) the first time someone clicks "Run Prediction" on
-- /prediction: backend/server.js's persistPredictionRun() upserts one `sites`
-- row and one representative `assets` row per site returned by that run (see
-- README "2026-11-09 — Prediction module enhancement"). Dashboard, Dispatch,
-- Work Orders and Equipment scheduling-by-site will show nothing until that
-- first run has happened. Crews and the equipment fleet below are seeded
-- independently of sites, so Crews/Equipment work immediately.


-- Crew depots, placed a short drive from their usual work area so routes are visible on the map
INSERT INTO crews (name, specialty, status, base_location, geom, engine_id, access_code, headcount) VALUES
('Sand Mitigation Team Alpha',   'PIPELINE', 'AVAILABLE', 'Abqaiq Field Depot',     ST_SetSRID(ST_MakePoint(49.9550, 26.2850), 4326), 'ENG-4471-PL', '1122', 4),
('Sand Mitigation Team Bravo',   'FACILITY', 'AVAILABLE', 'Safaniya Base Camp',     ST_SetSRID(ST_MakePoint(49.9650, 26.3350), 4326), 'ENG-5528-FC', '2233', 4),
('Wellhead Rapid Response Unit', 'WELLHEAD', 'AVAILABLE', 'Ghawar Operations Hub',  ST_SetSRID(ST_MakePoint(50.0300, 26.3050), 4326), 'ENG-6094-WH', '3344', 3),
('General Earthworks Crew 1',    'GENERAL',  'AVAILABLE', 'Shedgum Yard',           ST_SetSRID(ST_MakePoint(50.0200, 26.2800), 4326), 'ENG-7712-GN', '4455', 3),
('General Earthworks Crew 2',    'GENERAL',  'OFF_DUTY',  'Shedgum Yard',           ST_SetSRID(ST_MakePoint(50.0200, 26.2800), 4326), 'ENG-7713-GN', '5566', 3);


INSERT INTO equipment_types (equipment_class, type_name) VALUES
('HEAVY', 'Bulldozer'), ('HEAVY', 'Wheel loader'), ('HEAVY', 'Motor grader'), ('HEAVY', 'Excavator'), ('HEAVY', 'Dump truck'), ('HEAVY', 'Crane'),
('LIGHT', 'Pickup'), ('LIGHT', 'Skid-steer'), ('LIGHT', 'Water bowser'), ('LIGHT', 'Trailer'), ('LIGHT', 'ATV'), ('LIGHT', 'Generator'), ('LIGHT', 'Sweeper'), ('LIGHT', 'Utility vehicle');

-- Equipment (HEAVY / LIGHT). Some units start on crews, the rest wait in the yard to be assigned.
INSERT INTO equipment (unit_code, name, equipment_class, equipment_type, make_model, status, last_service_on, next_service_due, crew_id) VALUES
('HVY-D8-01',  'CAT D8 Bulldozer',               'HEAVY', 'Bulldozer',    'Caterpillar D8T',        'AVAILABLE',   CURRENT_DATE - 40,  CURRENT_DATE + 50,  1),
('HVY-WL-02',  'CAT 980 Wheel Loader',           'HEAVY', 'Wheel loader', 'Caterpillar 980M',       'AVAILABLE',   CURRENT_DATE - 25,  CURRENT_DATE + 65,  2),
('HVY-MG-03',  'CAT 140M Motor Grader',          'HEAVY', 'Motor grader', 'Caterpillar 140M',       'AVAILABLE',   CURRENT_DATE - 100, CURRENT_DATE - 10,  4),
('HVY-EX-04',  'CAT 336 Excavator',              'HEAVY', 'Excavator',    'Caterpillar 336',        'AVAILABLE',   CURRENT_DATE - 30,  CURRENT_DATE + 60,  NULL),
('HVY-WL-05',  'Komatsu WA470 Wheel Loader',     'HEAVY', 'Wheel loader', 'Komatsu WA470-8',        'MAINTENANCE', CURRENT_DATE - 5,   CURRENT_DATE + 3,   NULL),
('HVY-D6-06',  'CAT D6 Bulldozer',               'HEAVY', 'Bulldozer',    'Caterpillar D6T',        'AVAILABLE',   CURRENT_DATE - 60,  CURRENT_DATE + 30,  NULL),
('LGT-PU-01',  'Toyota Hilux Pickup',            'LIGHT', 'Pickup',       'Toyota Hilux 4x4',       'AVAILABLE',   CURRENT_DATE - 20,  CURRENT_DATE + 70,  1),
('LGT-PU-02',  'Toyota Hilux Pickup',            'LIGHT', 'Pickup',       'Toyota Hilux 4x4',       'AVAILABLE',   CURRENT_DATE - 22,  CURRENT_DATE + 68,  2),
('LGT-SS-03',  'Bobcat S650 Skid-steer',         'LIGHT', 'Skid-steer',   'Bobcat S650',            'AVAILABLE',   CURRENT_DATE - 35,  CURRENT_DATE + 55,  3),
('LGT-WB-04',  'Water Bowser 8,000 L',           'LIGHT', 'Water bowser', 'Isuzu FVR 8000 L',       'AVAILABLE',   CURRENT_DATE - 15,  CURRENT_DATE + 75,  4),
('LGT-TR-05',  'Sand-fence Trailer',             'LIGHT', 'Trailer',      'Custom flatbed trailer', 'AVAILABLE',   NULL,               NULL,               NULL),
('LGT-AT-06',  'Polaris ATV Survey Unit',        'LIGHT', 'ATV',          'Polaris Sportsman 570',  'AVAILABLE',   CURRENT_DATE - 45,  CURRENT_DATE + 45,  NULL),
('LGT-PU-07',  'Toyota Hilux Pickup',            'LIGHT', 'Pickup',       'Toyota Hilux 4x4',       'AVAILABLE',   CURRENT_DATE - 18,  CURRENT_DATE + 72,  NULL),
('LGT-SS-08',  'Bobcat S650 Skid-steer',         'LIGHT', 'Skid-steer',   'Bobcat S650',            'AVAILABLE',   CURRENT_DATE - 50,  CURRENT_DATE + 40,  NULL),
('LGT-GN-09',  'Mobile Generator / Light Tower', 'LIGHT', 'Generator',    'Atlas Copco QLT H20',    'AVAILABLE',   CURRENT_DATE - 70,  CURRENT_DATE + 20,  NULL),
('LGT-BL-10',  'Leaf Blower / Sand Sweeper',     'LIGHT', 'Sweeper',      'Stihl BR 800',           'AVAILABLE',   CURRENT_DATE - 12,  CURRENT_DATE + 78,  NULL);

-- Added: extra crews with depots next to the predicted-site area, so every site can be covered
INSERT INTO crews (name, specialty, status, base_location, geom, engine_id, access_code, headcount) VALUES
('Sand Response Crew 1', 'GENERAL', 'AVAILABLE', 'Dammam Rd North Depot', ST_SetSRID(ST_MakePoint(49.24, 25.52), 4326), 'ENG-8101-GN', '6611', 4),
('Sand Response Crew 2', 'GENERAL', 'AVAILABLE', 'Dammam Rd South Depot', ST_SetSRID(ST_MakePoint(49.24, 25.36), 4326), 'ENG-8102-GN', '6622', 4),
('Sand Response Crew 3', 'GENERAL', 'AVAILABLE', 'Central Staging Yard', ST_SetSRID(ST_MakePoint(49.3, 25.44), 4326), 'ENG-8103-GN', '6633', 4),
('Sand Response Crew 4', 'GENERAL', 'AVAILABLE', 'East Ridge Depot', ST_SetSRID(ST_MakePoint(49.37, 25.5), 4326), 'ENG-8104-GN', '6644', 4),
('Sand Response Crew 5', 'GENERAL', 'AVAILABLE', 'South East Depot', ST_SetSRID(ST_MakePoint(49.37, 25.37), 4326), 'ENG-8105-GN', '6655', 4),
('Sand Response Crew 6', 'GENERAL', 'AVAILABLE', 'West Ridge Depot', ST_SetSRID(ST_MakePoint(49.21, 25.45), 4326), 'ENG-8106-GN', '6666', 4),
('Sand Response Crew 7', 'GENERAL', 'AVAILABLE', 'North East Depot', ST_SetSRID(ST_MakePoint(49.32, 25.54), 4326), 'ENG-8107-GN', '6677', 4),
('Sand Response Crew 8', 'GENERAL', 'AVAILABLE', 'South Central Depot', ST_SetSRID(ST_MakePoint(49.3, 25.34), 4326), 'ENG-8108-GN', '6688', 4);

-- Added: each extra crew carries a full kit (2 heavy + pickup, skid-steer, sweeper, ATV)
INSERT INTO equipment (unit_code, name, equipment_class, equipment_type, make_model, status, last_service_on, next_service_due, crew_id) VALUES
('HVY-D6-C01', 'CAT D6 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D6T', 'AVAILABLE', CURRENT_DATE - 13, CURRENT_DATE + 86, 6),
('HVY-WL-C01', 'CAT 950 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 950 GC', 'AVAILABLE', CURRENT_DATE - 13, CURRENT_DATE + 86, 6),
('LGT-PU-C01', 'Toyota Hilux Pickup', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 13, CURRENT_DATE + 86, 6),
('LGT-SS-C01', 'Bobcat S650 Skid-steer', 'LIGHT', 'Skid-steer', 'Bobcat S650', 'AVAILABLE', CURRENT_DATE - 13, CURRENT_DATE + 86, 6),
('LGT-BL-C01', 'Leaf Blower / Sand Sweeper', 'LIGHT', 'Sweeper', 'Stihl BR 800', 'AVAILABLE', CURRENT_DATE - 13, CURRENT_DATE + 86, 6),
('LGT-AT-C01', 'Polaris ATV Survey Unit', 'LIGHT', 'ATV', 'Polaris Sportsman 570', 'AVAILABLE', CURRENT_DATE - 13, CURRENT_DATE + 86, 6),
('HVY-D6-C02', 'CAT D6 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D6T', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 82, 7),
('HVY-WL-C02', 'CAT 950 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 950 GC', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 82, 7),
('LGT-PU-C02', 'Toyota Hilux Pickup', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 82, 7),
('LGT-SS-C02', 'Bobcat S650 Skid-steer', 'LIGHT', 'Skid-steer', 'Bobcat S650', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 82, 7),
('LGT-BL-C02', 'Leaf Blower / Sand Sweeper', 'LIGHT', 'Sweeper', 'Stihl BR 800', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 82, 7),
('LGT-AT-C02', 'Polaris ATV Survey Unit', 'LIGHT', 'ATV', 'Polaris Sportsman 570', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 82, 7),
('HVY-D6-C03', 'CAT D6 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D6T', 'AVAILABLE', CURRENT_DATE - 19, CURRENT_DATE + 78, 8),
('HVY-WL-C03', 'CAT 950 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 950 GC', 'AVAILABLE', CURRENT_DATE - 19, CURRENT_DATE + 78, 8),
('LGT-PU-C03', 'Toyota Hilux Pickup', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 19, CURRENT_DATE + 78, 8),
('LGT-SS-C03', 'Bobcat S650 Skid-steer', 'LIGHT', 'Skid-steer', 'Bobcat S650', 'AVAILABLE', CURRENT_DATE - 19, CURRENT_DATE + 78, 8),
('LGT-BL-C03', 'Leaf Blower / Sand Sweeper', 'LIGHT', 'Sweeper', 'Stihl BR 800', 'AVAILABLE', CURRENT_DATE - 19, CURRENT_DATE + 78, 8),
('LGT-AT-C03', 'Polaris ATV Survey Unit', 'LIGHT', 'ATV', 'Polaris Sportsman 570', 'AVAILABLE', CURRENT_DATE - 19, CURRENT_DATE + 78, 8),
('HVY-D6-C04', 'CAT D6 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D6T', 'AVAILABLE', CURRENT_DATE - 22, CURRENT_DATE + 74, 9),
('HVY-WL-C04', 'CAT 950 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 950 GC', 'AVAILABLE', CURRENT_DATE - 22, CURRENT_DATE + 74, 9),
('LGT-PU-C04', 'Toyota Hilux Pickup', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 22, CURRENT_DATE + 74, 9),
('LGT-SS-C04', 'Bobcat S650 Skid-steer', 'LIGHT', 'Skid-steer', 'Bobcat S650', 'AVAILABLE', CURRENT_DATE - 22, CURRENT_DATE + 74, 9),
('LGT-BL-C04', 'Leaf Blower / Sand Sweeper', 'LIGHT', 'Sweeper', 'Stihl BR 800', 'AVAILABLE', CURRENT_DATE - 22, CURRENT_DATE + 74, 9),
('LGT-AT-C04', 'Polaris ATV Survey Unit', 'LIGHT', 'ATV', 'Polaris Sportsman 570', 'AVAILABLE', CURRENT_DATE - 22, CURRENT_DATE + 74, 9),
('HVY-D6-C05', 'CAT D6 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D6T', 'AVAILABLE', CURRENT_DATE - 25, CURRENT_DATE + 70, 10),
('HVY-WL-C05', 'CAT 950 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 950 GC', 'AVAILABLE', CURRENT_DATE - 25, CURRENT_DATE + 70, 10),
('LGT-PU-C05', 'Toyota Hilux Pickup', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 25, CURRENT_DATE + 70, 10),
('LGT-SS-C05', 'Bobcat S650 Skid-steer', 'LIGHT', 'Skid-steer', 'Bobcat S650', 'AVAILABLE', CURRENT_DATE - 25, CURRENT_DATE + 70, 10),
('LGT-BL-C05', 'Leaf Blower / Sand Sweeper', 'LIGHT', 'Sweeper', 'Stihl BR 800', 'AVAILABLE', CURRENT_DATE - 25, CURRENT_DATE + 70, 10),
('LGT-AT-C05', 'Polaris ATV Survey Unit', 'LIGHT', 'ATV', 'Polaris Sportsman 570', 'AVAILABLE', CURRENT_DATE - 25, CURRENT_DATE + 70, 10),
('HVY-D6-C06', 'CAT D6 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D6T', 'AVAILABLE', CURRENT_DATE - 28, CURRENT_DATE + 66, 11),
('HVY-WL-C06', 'CAT 950 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 950 GC', 'AVAILABLE', CURRENT_DATE - 28, CURRENT_DATE + 66, 11),
('LGT-PU-C06', 'Toyota Hilux Pickup', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 28, CURRENT_DATE + 66, 11),
('LGT-SS-C06', 'Bobcat S650 Skid-steer', 'LIGHT', 'Skid-steer', 'Bobcat S650', 'AVAILABLE', CURRENT_DATE - 28, CURRENT_DATE + 66, 11),
('LGT-BL-C06', 'Leaf Blower / Sand Sweeper', 'LIGHT', 'Sweeper', 'Stihl BR 800', 'AVAILABLE', CURRENT_DATE - 28, CURRENT_DATE + 66, 11),
('LGT-AT-C06', 'Polaris ATV Survey Unit', 'LIGHT', 'ATV', 'Polaris Sportsman 570', 'AVAILABLE', CURRENT_DATE - 28, CURRENT_DATE + 66, 11),
('HVY-D6-C07', 'CAT D6 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D6T', 'AVAILABLE', CURRENT_DATE - 31, CURRENT_DATE + 62, 12),
('HVY-WL-C07', 'CAT 950 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 950 GC', 'AVAILABLE', CURRENT_DATE - 31, CURRENT_DATE + 62, 12),
('LGT-PU-C07', 'Toyota Hilux Pickup', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 31, CURRENT_DATE + 62, 12),
('LGT-SS-C07', 'Bobcat S650 Skid-steer', 'LIGHT', 'Skid-steer', 'Bobcat S650', 'AVAILABLE', CURRENT_DATE - 31, CURRENT_DATE + 62, 12),
('LGT-BL-C07', 'Leaf Blower / Sand Sweeper', 'LIGHT', 'Sweeper', 'Stihl BR 800', 'AVAILABLE', CURRENT_DATE - 31, CURRENT_DATE + 62, 12),
('LGT-AT-C07', 'Polaris ATV Survey Unit', 'LIGHT', 'ATV', 'Polaris Sportsman 570', 'AVAILABLE', CURRENT_DATE - 31, CURRENT_DATE + 62, 12),
('HVY-D6-C08', 'CAT D6 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D6T', 'AVAILABLE', CURRENT_DATE - 34, CURRENT_DATE + 58, 13),
('HVY-WL-C08', 'CAT 950 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 950 GC', 'AVAILABLE', CURRENT_DATE - 34, CURRENT_DATE + 58, 13),
('LGT-PU-C08', 'Toyota Hilux Pickup', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 34, CURRENT_DATE + 58, 13),
('LGT-SS-C08', 'Bobcat S650 Skid-steer', 'LIGHT', 'Skid-steer', 'Bobcat S650', 'AVAILABLE', CURRENT_DATE - 34, CURRENT_DATE + 58, 13),
('LGT-BL-C08', 'Leaf Blower / Sand Sweeper', 'LIGHT', 'Sweeper', 'Stihl BR 800', 'AVAILABLE', CURRENT_DATE - 34, CURRENT_DATE + 58, 13),
('LGT-AT-C08', 'Polaris ATV Survey Unit', 'LIGHT', 'ATV', 'Polaris Sportsman 570', 'AVAILABLE', CURRENT_DATE - 34, CURRENT_DATE + 58, 13);

-- Added 2026-11-12: crews named like the prediction API's "Synthetic Crew N" (6 people; 1 dozer, 1 loader, 2 trucks each),
-- so the API schedule can be matched to real crews and equipment.
INSERT INTO crews (name, specialty, status, base_location, geom, engine_id, access_code, headcount) VALUES
('Synthetic Crew 1', 'GENERAL', 'AVAILABLE', 'Synthetic Camp Depot 1', ST_SetSRID(ST_MakePoint(49.27, 25.43), 4326), 'ENG-9101-SY', '7711', 6),
('Synthetic Crew 2', 'GENERAL', 'AVAILABLE', 'Synthetic Camp Depot 2', ST_SetSRID(ST_MakePoint(49.33, 25.45), 4326), 'ENG-9102-SY', '7722', 6),
('Synthetic Crew 3', 'GENERAL', 'AVAILABLE', 'Synthetic Camp Depot 3', ST_SetSRID(ST_MakePoint(49.31, 25.4), 4326), 'ENG-9103-SY', '7733', 6),
('Synthetic Crew 4', 'GENERAL', 'AVAILABLE', 'Synthetic Camp Depot 4', ST_SetSRID(ST_MakePoint(49.29, 25.49), 4326), 'ENG-9104-SY', '7744', 6),
('Synthetic Crew 5', 'GENERAL', 'AVAILABLE', 'Synthetic Camp Depot 5', ST_SetSRID(ST_MakePoint(49.25, 25.38), 4326), 'ENG-9105-SY', '7755', 6),
('Synthetic Crew 6', 'GENERAL', 'AVAILABLE', 'Synthetic Camp Depot 6', ST_SetSRID(ST_MakePoint(49.38, 25.47), 4326), 'ENG-9106-SY', '7766', 6);

INSERT INTO equipment (unit_code, name, equipment_class, equipment_type, make_model, status, last_service_on, next_service_due, crew_id) VALUES
('HVY-D8-S01', 'CAT D8 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D8T', 'AVAILABLE', CURRENT_DATE - 10, CURRENT_DATE + 77, 14),
('HVY-WL-S01', 'CAT 966 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 966M', 'AVAILABLE', CURRENT_DATE - 10, CURRENT_DATE + 77, 14),
('LGT-T1-S01', 'Support Truck A', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 10, CURRENT_DATE + 77, 14),
('LGT-T2-S01', 'Support Truck B', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 10, CURRENT_DATE + 77, 14),
('HVY-D8-S02', 'CAT D8 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D8T', 'AVAILABLE', CURRENT_DATE - 12, CURRENT_DATE + 74, 15),
('HVY-WL-S02', 'CAT 966 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 966M', 'AVAILABLE', CURRENT_DATE - 12, CURRENT_DATE + 74, 15),
('LGT-T1-S02', 'Support Truck A', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 12, CURRENT_DATE + 74, 15),
('LGT-T2-S02', 'Support Truck B', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 12, CURRENT_DATE + 74, 15),
('HVY-D8-S03', 'CAT D8 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D8T', 'AVAILABLE', CURRENT_DATE - 14, CURRENT_DATE + 71, 16),
('HVY-WL-S03', 'CAT 966 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 966M', 'AVAILABLE', CURRENT_DATE - 14, CURRENT_DATE + 71, 16),
('LGT-T1-S03', 'Support Truck A', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 14, CURRENT_DATE + 71, 16),
('LGT-T2-S03', 'Support Truck B', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 14, CURRENT_DATE + 71, 16),
('HVY-D8-S04', 'CAT D8 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D8T', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 68, 17),
('HVY-WL-S04', 'CAT 966 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 966M', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 68, 17),
('LGT-T1-S04', 'Support Truck A', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 68, 17),
('LGT-T2-S04', 'Support Truck B', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 16, CURRENT_DATE + 68, 17),
('HVY-D8-S05', 'CAT D8 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D8T', 'AVAILABLE', CURRENT_DATE - 18, CURRENT_DATE + 65, 18),
('HVY-WL-S05', 'CAT 966 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 966M', 'AVAILABLE', CURRENT_DATE - 18, CURRENT_DATE + 65, 18),
('LGT-T1-S05', 'Support Truck A', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 18, CURRENT_DATE + 65, 18),
('LGT-T2-S05', 'Support Truck B', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 18, CURRENT_DATE + 65, 18),
('HVY-D8-S06', 'CAT D8 Bulldozer', 'HEAVY', 'Bulldozer', 'Caterpillar D8T', 'AVAILABLE', CURRENT_DATE - 20, CURRENT_DATE + 62, 19),
('HVY-WL-S06', 'CAT 966 Wheel Loader', 'HEAVY', 'Wheel loader', 'Caterpillar 966M', 'AVAILABLE', CURRENT_DATE - 20, CURRENT_DATE + 62, 19),
('LGT-T1-S06', 'Support Truck A', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 20, CURRENT_DATE + 62, 19),
('LGT-T2-S06', 'Support Truck B', 'LIGHT', 'Pickup', 'Toyota Hilux 4x4', 'AVAILABLE', CURRENT_DATE - 20, CURRENT_DATE + 62, 19);

-- Assignment history for the units that start on a crew
INSERT INTO equipment_assignments (equipment_id, crew_id, crew_name, assigned_at)
SELECT e.id, e.crew_id, c.name, CURRENT_TIMESTAMP - INTERVAL '14 days' FROM equipment e JOIN crews c ON c.id = e.crew_id;

-- (Sample equipment bookings tied to the dummy site master list were removed 2026-11-09 —
--  equipment_schedules.site_id now only gets real rows once sites exist from a prediction run.)
