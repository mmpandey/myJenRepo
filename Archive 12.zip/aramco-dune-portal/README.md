# Dune Dynamix — Integration & Decision Support Portal (Phase 4)

A working POC that takes Phase 3 dune-forecast output, applies a business-rules
recommendation engine, finds the nearest available crew and the shortest road
route to a threatened asset, and lets ops teams create and track work orders —
including a mobile-friendly page crew members can open on their own phones via
a shareable link.

**Stack:** React (Vite) SPA + React Router · Node.js/Express API · PostgreSQL/PostGIS
· React-Leaflet + OpenStreetMap basemaps · GeoJSON layers from PostGIS · Turf.js (client-side only) · OSRM (open-source routing)

Tested end-to-end in a sandboxed environment: schema loads cleanly, every API
route was exercised (including the nearest-crew ranking, work-order dispatch
with route computation, and the crew-filtered mobile query), and `npm run build`
produces a clean production bundle.

## What this release adds

Same stack and structure as before (React + Vite, Node/Express, PostgreSQL/PostGIS, plain JavaScript). Nothing is auto-dispatched anywhere: the manual Dispatch workflow is unchanged.

**1. Sand Accumulation Prediction page** (`/prediction`) — **2026-11-09: rebuilt to run against the external AI Prediction Backend** (`POST /api/site-dashboard/production`, called server-side), with `prediction.json` as the automatic fallback when that backend is unreachable — no UI change either way (`PREDICTION_MODE` in `backend/.env` selects `auto` / `live` / `mock`). There is exactly **one** Run Prediction control and **one** site dropdown, both at the top of the page (a 7-day window always starting from the chosen start date) — one click covers every site the backend returns at once (not one site at a time), and every section on the page — map, drill-down, trend, Scheduling Team — always reflects whichever single site is selected there; no other section has a site picker of its own. Below it: a Risk summary (low/moderate/high/unavailable), an Available Models panel (Sand Model + Environmental Model, replacing the old model-comparison chart), KPI cards for MAE/RMSE/R²/BIAS, a map with per-site markers plus the selected site's current/predicted zone polygons and a dune-movement arrow (direction + intensity, and the map zooms to whichever site is selected), a **Predicted Accumulation Trend** chart (consumes the API's `accumulation_trend` directly once it exists; synthesizes a start→end line from the run's own numbers until then — same shape either way, no UI change needed when the API adds it), and a site drill-down (risk, coordinates, area, predicted/net accumulation, sand deposition + range, confidence, dune movement). Every run is persisted (upserted by site name + window, so re-running never duplicates data) in `prediction_runs` / `prediction_sites`. **(Superseded 2026-11-12: the API's `scheduling` / per-site `schedule` are now kept and used by the Planning page, see docs/PLANNING.md.)** Earlier text: the API's per-site `schedule` object was never read — the **Scheduling Team** widget on this page (no site picker, button, or date range of its own — it follows the one site dropdown above) shows the original, pre-existing feature's numbers (the original `sand_predictions` engine), which the single top-level Run Prediction click also refreshes automatically in the background for every site — the widget itself never calls the AI backend and is unaffected by it either way. Responsive down to phone width.

**2. One theme everywhere.** Light theme driven by the CSS tokens at the top of `frontend/src/App.css`, applied to every page including the crew mobile app. Pages are responsive at tablet and phone widths.

**3. Scheduling Team** (`/schedule`) — tick the crews for a prediction and assign equipment to them with live coverage against what the prediction requires; links onward to Dashboard, Dispatch, Work orders and Crews.

**4. Heavy / light equipment** (`/equipment`, tabs Fleet / Schedule / Report) — create, edit, retire and delete units, search and filter; heavy or light class and type; status (Available, Maintenance, Retired); service dates with an "overdue" flag; assign to a crew or return to the yard; full assignment history per unit; fleet counts (also on the Dashboard). Rules enforced by the API: maintenance or retired units cannot be assigned, off-duty crews cannot receive equipment, at most 2 heavy units per crew, and units on a crew cannot be deleted. Moving a unit to maintenance or retired releases it from its crew and cancels its upcoming bookings. **Scheduling:** book a unit for a date range (optionally for a crew and a site); overlapping bookings are refused; an availability finder lists the units free for any date window; bookings can be completed, cancelled or deleted. **Report:** fleet status, service due in 30 days, booked days per unit, equipment per crew, bookings per site.

**5. Open-source GIS only.** No commercial map provider, no paid GIS platform and no tile API keys anywhere in the code, configuration or docs. See "GIS stack" below.

**6. Site master list** — **(2026-11-09: no longer a static seed)** sites are now populated dynamically from the AI Prediction Backend / mock (see item 1 below) and drive every site dropdown, filter, form and report from there.

**7. All database changes live in `database/schema.sql`** — there are no migration files, seed files or migration tools.

## GIS stack (all open source)

| Concern | Technology |
|---|---|
| Map rendering | React-Leaflet / Leaflet |
| Basemap | OpenStreetMap raster tiles (`https://tile.openstreetmap.org`, override with `VITE_TILE_URL`) |
| Spatial storage and processing | PostgreSQL + PostGIS: geometry columns with GIST indexes, `ST_Intersects` (forecast zones vs assets), `ST_Buffer` / `ST_ConvexHull` / `ST_Area` on `geography` (site boundary and real km²), `ST_DistanceSphere` (nearest crews) |
| Vector layers | GeoJSON served by `GET /api/sites/:id/layers` (site boundary, forecast zones, blocks) and `GET /api/forecasts/polygons`, `GET /api/assets/impacted` |
| Client-side calculations | Turf.js, only where the browser needs an instant answer: `@turf/bbox` (map extent / Reset to overview) and `@turf/distance` (crew arrival geofence, route progress) |
| Routing | OSRM (open-source) for road distance and route geometry; falls back to straight-line when unreachable |

Notes: the public OSM tile server and the public OSRM demo server are fine for development and light use but have usage policies and no SLA. For production, run your own tile server and OSRM instance and set `VITE_TILE_URL`. The design mock-up shows satellite imagery; satellite tiles are not available from OpenStreetMap, so the map uses the OSM street basemap.

## Database setup

Everything is in one file, `database/schema.sql` (extension, tables, constraints, indexes, reference data, the 70-site master list and sample data). It drops and recreates the tables, so it is a fresh-install script:
```bash
createdb dune_gis
psql -d dune_gis -f database/schema.sql
```
Master data in the file: `equipment_types`, crews and equipment (seeded, available immediately). **`sites` and `assets` are intentionally empty** — they're populated by the AI Prediction Backend / mock the first time someone runs a prediction on `/prediction` (see "What changed from earlier versions" below), so they always reflect real site data, not a hardcoded list.

More documentation: [API reference](docs/API.md) · [Technical overview](docs/TECHNICAL.md) · [Deployment guide](docs/DEPLOYMENT.md) · [Architecture diagrams](docs/architecture/README.md). Set `OSRM_URL` to use your own routing server.

**Dispatch map lines.** *Planned route* (dashed indigo) is the road route stored on the work order when a crew is dispatched; it needs the routing server (`OSRM_URL`) to be reachable, otherwise the map shows a straight dashed line and says so. *Actual path driven* (solid teal) is the crew's GPS trail and only exists once a crew phone shares its location (Crew app, Home tab). For demos without a phone, run `cd backend && npm run demo:gps` after dispatching a job: it posts GPS points along the job's route exactly as the crew app does (options `--steps`, `--interval`, `--api`, optional crew id).

## New and changed API

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/sites` | Sites with asset count and last prediction risk |
| GET | `/api/sites/:id/layers` | GeoJSON from PostGIS: `boundary` (with `area_km2`), `zones`, `blocks` |
| GET | `/api/sites/:id/predictions/latest` | Latest prediction for a site (or `null`) |
| POST | `/api/sites/:id/predict` | `{ start_date, end_date }` → runs and stores a prediction |
| GET | `/api/predictions/:id` | One stored prediction |
| POST | `/api/predictions/run` | **2026-11-09.** `{ start_date?, end_date? }` → calls the AI Prediction Backend (or the `prediction.json` mock, see `PREDICTION_MODE`) for every site at once, upserts the result, returns the stored run |
|  |  | **Per-site payload shape (updated `prediction.json`):** `site_name, risk, coordinates{lat,lng}, total_area_km2, predicted_accumulation_m, net_accumulation_m, sand_deposition_m3, sand_deposition_range_m3{low,expected,high}, confidence_pct, dune_movement{direction_deg, intensity_pct, current_zone, predicted_zone}, observed_movement_detected`. The two zone polygons now live **inside** `dune_movement`; the earlier flat layout (zones directly on the site) is still accepted. `observed_movement_detected` is passed through in `raw_response` but not stored or shown. |
| GET | `/api/predictions/runs/latest` | Latest completed multi-site run (or `null`), so the Prediction page restores its state on reload |
| GET | `/api/predictions/runs?limit=` | Prediction run history, newest first (API only — not surfaced in the UI, which always shows the latest run) |
| GET | `/api/predictions/runs/:runId` | One run with all its sites (API only, same reason) |
| GET / PUT | `/api/predictions/:id/team` | Required vs assigned people / heavy / light; save `{ crew_ids }` |
| GET | `/api/equipment` | `?class=HEAVY\|LIGHT&status=&crew_id=(id\|none)&q=` fleet list with crew, service-overdue flag, assigned-since |
| GET | `/api/equipment/summary` | Counts per class: total, free, assigned, maintenance, retired, service overdue |
| POST | `/api/equipment` | Create a unit (`unit_code` unique, case-insensitive); optional `crew_id` |
| PUT | `/api/equipment/:id` | Edit details / status (maintenance or retired releases it from its crew) |
| PATCH | `/api/equipment/:id` | `{ crew_id \| null }` assign or return to yard (rules above) |
| DELETE | `/api/equipment/:id` | Delete a unit that is not on a crew (409 otherwise) |
| GET | `/api/equipment/:id/history` | Assignment history |
| GET | `/api/equipment/types` | Equipment type reference list per class |
| GET / POST | `/api/equipment/schedules` | List bookings (`from,to,site_id,equipment_id,crew_id,status`) / create one `{equipment_id, start_date, end_date, site_id?, crew_id?, purpose?}` |
| PATCH / DELETE | `/api/equipment/schedules/:sid` | `{status}` SCHEDULED/COMPLETED/CANCELLED / delete |
| GET | `/api/equipment/availability?from=&to=&class=` | Units free for the whole window |
| GET | `/api/equipment/report` | Fleet report |
| GET | `/api/work-orders`, `/api/assets/impacted` | Gained a `site_id` filter |
| GET | `/api/crews`, `/api/crews/nearest` | Now include `headcount`, `equipment`, and `in_scheduling_team` |

Errors are `{ "error": "message" }` with 400 (validation), 404, 409 (rule violation / duplicate) or 500.

## Pages (this is now a multi-page app)

| Route | Audience | Purpose |
|---|---|---|
| `/` | Dispatcher / stakeholder | **Dashboard** — KPIs (including SLA compliance), open-work-order priority breakdown, 7-day trend, printable situation report |
| `/dispatch` | Dispatcher | **Dispatch** — live map of assets, forecast risk zones, every active job's planned route + actual GPS trail, and real-time progress/SLA status. Click an asset → the app ranks available crews by specialty match and distance, previews the route, and dispatches on one click |
| `/work-orders` | Dispatcher / supervisor | **Work orders** — status tabs, live progress bars, SLA badges (on track / at risk / breached), one-click status advance, expandable audit trail per order |
| `/crews` | Dispatcher | **Crews** — roster with live workload, engine IDs, live-location freshness, base locations on a map, and the **one shared app link** every crew uses |
| `/crew` | Any crew member, on their phone | **Shared entry point** — pick your name, enter your 4-digit PIN, and land on a proper Home screen with three tabs (Home / Jobs / History). Remembered on that device afterward. |
| `/crew/:crewId` | Legacy / direct link | Same tabbed app as `/crew`, addressable directly by crew ID (kept for backward compatibility and quick dispatcher testing) |

All the crew-facing capabilities — status updates with notes, standalone update log, issue flagging, push notification opt-in, live location sharing, and the geofence arrival prompt — work identically whether reached via `/crew` (the normal path) or `/crew/:crewId`.

## The crew app has a real Home screen now

Opening `/crew` no longer drops a crew member straight into a wall of job
cards. After picking their name and PIN, they land on **Home**: a welcome
card with their name/specialty/engine ID/status, three quick stats (active
jobs, completed today, completed all-time), a "View my active jobs" button,
and the alert/location opt-in controls. A bottom tab bar (Home / Jobs /
History, mirroring a native app) lets them move between their overview, their
live assignments, and their full job history — instead of everything living
on one long scrolling page.

## How the dispatcher sees "what the crew is actually following"

The Dispatch map now draws two distinct lines per active job, always pulled
live from the database (not just whatever was dispatched in the current
browser tab):

- **Planned route** (dashed, muted) — the road route computed by OSRM at
  dispatch time; what the crew was told to take.
- **Actual path driven** (solid, bright cyan) — the crew's real GPS breadcrumb
  trail, so a dispatcher can see exactly where they've been, including any
  detour from the plan.

Each active job also shows a **live progress bar** (an approximate % of the
route covered, based on straight-line distance from the crew's current
position to the asset) and, where SLA timestamps make sense, an **on
track / at risk / breached** badge — visible on both the Dispatch map's side
panel and the Work Orders page.

## SLA compliance — turning timestamps into a business metric

Every dispatched job now carries a **response-time target based on its
priority** (CRITICAL: 30 min, HIGH: 60 min, MEDIUM: 120 min, LOW: 240 min,
defined in `frontend/src/sla.js`). While a job is still en route, this shows
as a live on-track/at-risk/breached badge; once a crew marks a job "in
progress" (i.e. they've arrived), it resolves to a simple met/missed SLA
verdict based on the real dispatch → arrival time from the audit trail. The
Dashboard rolls this up into a single **SLA compliance %** KPI across all
resolved jobs — the kind of number a decision-support tool needs to be able
to show a stakeholder, not just an internal ops convenience.

## How a crew accesses the app (single URL, not a link per person)

Instead of generating and distributing a unique link per crew, there's **one URL for everyone**: `/crew`. The flow:

1. Dispatcher copies the one link from the Crews page and sends it to the whole team once (SMS, WhatsApp, a printed card at the depot — doesn't matter, it never changes).
2. A crew member opens it and taps their own name from a simple list.
3. They enter their 4-digit PIN (visible only to the dispatcher, revealed on demand from the Crews page — never included in any list response).
4. They land on their own assignments. The device remembers them (`localStorage`), so this is a one-time step — reopening the same link later skips straight to their jobs. A small ⇄ button in the header lets them switch crews if a device is shared.

This is intentionally lightweight (a PIN, not a password) since it's meant to be fast for someone in the field, not a hardened login system — see the production notes below for what a real deployment would need to add.

## Live crew location

Once a crew member taps "📍 Share my location" on their mobile view, the app
watches their phone's GPS (`navigator.geolocation.watchPosition`) and reports
a position to the backend roughly every 20 seconds — deliberately throttled so
it doesn't hammer the API on every GPS tick. Nothing is sent until they
explicitly opt in.

This isn't just a dot on a map for show: the **nearest-crew ranking and the
route/ETA computed at dispatch time both use a crew's live position over their
static home-base location whenever one is available** (falling back to the
base depot location otherwise). So a crew who's already out in the field gets
correctly prioritized over one still sitting at the depot, and the ETA shown
to the dispatcher reflects where the crew actually is right now, not where
they started their shift.

Dispatchers see this everywhere a crew appears — map popups, the Crews roster,
and the Dispatch page's candidate list — as either "📍 Live · updated Xs ago"
or "📍 Base location (no live GPS yet)", so it's always clear whether a
distance/ETA is real-time or an estimate.

Each crew renders as a **top-down vehicle icon** (not an abstract shape) that
rotates to face its actual direction of travel whenever the phone's GPS
reports a heading, with a pulsing ring while dispatched. The last 50 GPS
points per crew are kept as a rolling breadcrumb trail (`crew_location_pings`
table) and drawn as the "actual path driven" line described above.

While sharing location, a crew's phone also runs a simple **geofence check**
against their assigned asset's coordinates: within 300m of the site, the app
proactively prompts "You've arrived — mark it started?" instead of relying on
them to remember. Marking a job completed triggers a small celebratory
animation — a minor touch, but it's the difference between a tool that feels
transactional and one that feels considered.

## How the "nearest crew + shortest route" flow works

1. **Forecast → priority.** `computeRecommendation()` in `backend/server.js` turns
   `risk_level + asset criticality + asset type` into a priority
   (CRITICAL/HIGH/MEDIUM/LOW) and a specific recommended action — this is the
   business-rules engine the Phase 4 brief calls for.
2. **Nearest available crew, ranked by real road distance.**
   `GET /api/crews/nearest?asset_id=` first shortlists `AVAILABLE` crews by
   specialty match and straight-line distance (fast, computed in PostGIS), then
   calls OSRM's free **Table service** — a single request that returns real
   driving distance/time from every candidate crew to the asset at once — and
   re-ranks by actual road distance. This matters in desert terrain: a crew
   that's closer as-the-crow-flies can easily have a longer actual drive once
   roads, wadis, or pipeline right-of-ways are accounted for. If the routing
   service is unreachable, it fails soft back to straight-line ranking and the
   UI shows a small notice saying so (`routing_source: "straight_line"` in the
   API response).
3. **Shortest route for dispatch.** When the dispatcher confirms, `POST
   /api/work-orders` calls OSRM's `/route` service for the actual driving route
   from that crew's base to the asset, and stores the route geometry, distance,
   and ETA on the work order — shown as a preview dashed line before dispatch
   and a solid route line after.
4. **Crew updates from their phone.** The dispatcher copies a crew's link from
   the Crews page and sends it to them. Opening it shows only their assignments
   and a big "Mark [next status]" button — no login, no desktop UI to navigate.
   Crews aren't limited to just tapping a status button: they can attach a free-text
   note to any status change, log a standalone update at any time without changing
   status (e.g. "extra sand on the east side"), or flag a genuine problem — which
   raises a visible alert on the dispatcher's Work Orders page and Dashboard until
   it's acknowledged.

**Note on OSRM:** `router.project-osrm.org` (used for both the Table ranking
call and the Route dispatch call) is a **free, open-source, no-signup** public
demo server — no API key, no cost. It's fine for this POC/demo, but it's a
shared public server with no uptime guarantee and fair-use rate limits, so it's
not meant for production volume. Both calls fail soft: if the server is
unreachable, work orders still get created and crews are still ranked, just
using straight-line distance instead of real road distance/ETA. Before a real
pilot, swap `computeRoute()` / `computeDistanceMatrix()` for a self-hosted OSRM
instance (fully open-source, Docker-friendly) or another open-source router
such as Valhalla, GraphHopper, or pgRouting (which runs inside the Postgres
you already have).

## How a crew finds out they've been assigned a job

The mobile view uses two layers so a crew genuinely notices a new assignment,
not just whoever happens to be staring at their phone at the right second:

1. **While the tab is open (even backgrounded):** the page polls every 8
   seconds; a newly assigned job triggers a synthesized alert tone, a phone
   vibration (`navigator.vibrate`), a flashing browser tab title ("🔴 New job
   assigned!"), and a dismissible on-screen banner. No setup required — this
   works the moment the page has been opened once.
2. **Real push notifications, even with the app fully closed:** tapping
   "Enable alerts for new jobs" on the mobile view registers a service worker
   and subscribes the phone to **Web Push** — the same free, open, no-cost
   mechanism every browser vendor provides (not Firebase, not Twilio, no
   third-party bill). When a dispatcher creates a work order for that crew,
   the backend sends a real push notification via the open-source `web-push`
   library using a VAPID keypair you generate once and keep in `backend/.env`.
   The crew gets an OS-level notification — lock screen, notification center,
   the works — and tapping it opens the app straight to their assignments.

**Setup note:** Web Push requires HTTPS in production (a browser security
requirement, not a limitation of this code) — `localhost` is exempted for
local development, so this works out of the box while testing, but a real
phone on a real network needs the deployed site served over HTTPS before
"Enable alerts" will work. Generate your own VAPID keypair (do not reuse any
sample values) with:
```bash
node -e "console.log(require('web-push').generateVAPIDKeys())"
```
and put the two keys in `backend/.env`. If they're left blank, push is simply
disabled — the tab-open alerts (tone/vibration/flashing title/banner) keep
working regardless, since they don't depend on VAPID at all.

## What changed from earlier versions

- **2026-11-09 — "Final Prompt" corrections.** Per the final requirements doc:
  the API's per-site `schedule` object (team/equipment/status) is now never
  read anywhere, in the UI or the database — `prediction_sites` no longer has
  `team`/`equipment`/`schedule_*` columns at all (replaced by plain
  `window_start`/`window_end`, taken from the run itself, used only for the
  upsert key). The **Scheduling Team** widget is restored on `/prediction` as
  its own, fully independent card — original site picker, original "Run
  Prediction" button, original `sand_predictions` engine — so it cannot be
  affected by the AI integration either way. Added a **searchable, type-ahead
  site dropdown** (`SiteSearchSelect` in `Prediction.jsx`) that also zooms the
  map to the picked site, and restored the **Predicted Accumulation Trend**
  chart, now reading `site.accumulation_trend` when the API provides it (with
  a start→end fallback line until it does).
- **2026-11-09 — Prediction module enhancement.** `/prediction` now runs against the
  external AI Prediction Backend (`backend/sandSiteDashboard.js`, `POST
  {PREDICTION_API_URL}`) instead of the old in-process single-site engine, with
  automatic fallback to `backend/mock/prediction.json` when that backend is
  unreachable (`PREDICTION_MODE=auto|live|mock`). Added `prediction_runs` /
  `prediction_sites` tables (upserted by site name + schedule window — re-running
  never duplicates data) and `POST /api/predictions/run`, `GET
  /api/predictions/runs(/latest|/:runId)`.
- **2026-11-09 — the 70-site dummy master list is gone; sites now come from the
  AI backend too.** `database/schema.sql` no longer seeds `sites` / `assets` /
  `dune_forecasts` (the old `Site B-01`...`Site S-70` block and its sample
  blocks/zones). Instead, every time `POST /api/predictions/run` completes,
  `syncLegacySiteAndAsset()` in `backend/server.js` upserts (by a code derived
  from the site name, e.g. `Station 1` → `STATION-1`) a matching row in the
  legacy `sites` table and one representative `assets` row per site — so
  Dashboard, Dispatch, Work Orders, Crews and Equipment scheduling-by-site now
  show the **same real, API-sourced sites** as the Prediction page (same code,
  same upsert-not-duplicate guarantee), not placeholder data. The pages
  themselves and the old per-site `sand_predictions` / `POST
  /api/sites/:id/predict` engine are unchanged — only the dummy seed data is
  gone. **Consequence:** `sites` and `assets` are empty immediately after a
  fresh `psql -f database/schema.sql` install, until someone opens `/prediction`
  and clicks **Run Prediction** at least once; Crews and the Equipment fleet are
  still seeded independently and available immediately.
- Added `crews.geom` (crew base coordinates), `work_orders.route_geometry /
  distance_km / eta_minutes`, and a `work_order_events` audit-trail table.
- Added `GET /api/crews/nearest`, crew-workload counts on `GET /api/crews`,
  a `crew_id` filter on `GET /api/work-orders`, and a richer
  `GET /api/dashboard/summary` (priority breakdown + 7-day trend).
- Rebuilt the frontend as a proper multi-page app with React Router instead of
  one single view, and added the standalone mobile crew page.
- Fixed the original mismatch between `App.jsx` class names and `App.css`, the
  missing `leaflet.css` import, and the `LEFT JOIN` duplicate-risk bug from
  earlier iterations of this project.

## Project layout

```
aramco-dune-portal/
├── database/
│   └── schema.sql                # the only database file: tables, constraints, indexes, master and sample data
├── docs/architecture/            # editable Draw.io architecture diagrams
├── backend/
│   ├── server.js                 # REST API
│   ├── prediction.js             # sand prediction engine + team sizing
│   ├── package.json
│   └── .env.example
└── frontend/
    ├── src/
    │   ├── api.js               # single API client used by every page
    │   ├── constants.js
    │   ├── mapUtils.js           # Leaflet icon/style helpers
    │   ├── ToastContext.jsx
    │   ├── App.jsx               # route definitions
    │   ├── components/
    │   │   └── DesktopLayout.jsx # header + nav + clock, wraps desktop pages
    │   └── pages/
    │       ├── Dashboard.jsx
    │       ├── Prediction.jsx
    │       ├── ScheduleTeam.jsx
    │       ├── Dispatch.jsx
    │       ├── WorkOrders.jsx
    │       ├── Crews.jsx
    │       ├── Equipment.jsx
    │       ├── CrewGate.jsx / CrewLogin.jsx
    │       └── CrewMobile.jsx    # standalone, no DesktopLayout
    ├── index.html
    ├── package.json
    └── .env.example
```

## Setup

### 1. Database

See "Database setup" above (`psql -d dune_gis -f database/schema.sql`).

### 2. Backend

```bash
cd backend
cp .env.example .env      # set PGPASSWORD etc. to match your local Postgres
npm install
npm run dev                # http://localhost:5000
```

### 3. Frontend

```bash
cd frontend
cp .env.example .env       # VITE_API_URL (default http://localhost:5000); optional VITE_TILE_URL
npm install
npm run dev                 # http://localhost:5173
```

### 4. Try the full flow

1. Open `http://localhost:5173/dispatch`, click a red/orange marker.
2. The right panel suggests the nearest available crew — click "Dispatch
   nearest crew." Watch the dashed preview line become a solid route.
3. Go to `/crews`, copy the one shared app link, and note a crew's PIN (click
   "Show" next to any roster card — seeded PINs are in `database/schema.sql`,
   e.g. Sand Mitigation Team Alpha is `1122`).
4. Open that link (in another tab, or on your phone if both devices are on
   the same network and you replace `localhost` with your machine's LAN IP),
   pick that crew's name, and enter their PIN — you'll land on the same work
   order from the crew's point of view, with a one-tap button to advance its
   status.
5. Tap "📍 Share my location" on that page, then check `/crews` or
   `/dispatch` — the crew's marker should move to wherever your test device's
   GPS reports, and its distance/ETA in the Dispatch panel should update to
   reflect that live position.
6. Watch `/work-orders` and `/` (Dashboard) update to reflect the change.

## API reference

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/dashboard/summary` | KPIs, open-order priority breakdown, 7-day trend |
| GET | `/api/assets/impacted` | GeoJSON of assets with computed priority/recommendation |
| GET | `/api/forecasts/polygons` | GeoJSON of dune-risk forecast polygons |
| GET | `/api/crews` | Crew roster with live workload, engine ID, and effective position (live GPS if reported, else base) |
| GET | `/api/crews/directory` | Safe name/specialty list only — powers the `/crew` login picker, no PINs or status |
| POST | `/api/crews/login` | `{ crew_id, access_code }` → verifies a crew's PIN, returns their details on success |
| GET | `/api/crews/:id/access-code` | Dispatcher-only PIN lookup, revealed on demand — never included in the general crew list |
| POST | `/api/crews/:id/location` | `{ lat, lon, heading? }` → records a crew's live GPS position + travel heading, reported periodically from their phone |
| GET | `/api/crews/:id/trail?limit=` | Recent GPS breadcrumb points for a crew (oldest first), for drawing the "actual path driven" line |
| GET | `/api/crews/nearest?asset_id=` | Available crews ranked by specialty + **real road distance/ETA** (OSRM Table service, falls back to straight-line), using each crew's live position when available |
| GET | `/api/work-orders?crew_id=&status=` | Work orders, optionally filtered (used by the mobile crew view) |
| POST | `/api/work-orders` | `{ asset_id, crew_id? }` → creates a work order, computes the route if a crew is given |
| PATCH | `/api/work-orders/:id/status` | `{ status, note? }` → advances/cancels, logs to the audit trail, frees the crew on completion |
| POST | `/api/work-orders/:id/notes` | `{ note }` → logs a standalone update to the audit trail without changing status |
| PATCH | `/api/work-orders/:id/flag` | `{ flagged, reason? }` → crew raises/dispatcher clears an issue; feeds the Dashboard's flagged-issues count |
| GET | `/api/sites/:id/routes?limit=` | Nearest crews to a site: ranked in PostGIS (KNN), OSRM route geometry, distance and ETA |
| GET | `/api/predictions/:id/routes` | Routes from the scheduling team's crews to the prediction's site |
| GET | `/api/sites/:id` | One site |
| GET | `/api/push/vapid-public-key` | Public key the frontend needs to create a push subscription |
| POST | `/api/crews/:id/push-subscribe` | `{ subscription }` → stores a crew's phone as a push target |

## Notes for a production deployment

- Add real authentication. The 4-digit PIN at `/crew` is deliberately
  lightweight for a fast field-friendly POC, not a hardened login — anyone who
  guesses or is shown a PIN can act as that crew, and the same is true of the
  dispatcher-facing pages, which have no login at all in this build.
- The `/api/crews/:id/access-code` PIN-reveal endpoint has no access control
  either, for the same reason — restrict it to authenticated dispatchers only.
- Replace the OSRM demo server with a self-hosted instance or a commercial
  routing API, and add caching if you're checking many candidate crews per
  dispatch.
- Move CORS from allow-all to an explicit allow-list for your deployed
  frontend origin.
- Consider tightening the live-location ping interval or adding a
  "stop sharing" control once a crew's shift or job ends, so location
  reporting doesn't run indefinitely in the background.


## 2026-11-11: Operational Planning & Decision Support
New page `/planning` (nav item "Planning") and `GET /api/planning/plan`. It turns the latest prediction run into site priorities, a crew schedule and a deployment recommendation, using this application's own crews and equipment. The prediction API's schedule/team/equipment fields are ignored and dropped on arrival. Details, rules and assumptions: [docs/PLANNING.md](docs/PLANNING.md). The bundled `backend/mock/prediction.json` is now the 53-site sample (without its schedule objects).
