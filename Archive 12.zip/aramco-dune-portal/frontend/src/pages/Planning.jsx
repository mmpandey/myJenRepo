import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, CircleMarker, Polyline, Tooltip, useMap } from 'react-leaflet';
import { api } from '../api';
import { useToast } from '../ToastContext';
import { TILE_URL, TILE_ATTRIBUTION } from '../constants';

// ---------------------------------------------------------------------------
// Operational Planning & Decision Support. One page, four questions:
//   1. What is going to happen?          2. Which site needs attention first?
//   3. When should the team go?          4. Who and what should be deployed?
// Everything comes from GET /api/planning/plan (backend/planning.js), built from
// the latest prediction run plus this app's own crews, equipment and bookings.
// The prediction API's schedule / team / equipment fields are never used.
// ---------------------------------------------------------------------------

const TIER = {
  P1: { color: '#dc3545', short: 'P1', label: 'Act now' },
  P2: { color: '#e0a21b', short: 'P2', label: 'Plan this week' },
  P3: { color: '#4c6ef5', short: 'P3', label: 'Routine' },
  P4: { color: '#8a94ad', short: 'P4', label: 'Monitor' },
};
const RISK_LABEL = { HIGH: 'High', MODERATE: 'Moderate', LOW: 'Low', UNAVAILABLE: 'Unavailable' };
const CREW_COLORS = ['#5b45dc', '#2f9e73', '#d9822b', '#c2417c', '#1c7ed6', '#7c5e10'];
const n0 = (v) => (v == null ? '—' : Math.round(Number(v)).toLocaleString());
const dayLabel = (iso) => new Date(`${iso}T00:00:00Z`).toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short', timeZone: 'UTC' });

function TierChip({ tier }) {
  const t = TIER[tier];
  return <span className="pl-chip" style={{ background: `${t.color}22`, color: t.color, borderColor: `${t.color}66` }}>{t.short} · {t.label}</span>;
}

function FitMap({ points }) {
  const map = useMap();
  useEffect(() => {
    if (points.length) map.fitBounds(points, { padding: [40, 40], maxZoom: 11 });
  }, [map, points]);
  return null;
}

function Question({ n, title, answer }) {
  return (
    <div className="pl-q">
      <div className="pl-q-n">{n}</div>
      <div><div className="pl-q-title">{title}</div><div className="pl-q-ans">{answer}</div></div>
    </div>
  );
}

function TrendBars({ trend }) {
  if (!trend || !trend.length) return <div className="pl-muted">No daily volume series in this run.</div>;
  const max = Math.max(...trend.map((t) => t.volume_m3), 1);
  return (
    <div className="pl-bars" role="img" aria-label="Expected sand volume per day">
      {trend.map((t) => (
        <div key={t.date} className="pl-bar-col">
          <div className="pl-bar-val">{n0(t.volume_m3)}</div>
          <div className="pl-bar" style={{ height: `${Math.max(4, (t.volume_m3 / max) * 80)}px` }} />
          <div className="pl-bar-lab">{dayLabel(t.date).slice(0, 6)}</div>
        </div>
      ))}
    </div>
  );
}

export default function Planning() {
  const showToast = useToast();
  const navigate = useNavigate();
  const [plan, setPlan] = useState(undefined); // undefined = loading, null = no prediction yet
  const [loading, setLoading] = useState(false);
  const [tierFilter, setTierFilter] = useState('ALL');
  const [showAll, setShowAll] = useState(false);
  const [selected, setSelected] = useState(null);
  const [day, setDay] = useState(null);
  const [crewFocus, setCrewFocus] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const p = await api.getPlan();
      setPlan(p);
      if (p) {
        setSelected((cur) => cur || (p.sites[0] && p.sites[0].site_name));
        setDay((cur) => cur || (p.schedule.days.find((d) => d.crews_working > 0) || p.schedule.days[0] || {}).date);
      }
    } catch (err) { showToast(err.message, true); setPlan(null); } finally { setLoading(false); }
  }, [showToast]);
  useEffect(() => { load(); }, [load]);

  const crewColor = useMemo(() => Object.fromEntries((plan?.crews || []).map((c, i) => [c.crew_id, CREW_COLORS[i % CREW_COLORS.length]])), [plan]);
  const site = plan?.sites.find((s) => s.site_name === selected) || null;
  const siteStops = plan ? plan.schedule.stops.filter((s) => s.site_name === selected) : [];
  const dayStops = plan ? plan.schedule.stops.filter((s) => s.date === day) : [];
  const dayInfo = plan?.schedule.days.find((d) => d.date === day);
  const listed = useMemo(() => {
    if (!plan) return [];
    const rows = tierFilter === 'ALL' ? plan.sites : plan.sites.filter((s) => s.tier === tierFilter);
    return showAll ? rows : rows.slice(0, 12);
  }, [plan, tierFilter, showAll]);

  // route of the focused crew on the chosen day: depot -> stops -> depot
  const crewRoute = useMemo(() => {
    if (!plan || crewFocus == null) return null;
    const crew = plan.crews.find((c) => c.crew_id === crewFocus);
    const stops = dayStops.filter((s) => s.crew_id === crewFocus).sort((a, b) => a.order - b.order);
    if (!crew || !stops.length) return null;
    if (crew.route) return { color: crewColor[crewFocus], pts: crew.route, api: true }; // road-network route from the prediction API
    const base = plan.crew_bases?.[crew.crew_id];
    const pts = stops.map((s) => plan.sites.find((x) => x.site_name === s.site_name)).filter(Boolean).map((s) => [s.lat, s.lon]);
    return { color: crewColor[crewFocus], pts: base ? [[base.lat, base.lon], ...pts, [base.lat, base.lon]] : pts };
  }, [plan, crewFocus, dayStops, crewColor]);

  const bounds = useMemo(() => {
    if (!plan) return [];
    const pts = plan.sites.filter((s) => s.tier !== 'P4').map((s) => [s.lat, s.lon]);
    return pts.length ? pts : plan.sites.map((s) => [s.lat, s.lon]);
  }, [plan]);

  const dispatchFirst = async (crew) => {
    const fs = crew.first_stop && plan.sites.find((s) => s.site_name === crew.first_stop.site_name);
    if (!fs || !fs.asset_id || !fs.site_id) { showToast('This site is not linked to a dispatchable asset yet. Run the prediction again.', true); return; }
    if (!window.confirm(`Create a work order and dispatch ${crew.crew_name} to ${fs.site_name}?`)) return;
    try {
      await api.createWorkOrder({ asset_id: fs.asset_id, crew_id: crew.crew_id, site_id: fs.site_id });
      showToast(`${crew.crew_name} dispatched to ${fs.site_name}`);
      navigate('/work-orders');
    } catch (err) { showToast(err.message, true); }
  };

  if (plan === undefined) return <div className="page pl-page"><div className="pl-muted">Building plan…</div></div>;
  if (plan === null) {
    return (
      <div className="page pl-page">
        <section className="pred-card pl-empty">
          <div className="pred-card-title">No prediction to plan from yet</div>
          <p className="pl-muted">Planning is built from the latest prediction run. Run a prediction first, then come back.</p>
          <Link className="btn btn-primary" to="/prediction">Go to Prediction</Link>
        </section>
      </div>
    );
  }

  const f = plan.forecast, cap = plan.capacity;
  const unsched = plan.sites.filter((s) => s.plan.status === 'UNSCHEDULED' || s.plan.status === 'PARTIAL');

  return (
    <div className="page pl-page">
      <div className="pl-head">
        <div>
          <h1 className="pl-title">Operational planning</h1>
          <div className="pred-subhead">Run #{plan.run.run_id} &middot; {plan.run.start_date} &rarr; {plan.run.end_date} &middot; source: {plan.run.source === 'mock' ? 'mock data (prediction.json)' : 'AI Prediction Backend'}</div>
        </div>
        <div className="pl-head-actions">
          <button className="btn btn-ghost" onClick={load} disabled={loading}>{loading ? 'Refreshing…' : 'Refresh plan'}</button>
          <Link className="btn btn-primary" to="/prediction">Run a new prediction</Link>
        </div>
      </div>

      <div className="pl-qs">
        <Question n="1" title="What is going to happen?" answer={plan.answers.what} />
        <Question n="2" title="Which site needs attention first?" answer={plan.answers.first} />
        <Question n="3" title="When should the team go?" answer={plan.answers.when} />
        <Question n="4" title="Who and what should be deployed?" answer={plan.answers.who} />
      </div>

      {/* 1 ---------------------------------------------------------------- */}
      <section className="pred-card">
        <div className="pred-card-title"><span className="pred-dot" /> 1 &middot; What is going to happen</div>
        <div className="pl-kpis">
          <div className="kpi-card"><div className="kpi-value" style={{ color: '#dc3545' }}>{f.risk_summary.high}</div><div className="kpi-label">High risk sites</div></div>
          <div className="kpi-card"><div className="kpi-value" style={{ color: '#e0a21b' }}>{f.risk_summary.moderate}</div><div className="kpi-label">Moderate risk sites</div></div>
          <div className="kpi-card"><div className="kpi-value" style={{ color: '#2f9e73' }}>{f.risk_summary.low}</div><div className="kpi-label">Low risk sites</div></div>
          <div className="kpi-card"><div className="kpi-value">{n0(f.total_volume_m3)}</div><div className="kpi-label">m³ expected, all sites</div></div>
          <div className="kpi-card"><div className="kpi-value">{f.sites_with_observed_movement}</div><div className="kpi-label">sites with movement observed</div></div>
          <div className="kpi-card"><div className="kpi-value">{f.wind.compass ? `${f.wind.compass} ${Math.round(f.wind.direction_deg)}°` : '—'}</div>
            <div className="kpi-label">wind{f.wind.mean_speed_ms != null ? `, mean ${f.wind.mean_speed_ms} m/s` : ''}{f.wind.transport_hours_pct != null ? `, ${f.wind.transport_hours_pct}% transport hours` : ''}</div></div>
        </div>
        <div className="pl-sub">Expected sand volume per day (all sites, m³){f.peak_day ? ` · peak ${dayLabel(f.peak_day)}` : ''}</div>
        <TrendBars trend={f.trend} />
      </section>

      {/* 2 ---------------------------------------------------------------- */}
      <div className="pl-grid">
        <section className="pred-card pl-wide">
          <div className="pred-card-title"><span className="pred-dot" /> 2 &middot; Which site needs attention first</div>
          <div className="pl-filters">
            {['ALL', 'P1', 'P2', 'P3', 'P4'].map((t) => (
              <button key={t} className={`pl-filter${tierFilter === t ? ' on' : ''}`} onClick={() => { setTierFilter(t); setShowAll(false); }}>
                {t === 'ALL' ? `All (${plan.sites.length})` : `${t} ${TIER[t].label} (${f.tiers[t]})`}
              </button>
            ))}
          </div>
          <div className="table-scroll">
            <table className="st-table pl-table">
              <thead><tr><th>#</th><th>Site</th><th>Risk</th><th>Score</th><th>Priority</th><th>m³</th><th>Conf.</th><th>Why</th><th>Plan</th></tr></thead>
              <tbody>
                {listed.map((s) => (
                  <tr key={s.site_name} className={`pl-row${s.site_name === selected ? ' sel' : ''}`} onClick={() => setSelected(s.site_name)}>
                    <td>{s.rank}</td><td className="st-unit">{s.site_name}</td><td>{RISK_LABEL[s.risk] || s.risk}</td>
                    <td><div className="pl-score"><div style={{ width: `${s.score}%`, background: TIER[s.tier].color }} /></div>{s.score}</td>
                    <td><TierChip tier={s.tier} /></td><td>{n0(s.volume_m3)}</td><td>{s.confidence_pct == null ? '—' : `${Math.round(s.confidence_pct)}%`}</td>
                    <td className="pl-why">{s.reasons.join(' · ')}</td>
                    <td>{s.plan.status === 'SCHEDULED' ? dayLabel(s.plan.first_date) : s.plan.status === 'PARTIAL' ? 'Partly' : s.plan.status === 'UNSCHEDULED' ? 'No capacity' : 'Monitor'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {(tierFilter === 'ALL' ? plan.sites.length : f.tiers[tierFilter]) > 12 && (
            <button className="link-btn pl-more" onClick={() => setShowAll((v) => !v)}>{showAll ? 'Show top 12 only' : 'Show all'}</button>
          )}
          <div className="pl-note">Score (0–100) = risk 40 + sand volume 25 + dune movement 15 + confidence 10 + growth 10. P1 ≥ {plan.assumptions.tiers.p1}, P2 ≥ {plan.assumptions.tiers.p2}, P3 ≥ {plan.assumptions.tiers.p3}.</div>
        </section>

        <section className="pred-card pl-side">
          {site ? (
            <>
              <div className="pred-card-title"><span className="pred-dot" /> {site.site_name} <TierChip tier={site.tier} /></div>
              <div className="pl-facts">
                <div><span>Rank</span><b>#{site.rank} of {plan.sites.length}</b></div>
                <div><span>Score</span><b>{site.score}</b></div>
                <div><span>Sand expected</span><b>{n0(site.volume_m3)} m³</b></div>
                <div><span>Range</span><b>{n0(site.range_m3.low)} – {n0(site.range_m3.high)} m³</b></div>
                <div><span>Dune movement</span><b>{site.intensity_pct == null ? '—' : `${Math.round(site.intensity_pct)}%`}{site.direction_deg != null ? ` toward ${Math.round(site.direction_deg)}°` : ''}</b></div>
                <div><span>Do it by</span><b>{site.target_by ? dayLabel(site.target_by) : '—'}</b></div>
              </div>
              <div className="pl-sub">Score breakdown</div>
              {site.score_parts.map((p) => (
                <div key={p.key} className="pl-part"><span>{p.key}</span><div className="pl-score"><div style={{ width: `${(p.points / p.max) * 100}%`, background: TIER[site.tier].color }} /></div><b>{p.points}/{p.max}</b></div>
              ))}
              <div className="pl-sub">3 · When</div>
              {site.plan.status === 'MONITOR' && <div className="pl-muted">{site.plan.note}</div>}
              {site.plan.status === 'UNSCHEDULED' && <div className="pl-warn">{site.plan.note} {site.plan.remaining_h} h of work still unplanned.</div>}
              {siteStops.map((s, i) => (
                <div key={i} className="pl-stop"><b>{dayLabel(s.date)}</b> {s.arrive}–{s.finish} &middot; {s.crew_name} &middot; {s.travel_km != null ? `${s.travel_km} km away` : `${Math.round(s.travel_h * 60)} min drive`}{!s.finishes_site ? ' · continues' : ''}</div>
              ))}
              {site.plan.status === 'PARTIAL' && <div className="pl-warn">{site.plan.remaining_h} h of work does not fit in this window.</div>}
              {site.plan.on_time === false && <div className="pl-warn">First visit is after the recommended date.</div>}
              <div className="pl-sub">4 · What to send</div>
              <div className="pl-deploy">
                {site.deployment.items.map((it) => <span key={it} className="pl-tag">{it}</span>)}
              </div>
              <div className="pl-muted">{site.deployment.team ? `${site.deployment.team} · ` : ''}{site.deployment.people} people · {site.deployment.heavy} heavy · {site.deployment.light} light · about {site.deployment.work_hours} h on site</div>
            </>
          ) : <div className="pl-muted">Select a site.</div>}
        </section>
      </div>

      <section className="pl-map">
        <MapContainer center={[26.3, 49.9]} zoom={8} scrollWheelZoom style={{ height: '100%', width: '100%' }}>
          <TileLayer url={TILE_URL} attribution={TILE_ATTRIBUTION} />
          <FitMap points={bounds} />
          {plan.sites.map((s) => (
            <CircleMarker key={s.site_name} center={[s.lat, s.lon]} radius={s.site_name === selected ? 11 : 7}
              pathOptions={{ color: s.site_name === selected ? '#232F3E' : '#ffffff', weight: s.site_name === selected ? 3 : 1.5, fillColor: TIER[s.tier].color, fillOpacity: s.tier === 'P4' ? 0.55 : 0.95 }}
              eventHandlers={{ click: () => setSelected(s.site_name) }}>
              <Tooltip>#{s.rank} {s.site_name} · {TIER[s.tier].short} · {n0(s.volume_m3)} m³</Tooltip>
            </CircleMarker>
          ))}
          {plan.crews.map((c) => plan.crew_bases?.[c.crew_id] && (
            <CircleMarker key={`b${c.crew_id}`} center={[plan.crew_bases[c.crew_id].lat, plan.crew_bases[c.crew_id].lon]} radius={6}
              pathOptions={{ color: crewColor[c.crew_id], weight: 3, fillColor: '#ffffff', fillOpacity: 1 }}>
              <Tooltip>{c.crew_name} depot</Tooltip>
            </CircleMarker>
          ))}
          {crewRoute && <Polyline positions={crewRoute.pts} pathOptions={{ color: crewRoute.color, weight: 4, dashArray: '8 6' }} />}
        </MapContainer>
        <div className="pl-legend">
          {['P1', 'P2', 'P3', 'P4'].map((t) => <span key={t}><i style={{ background: TIER[t].color }} />{TIER[t].short} {TIER[t].label}</span>)}
          <span><i className="ring" />Crew depot</span>
          {crewRoute && <span>Dashed line: {plan.crews.find((c) => c.crew_id === crewFocus)?.crew_name}, {dayLabel(day)} {crewRoute.api ? '(full route from the prediction plan)' : '(straight-line sketch)'}</span>}
        </div>
      </section>

      {/* 3 ---------------------------------------------------------------- */}
      <section className="pred-card">
        <div className="pred-card-title"><span className="pred-dot" /> 3 &middot; When should the team go</div>
        <div className="pl-days">
          {plan.schedule.days.map((d) => (
            <button key={d.date} className={`pl-day${d.date === day ? ' on' : ''}`} onClick={() => setDay(d.date)}>
              <b>{dayLabel(d.date)}</b><span>{d.crews_working} crew{d.crews_working === 1 ? '' : 's'}</span>
              <div className="pl-score"><div style={{ width: `${d.utilisation_pct}%`, background: '#5b45dc' }} /></div>
            </button>
          ))}
        </div>
        {dayInfo && <div className="pl-sub">{dayLabel(day)}: {dayInfo.hours_used} of {dayInfo.hours_capacity} crew-hours used ({dayInfo.utilisation_pct}%)</div>}
        {dayStops.length ? (
          <div className="table-scroll">
            <table className="st-table">
              <thead><tr><th>Crew</th><th>Leave</th><th>Arrive</th><th>Finish</th><th>Site</th><th>Priority</th><th>Drive</th><th>On site</th></tr></thead>
              <tbody>
                {[...dayStops].sort((a, b) => a.crew_id - b.crew_id || a.order - b.order).map((s, i) => (
                  <tr key={i} className="pl-row" onClick={() => { setSelected(s.site_name); setCrewFocus(s.crew_id); }}>
                    <td><i className="pl-dotc" style={{ background: crewColor[s.crew_id] }} />{s.crew_name}</td><td>{s.depart}</td><td>{s.arrive}</td><td>{s.finish}</td>
                    <td className="st-unit">{s.site_name}{!s.finishes_site ? ' (continues)' : ''}</td><td><TierChip tier={s.tier} /></td>
                    <td>{s.travel_km != null ? `${s.travel_km} km · ` : ''}{s.travel_h} h</td><td>{s.work_h} h</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <div className="pl-muted">No crew work planned on this day.</div>}
        <div className="pl-capacity">
          <b>Window capacity:</b> {cap.hours_scheduled} of {cap.hours_needed} h of work planned, {cap.hours_capacity} crew-hours available.
          {cap.unscheduled_sites > 0 && <span className="pl-warn-inline"> {cap.unscheduled_sites} site{cap.unscheduled_sites === 1 ? '' : 's'} ({cap.hours_unscheduled} h) do not fit: about {cap.extra_crew_days} more crew-day{cap.extra_crew_days === 1 ? '' : 's'} needed.</span>}
        </div>
        {unsched.length > 0 && (
          <details className="pl-details"><summary>Sites that do not fully fit ({unsched.length})</summary>
            <ul>{unsched.map((s) => <li key={s.site_name}><b>{s.site_name}</b> ({s.tier}, {n0(s.volume_m3)} m³): {s.plan.status === 'PARTIAL' ? `${s.plan.remaining_h} h left over` : 'not scheduled'}</li>)}</ul>
          </details>
        )}
      </section>

      {/* 4 ---------------------------------------------------------------- */}
      <section className="pred-card">
        <div className="pred-card-title"><span className="pred-dot" /> 4 &middot; Who and what should be deployed</div>
        <div className="pl-crews">
          {plan.crews.map((c) => {
            const e = c.equipment;
            return (
              <div key={c.crew_id} className={`pl-crew${crewFocus === c.crew_id ? ' on' : ''}`} onClick={() => setCrewFocus(c.crew_id === crewFocus ? null : c.crew_id)}>
                <div className="pl-crew-top"><i className="pl-dotc" style={{ background: crewColor[c.crew_id] }} /><b>{c.crew_name}</b><span className="pl-chip">{c.status === 'DISPATCHED' ? 'Busy today' : 'Available'}</span></div>
                <div className="pl-muted">{c.specialty} · {c.base || 'no base'} · {c.headcount} people</div>
                <div className="pl-facts one">
                  <div><span>Planned</span><b>{c.stops} stops, {c.sites} sites, {c.busy_hours} h</b></div>
                  <div><span>People</span><b className={c.understaffed ? 'bad' : ''}>{c.headcount} of {c.people_needed} needed{c.understaffed ? ' (short)' : ''}</b></div>
                  <div><span>Heavy</span><b className={e.shortfall_heavy ? 'bad' : ''}>{e.heavy_have} of {e.heavy_needed}{e.add_from_yard.some((u) => u.type !== 'LIGHT') ? '' : ''}</b></div>
                  <div><span>Light / vehicles</span><b className={e.shortfall_light ? 'bad' : ''}>{e.light_have} of {e.light_needed}</b></div>
                </div>
                {e.add_from_yard.length > 0 && <div className="pl-add">Add from yard: {e.add_from_yard.map((u) => `${u.name} (${u.unit_code})`).join(', ')}</div>}
                {(e.shortfall_heavy > 0 || e.shortfall_light > 0) && <div className="pl-warn">Still short: {e.shortfall_heavy} heavy, {e.shortfall_light} light. Free more units on the Equipment page.</div>}
                <div className="pl-crew-actions">
                  {c.first_stop && c.crew_id > 0 && c.status === 'AVAILABLE'
                    ? <button className="btn btn-primary" onClick={(ev) => { ev.stopPropagation(); dispatchFirst(c); }}>Dispatch to {c.first_stop.site_name}</button>
                    : <span className="pl-muted">{c.first_stop ? 'Dispatch once the current job is done' : 'No work planned'}</span>}
                  <Link className="link-btn" to="/schedule" onClick={(ev) => ev.stopPropagation()}>Manage team</Link>
                </div>
              </div>
            );
          })}
        </div>
        <div className="pl-note">{plan.assumptions.note}{plan.api_plan
          ? ` ${plan.api_plan.optimizer ? `Optimiser: ${plan.api_plan.optimizer.split(';')[0]}.` : ''} ${plan.api_plan.message || ''}`
          : ` Shift: ${plan.assumptions.shift}; ${plan.assumptions.speed_kmh} km/h x${plan.assumptions.detour_factor} detour; ${plan.assumptions.heavy_m3_per_hour} m³/h per heavy unit.`}</div>
      </section>
    </div>
  );
}
