// ---------------------------------------------------------------------------
// Sand Accumulation Prediction — site-dashboard integration.
//
// Calls the external AI Prediction Backend for a multi-site, 7-day sand
// accumulation forecast:
//   POST {PREDICTION_API_URL}  { start_date, end_date } -> site-dashboard JSON
//
// Falls back to the bundled mock/prediction.json when that backend is
// unreachable. PREDICTION_MODE controls this:
//   'mock' - always use the mock file (no network call)
//   'live' - always call the real backend; errors are thrown, not hidden
//   'auto' - call the real backend, fail soft to the mock file (default)
//
// Both paths resolve to the exact same response shape, so nothing above this
// module (persistence or the UI) needs to know or care which one answered —
// switching environments is purely a .env change, per the requirements doc.
// ---------------------------------------------------------------------------
const fs = require('fs');
const path = require('path');

const API_URL = process.env.PREDICTION_API_URL || 'http://10.0.1.11:8000/api/site-dashboard/production';
const MODE = (process.env.PREDICTION_MODE || 'auto').toLowerCase(); // 'auto' | 'live' | 'mock'
const TIMEOUT_MS = Number(process.env.PREDICTION_API_TIMEOUT_MS) || 8000;
const MOCK_PATH = process.env.PREDICTION_MOCK_PATH || path.join(__dirname, 'mock', 'prediction.json');

// Loads the bundled sample response, but lines its dates up with whatever
// window was actually requested so history and the upsert key reflect what
// the user asked for — the sample numbers, geometry and models stay as-is.
function loadMock(startDate, endDate) {
  const raw = fs.readFileSync(MOCK_PATH, 'utf8');
  const mock = JSON.parse(raw);
  const shiftMs = (Date.parse(startDate) - Date.parse(mock.start_date)) || 0; // sample window -> requested window
  mock.start_date = startDate;
  mock.end_date = endDate;
  const sh = (v) => (typeof v === 'string' && /^\d{4}-\d\d-\d\d/.test(v) && shiftMs
    ? new Date(Date.parse(v.slice(0, 10)) + shiftMs).toISOString().slice(0, 10) + v.slice(10) : v);
  const shObj = (o, keys) => { if (o) keys.forEach((k) => { if (k in o) o[k] = sh(o[k]); }); };
  // the API's own schedule (assignments, per-site windows) moves with the window
  if (mock.scheduling) {
    shObj(mock.scheduling, ['start_date', 'end_date']);
    (mock.scheduling.assignments || []).forEach((a) => shObj(a, ['start', 'end']));
  }
  (mock.sites || []).forEach((s) => shObj(s.schedule, ['start_date', 'end_date']));
  // keep the sample's daily series on the requested window
  if (Array.isArray(mock.accumulation_trend_m3)) {
    mock.accumulation_trend_m3 = mock.accumulation_trend_m3.map((t, i) => ({
      ...t, date: new Date(new Date(startDate).getTime() + i * 86400000).toISOString().slice(0, 10),
    }));
  }
  return mock;
}

async function callLiveApi(startDate, endDate) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ start_date: startDate, end_date: endDate }),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`AI prediction backend returned HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

// Returns { data, source: 'api' | 'mock' }
async function fetchSiteDashboardPrediction(startDate, endDate) {
  if (MODE === 'mock') return { data: loadMock(startDate, endDate), source: 'mock' };
  if (MODE === 'live') return { data: await callLiveApi(startDate, endDate), source: 'api' };

  // auto (default): try the real backend first, fail soft to the mock file —
  // same "fail soft" pattern already used for OSRM routing elsewhere in this app.
  try {
    return { data: await callLiveApi(startDate, endDate), source: 'api' };
  } catch (err) {
    console.warn(`AI prediction backend unavailable (${err.message}) — using prediction.json mock instead.`);
    return { data: loadMock(startDate, endDate), source: 'mock' };
  }
}

// A site's current/predicted zone polygons. The updated prediction.json nests
// them inside "dune_movement" ({direction_deg, intensity_pct, current_zone,
// predicted_zone}); the earlier shape had them directly on the site. Read the
// nested location first and fall back to the old one so either payload works.
// Only a GeoJSON Polygon is accepted (the database columns are Polygon), so a
// malformed or missing zone is stored as NULL instead of failing the whole run.
function asPolygon(z) {
  return z && z.type === 'Polygon' && Array.isArray(z.coordinates) && z.coordinates.length ? z : null;
}
function siteZones(site) {
  const dune = (site && site.dune_movement) || {};
  return {
    current: asPolygon(dune.current_zone) || asPolygon(site && site.current_zone),
    predicted: asPolygon(dune.predicted_zone) || asPolygon(site && site.predicted_zone),
  };
}

module.exports = { fetchSiteDashboardPrediction, siteZones };
