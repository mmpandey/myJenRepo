const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const webpush = require('web-push');
require('dotenv').config();
const { runSandPrediction } = require('./prediction');
const { fetchSiteDashboardPrediction, siteZones } = require('./sandSiteDashboard');
const { buildPlan } = require('./planning');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  user: process.env.PGUSER || 'postgres',
  host: process.env.PGHOST || 'localhost',
  database: process.env.PGDATABASE || 'dune_gis',
  password: process.env.PGPASSWORD || 'postgres',
  port: process.env.PGPORT || 5432,
});

// an idle client can drop (DB restart, network blip); log it instead of crashing the API
pool.on('error', (err) => console.error('Unexpected PostgreSQL pool error:', err.message));

pool.query('SELECT NOW()', (err, result) => {
  if (err) {
    console.error('Database connection error:', err.message);
  } else {
    console.log('Dune Dynamix Portal DB connected:', result.rows[0].now);
  }
});

// ---------------------------------------------------------------------------
// Web Push setup. VAPID keys identify this server to the browsers' own push
// services (Chrome/Firefox/etc.) — this is the free, open web-standard
// alternative to a paid push provider. Generate your own pair once with:
//   node -e "console.log(require('web-push').generateVAPIDKeys())"
// and put them in .env — never reuse the sample pair below in production.
// ---------------------------------------------------------------------------
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
const pushEnabled = Boolean(VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY);

if (pushEnabled) {
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT || 'mailto:ops@example.com',
    VAPID_PUBLIC_KEY,
    VAPID_PRIVATE_KEY
  );
} else {
  console.warn('VAPID keys not set — push notifications are disabled. See backend/.env.example.');
}

async function sendPushToCrew(crewId, payload) {
  if (!pushEnabled) return;
  try {
    const subs = await pool.query('SELECT id, endpoint, p256dh, auth FROM push_subscriptions WHERE crew_id = $1', [crewId]);
    await Promise.all(subs.rows.map(async (sub) => {
      const subscription = { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } };
      try {
        await webpush.sendNotification(subscription, JSON.stringify(payload));
      } catch (err) {
        // 404/410 means the browser subscription is gone (uninstalled, expired) — clean it up
        if (err.statusCode === 404 || err.statusCode === 410) {
          await pool.query('DELETE FROM push_subscriptions WHERE id = $1', [sub.id]);
        } else {
          console.warn('Push send failed:', err.message);
        }
      }
    }));
  } catch (err) {
    console.warn('Push lookup failed:', err.message);
  }
}

// ---------------------------------------------------------------------------
// Business-rules engine (Phase 4 requirement: turn forecast output into
// actionable priorities + recommended actions). Kept in one place so the
// same logic drives both the map overlay and work-order creation.
// ---------------------------------------------------------------------------
function computeRecommendation(riskLevel, assetType, criticality) {
  const risk = riskLevel || 'SAFE';

  let priority = 'LOW';
  if (risk === 'HIGH' && criticality === 'CRITICAL') priority = 'CRITICAL';
  else if (risk === 'HIGH') priority = 'HIGH';
  else if (risk === 'MEDIUM' && criticality === 'CRITICAL') priority = 'HIGH';
  else if (risk === 'MEDIUM') priority = 'MEDIUM';
  else if (risk === 'LOW') priority = 'LOW';
  else priority = 'NONE';

  const actionByType = {
    PIPELINE: 'Clear encroaching sand from right-of-way and inspect pipeline coating for abrasion.',
    FACILITY: 'Deploy sand fencing around facility perimeter and inspect HVAC/intake filtration.',
    WELLHEAD: 'Clear wellhead pad access and inspect Christmas tree valves for sand ingress.',
    ROAD: 'Grade access road and schedule recurring dune-clearance patrol.',
  };

  const suggestedCrewType = assetType === 'ROAD' ? 'GENERAL' : assetType;

  return {
    priority,
    recommended_action: risk === 'SAFE'
      ? 'No action required — continue routine monitoring.'
      : (actionByType[assetType] || 'Inspect asset and clear sand accumulation.'),
    suggested_crew_type: suggestedCrewType,
  };
}

// ---------------------------------------------------------------------------
// Routing engine: crew base -> asset, via the free OSRM public demo server.
// This is fine for a POC/demo; a production deployment should use a
// self-hosted OSRM instance or a commercial provider (Google/Mapbox Directions)
// per its usage policy. Fails soft: if OSRM is unreachable, the work order is
// still created without a route rather than blocking the workflow.
// ---------------------------------------------------------------------------
const OSRM_URL = (process.env.OSRM_URL || 'https://router.project-osrm.org').replace(/\/+$/, '');

async function computeRoute(originLon, originLat, destLon, destLat) {
  try {
    const url = `${OSRM_URL}/route/v1/driving/${originLon},${originLat};${destLon},${destLat}?overview=full&geometries=geojson`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) return null;

    const data = await res.json();
    const route = data.routes && data.routes[0];
    if (!route) return null;

    return {
      route_geometry: route.geometry, // GeoJSON LineString
      distance_km: Math.round((route.distance / 1000) * 10) / 10,
      eta_minutes: Math.round(route.duration / 60),
    };
  } catch (err) {
    console.warn('Routing lookup failed, continuing without a route:', err.message);
    return null;
  }
}

// ---------------------------------------------------------------------------
// Distance/duration matrix (crew bases -> one asset) via OSRM's Table service —
// a single free API call that ranks every candidate crew by real road distance
// and drive time, instead of straight-line distance. Falls back to null on
// any failure so the caller can degrade to straight-line ranking.
// ---------------------------------------------------------------------------
async function computeDistanceMatrix(assetLon, assetLat, crews) {
  if (!crews.length) return null;
  try {
    // Coordinate list: index 0 = asset, indices 1..n = crews, in the given order
    const coordList = [`${assetLon},${assetLat}`, ...crews.map((c) => `${c.lon},${c.lat}`)].join(';');
    const sources = crews.map((_, i) => i + 1).join(';'); // each crew
    const destinations = '0'; // the asset

    const url = `${OSRM_URL}/table/v1/driving/${coordList}?sources=${sources}&destinations=${destinations}&annotations=distance,duration`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) return null;

    const data = await res.json();
    if (data.code !== 'Ok' || !data.distances || !data.durations) return null;

    // data.distances[i][0] / data.durations[i][0] correspond to crews[i], since
    // sources were given in that same order and there is only one destination.
    return crews.map((c, i) => ({
      id: c.id,
      road_distance_km: data.distances[i]?.[0] != null ? Math.round((data.distances[i][0] / 1000) * 10) / 10 : null,
      road_eta_minutes: data.durations[i]?.[0] != null ? Math.round(data.durations[i][0] / 60) : null,
    }));
  } catch (err) {
    console.warn('Distance matrix lookup failed, falling back to straight-line ranking:', err.message);
    return null;
  }
}


app.get('/api/dashboard/summary', async (req, res) => {
  try {
    const [assets, highRisk, openOrders, crews, flaggedOrders, priorityBreakdown, trend, fleet] = await Promise.all([
      pool.query('SELECT COUNT(*)::int AS count FROM assets'),
      pool.query("SELECT COUNT(*)::int AS count FROM dune_forecasts WHERE risk_level = 'HIGH'"),
      pool.query("SELECT COUNT(*)::int AS count FROM work_orders WHERE status NOT IN ('COMPLETED','CANCELLED')"),
      pool.query("SELECT COUNT(*)::int AS count FROM crews WHERE status = 'AVAILABLE'"),
      pool.query("SELECT COUNT(*)::int AS count FROM work_orders WHERE flagged = true AND status NOT IN ('COMPLETED','CANCELLED')"),
      pool.query(`
        SELECT priority, COUNT(*)::int AS count
        FROM work_orders
        WHERE status NOT IN ('COMPLETED', 'CANCELLED')
        GROUP BY priority
      `),
      pool.query(`
        SELECT gs.day::date AS day, COALESCE(c.count, 0)::int AS count
        FROM generate_series(CURRENT_DATE - INTERVAL '6 days', CURRENT_DATE, INTERVAL '1 day') AS gs(day)
        LEFT JOIN (
          SELECT created_at::date AS day, COUNT(*)::int AS count
          FROM work_orders
          WHERE created_at >= CURRENT_DATE - INTERVAL '6 days'
          GROUP BY created_at::date
        ) c ON c.day = gs.day::date
        ORDER BY gs.day
      `),
      pool.query(`
        SELECT equipment_class,
               COUNT(*) FILTER (WHERE status = 'AVAILABLE' AND crew_id IS NULL)::int AS free,
               COUNT(*) FILTER (WHERE status <> 'RETIRED')::int AS total
        FROM equipment GROUP BY equipment_class`),
    ]);

    const equipment = { HEAVY: { free: 0, total: 0 }, LIGHT: { free: 0, total: 0 } };
    fleet.rows.forEach((r) => { equipment[r.equipment_class] = { free: r.free, total: r.total }; });
    const breakdown = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
    priorityBreakdown.rows.forEach((r) => { breakdown[r.priority] = r.count; });

    res.json({
      total_assets: assets.rows[0].count,
      high_risk_zones: highRisk.rows[0].count,
      open_work_orders: openOrders.rows[0].count,
      available_crews: crews.rows[0].count,
      flagged_open: flaggedOrders.rows[0].count,
      priority_breakdown: breakdown,
      trend_7day: trend.rows.map((r) => ({ day: r.day, count: r.count })),
      equipment,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Assets + their worst-case intersecting risk, enriched with recommendations
// ---------------------------------------------------------------------------
app.get('/api/assets/impacted', async (req, res) => {
  const siteId = req.query.site_id ? Number(req.query.site_id) : null;
  if (req.query.site_id && !Number.isInteger(siteId)) return res.status(400).json({ error: 'site_id must be a site id' });
  try {
    const query = `
      SELECT
        a.id, a.site_id, a.name, a.asset_type, a.criticality,
        ST_X(a.geom) AS lon, ST_Y(a.geom) AS lat,
        worst.risk_level, worst.encroach_rate_m_per_yr
      FROM assets a
      LEFT JOIN LATERAL (
        SELECT df.risk_level, df.encroach_rate_m_per_yr
        FROM dune_forecasts df
        WHERE ST_Intersects(a.geom, df.geom)
        ORDER BY
          CASE df.risk_level WHEN 'HIGH' THEN 3 WHEN 'MEDIUM' THEN 2 WHEN 'LOW' THEN 1 ELSE 0 END DESC
        LIMIT 1
      ) worst ON true
      WHERE ($1::int IS NULL OR a.site_id = $1)
      ORDER BY a.id;
    `;
    const result = await pool.query(query, [siteId]);

    const features = result.rows.map((row) => {
      const rec = computeRecommendation(row.risk_level, row.asset_type, row.criticality);
      return {
        type: 'Feature',
        geometry: { type: 'Point', coordinates: [row.lon, row.lat] },
        properties: {
          id: row.id,
          site_id: row.site_id,
          name: row.name,
          asset_type: row.asset_type,
          criticality: row.criticality,
          risk_level: row.risk_level || 'SAFE',
          encroach_rate_m_per_yr: row.encroach_rate_m_per_yr,
          recommended_priority: rec.priority,
          recommended_action: rec.recommended_action,
          suggested_crew_type: rec.suggested_crew_type,
        },
      };
    });

    res.json({ type: 'FeatureCollection', features });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Forecast risk polygons
// ---------------------------------------------------------------------------
app.get('/api/forecasts/polygons', async (req, res) => {
  try {
    const query = `
      SELECT
        json_build_object(
          'type', 'FeatureCollection',
          'features', COALESCE(json_agg(
            json_build_object(
              'type', 'Feature',
              'geometry', ST_AsGeoJSON(geom)::json,
              'properties', json_build_object(
                'id', id,
                'forecast_date', forecast_date,
                'risk_level', risk_level,
                'encroach_rate_m_per_yr', encroach_rate_m_per_yr
              )
            )
          ), '[]'::json)
        ) AS geojson
      FROM dune_forecasts;
    `;
    const result = await pool.query(query);
    res.json(result.rows[0].geojson);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Crews — includes lat/lon for map markers and current open-order workload
// ---------------------------------------------------------------------------
// Equipment currently assigned to a crew, as a JSON array (used by the crews list and the nearest-crew ranking)
const EQUIPMENT_JSON = (crewIdExpr) => `COALESCE((
  SELECT json_agg(json_build_object('id', e.id, 'unit_code', e.unit_code, 'name', e.name,
                                     'equipment_class', e.equipment_class, 'equipment_type', e.equipment_type)
                  ORDER BY e.equipment_class ASC, e.unit_code)
  FROM equipment e WHERE e.crew_id = ${crewIdExpr}), '[]'::json)`;

app.get('/api/crews', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        c.id, c.name, c.specialty, c.status, c.base_location, c.engine_id,
        ST_X(c.geom) AS base_lon, ST_Y(c.geom) AS base_lat,
        COALESCE(c.live_lon, ST_X(c.geom)) AS lon,
        COALESCE(c.live_lat, ST_Y(c.geom)) AS lat,
        c.live_heading,
        c.live_lat IS NOT NULL AS has_live_location,
        c.last_ping_at,
        c.headcount,
        COALESCE(w.open_count, 0)::int AS open_work_orders,
        ${EQUIPMENT_JSON('c.id')} AS equipment
      FROM crews c
      LEFT JOIN (
        SELECT crew_id, COUNT(*) AS open_count
        FROM work_orders
        WHERE status NOT IN ('COMPLETED', 'CANCELLED')
        GROUP BY crew_id
      ) w ON w.crew_id = c.id
      ORDER BY c.status, c.name
    `);
    // access_code is intentionally never selected above — it must never leave the server
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Crew self-service: a safe name/specialty directory for the login picker
// (no PINs, no status), PIN verification, and live GPS reporting — this is
// what lets every crew use one shared app URL instead of a unique link each.
// ---------------------------------------------------------------------------
app.get('/api/crews/directory', async (req, res) => {
  try {
    const result = await pool.query('SELECT id, name, specialty FROM crews ORDER BY name');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/crews/login', async (req, res) => {
  const { crew_id, access_code } = req.body;
  if (!crew_id || !access_code) return res.status(400).json({ error: 'crew_id and access_code are required' });

  try {
    const result = await pool.query(
      `SELECT id, name, specialty, status, engine_id FROM crews WHERE id = $1 AND access_code = $2`,
      [crew_id, access_code]
    );
    if (result.rows.length === 0) return res.status(401).json({ error: 'Incorrect PIN for that crew' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Dispatcher-only lookup so a PIN can be revealed on demand without ever
// including it in the general crew list response.
app.get('/api/crews/:id/access-code', async (req, res) => {
  try {
    const result = await pool.query('SELECT access_code FROM crews WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Crew not found' });
    res.json({ access_code: result.rows[0].access_code });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/crews/:id/location', async (req, res) => {
  const { id } = req.params;
  const { lat, lon, heading } = req.body;
  if (typeof lat !== 'number' || typeof lon !== 'number') {
    return res.status(400).json({ error: 'lat and lon (numbers) are required' });
  }
  const headingValue = typeof heading === 'number' && !Number.isNaN(heading) ? heading : null;

  try {
    const result = await pool.query(
      `UPDATE crews SET live_lat = $1, live_lon = $2, live_heading = $3, last_ping_at = CURRENT_TIMESTAMP WHERE id = $4 RETURNING id`,
      [lat, lon, headingValue, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Crew not found' });

    // Record a breadcrumb, then trim to the most recent 50 pings for this crew
    // so the table stays a small rolling window instead of growing forever.
    await pool.query('INSERT INTO crew_location_pings (crew_id, lat, lon) VALUES ($1, $2, $3)', [id, lat, lon]);
    await pool.query(
      `DELETE FROM crew_location_pings
       WHERE crew_id = $1 AND id NOT IN (
         SELECT id FROM crew_location_pings WHERE crew_id = $1 ORDER BY recorded_at DESC LIMIT 50
       )`,
      [id]
    );

    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/crews/:id/trail', async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit, 10) || 30, 50);
  try {
    const result = await pool.query(
      `SELECT lat, lon, recorded_at FROM crew_location_pings
       WHERE crew_id = $1 ORDER BY recorded_at DESC LIMIT $2`,
      [req.params.id, limit]
    );
    res.json(result.rows.reverse()); // oldest first, for drawing a line in order
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Nearest-available-crew suggestion for a given asset. Ranks crews whose
// specialty matches the asset's needs first, then by straight-line distance
// (fast, computed in the database — no external calls). The exact driving
// route + ETA for the chosen crew is computed separately at dispatch time.
// ---------------------------------------------------------------------------
app.get('/api/crews/nearest', async (req, res) => {
  const assetId = req.query.asset_id;
  if (!assetId) return res.status(400).json({ error: 'asset_id query param is required' });

  try {
    const assetResult = await pool.query(
      `SELECT a.id, a.asset_type, a.criticality, ST_X(a.geom) AS lon, ST_Y(a.geom) AS lat, worst.risk_level
       FROM assets a
       LEFT JOIN LATERAL (
         SELECT df.risk_level FROM dune_forecasts df
         WHERE ST_Intersects(a.geom, df.geom)
         ORDER BY CASE df.risk_level WHEN 'HIGH' THEN 3 WHEN 'MEDIUM' THEN 2 WHEN 'LOW' THEN 1 ELSE 0 END DESC
         LIMIT 1
       ) worst ON true
       WHERE a.id = $1`,
      [assetId]
    );
    if (assetResult.rows.length === 0) return res.status(404).json({ error: 'Asset not found' });

    const asset = assetResult.rows[0];
    const rec = computeRecommendation(asset.risk_level, asset.asset_type, asset.criticality);

    const crewsResult = await pool.query(
      `SELECT
         c.id, c.name, c.specialty, c.status, c.base_location, c.engine_id,
         COALESCE(c.live_lon, ST_X(c.geom)) AS lon,
         COALESCE(c.live_lat, ST_Y(c.geom)) AS lat,
         c.live_heading,
         c.live_lat IS NOT NULL AS has_live_location,
         c.last_ping_at,
         ROUND((ST_DistanceSphere(
           ST_SetSRID(ST_MakePoint(COALESCE(c.live_lon, ST_X(c.geom)), COALESCE(c.live_lat, ST_Y(c.geom))), 4326),
           a.geom
         ) / 1000)::numeric, 1) AS straight_line_km,
         c.headcount,
         ${EQUIPMENT_JSON('c.id')} AS equipment,
         (c.id IN (SELECT pc.crew_id FROM prediction_crews pc
                   WHERE pc.prediction_id = (SELECT p.id FROM sand_predictions p WHERE p.site_id = (SELECT site_id FROM assets WHERE id = $1)
                                             ORDER BY p.run_at DESC, p.id DESC LIMIT 1))) AS in_scheduling_team,
         COALESCE(w.open_count, 0)::int AS open_work_orders
       FROM crews c
       CROSS JOIN (SELECT geom FROM assets WHERE id = $1) a
       LEFT JOIN (
         SELECT crew_id, COUNT(*) AS open_count
         FROM work_orders WHERE status NOT IN ('COMPLETED', 'CANCELLED')
         GROUP BY crew_id
       ) w ON w.crew_id = c.id
       WHERE c.status = 'AVAILABLE'
       ORDER BY (c.specialty = $2) DESC, in_scheduling_team DESC, straight_line_km ASC`,
      [assetId, rec.suggested_crew_type]
    );

    let candidates = crewsResult.rows;
    let routingSource = 'straight_line';

    // Try to rank by real road distance/duration instead of straight-line.
    const matrix = await computeDistanceMatrix(asset.lon, asset.lat, candidates);
    if (matrix) {
      const byId = new Map(matrix.map((m) => [m.id, m]));
      candidates = candidates.map((c) => ({
        ...c,
        road_distance_km: byId.get(c.id)?.road_distance_km ?? null,
        road_eta_minutes: byId.get(c.id)?.road_eta_minutes ?? null,
      }));

      // Re-sort: specialty match still takes priority (a crew must be able to
      // do the job), but within/across that tier, rank by real road distance.
      candidates.sort((a, b) => {
        const aMatch = a.specialty === rec.suggested_crew_type ? 1 : 0;
        const bMatch = b.specialty === rec.suggested_crew_type ? 1 : 0;
        if (aMatch !== bMatch) return bMatch - aMatch;
        // crews already scheduled for this site's prediction come first within a specialty tier
        if (a.in_scheduling_team !== b.in_scheduling_team) return a.in_scheduling_team ? -1 : 1;
        const aDist = a.road_distance_km ?? a.straight_line_km;
        const bDist = b.road_distance_km ?? b.straight_line_km;
        return aDist - bDist;
      });
      routingSource = 'road_network';
    }

    res.json({
      asset_id: asset.id,
      recommended_priority: rec.priority,
      recommended_action: rec.recommended_action,
      suggested_crew_type: rec.suggested_crew_type,
      routing_source: routingSource,
      candidates,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Work orders — includes route info and full audit trail per order
// ---------------------------------------------------------------------------
app.get('/api/work-orders', async (req, res) => {
  const { crew_id, status, site_id } = req.query;
  const conditions = [];
  const params = [];

  if (crew_id) {
    params.push(crew_id);
    conditions.push(`w.crew_id = $${params.length}`);
  }
  if (status) {
    params.push(status);
    conditions.push(`w.status = $${params.length}`);
  }
  if (site_id) {
    if (!Number.isInteger(Number(site_id))) return res.status(400).json({ error: 'site_id must be a site id' });
    params.push(Number(site_id));
    conditions.push(`w.site_id = $${params.length}`);
  }
  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const result = await pool.query(`
      SELECT
        w.*, s.name AS site_name, s.code AS site_code, a.name AS asset_name, a.asset_type, a.criticality AS asset_criticality,
        ST_X(a.geom) AS asset_lon, ST_Y(a.geom) AS asset_lat,
        c.name AS crew_name, c.specialty AS crew_specialty, c.engine_id AS crew_engine_id,
        COALESCE(c.live_lon, ST_X(c.geom)) AS crew_lon, COALESCE(c.live_lat, ST_Y(c.geom)) AS crew_lat,
        COALESCE(
          (SELECT json_agg(json_build_object('status', e.status, 'note', e.note, 'created_at', e.created_at) ORDER BY e.created_at)
           FROM work_order_events e WHERE e.work_order_id = w.id),
          '[]'::json
        ) AS events
      FROM work_orders w
      JOIN assets a ON w.asset_id = a.id
      LEFT JOIN sites s ON w.site_id = s.id
      LEFT JOIN crews c ON w.crew_id = c.id
      ${whereClause}
      ORDER BY
        CASE w.priority WHEN 'CRITICAL' THEN 4 WHEN 'HIGH' THEN 3 WHEN 'MEDIUM' THEN 2 ELSE 1 END DESC,
        w.created_at DESC
    `, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/work-orders', async (req, res) => {
  const { asset_id, crew_id } = req.body;
  if (!asset_id) return res.status(400).json({ error: 'asset_id is required' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const assetResult = await client.query(
      `SELECT a.id, a.site_id, a.name, a.asset_type, a.criticality, ST_X(a.geom) AS lon, ST_Y(a.geom) AS lat, worst.risk_level
       FROM assets a
       LEFT JOIN LATERAL (
         SELECT df.risk_level FROM dune_forecasts df
         WHERE ST_Intersects(a.geom, df.geom)
         ORDER BY CASE df.risk_level WHEN 'HIGH' THEN 3 WHEN 'MEDIUM' THEN 2 WHEN 'LOW' THEN 1 ELSE 0 END DESC
         LIMIT 1
       ) worst ON true
       WHERE a.id = $1`,
      [asset_id]
    );

    if (assetResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Asset not found' });
    }

    const asset = assetResult.rows[0];
    const rec = computeRecommendation(asset.risk_level, asset.asset_type, asset.criticality);
    // computeRecommendation() can return 'NONE' for an asset with no intersecting dune_forecasts
    // zone (every asset synced in from the AI Prediction Backend has none, by design — see
    // syncLegacySiteAndAsset() — dune_forecasts is a separate, legacy concept this integration never
    // fakes data for). 'NONE' is a valid *display* value on /api/assets/impacted, but work_orders.priority
    // only allows CRITICAL/HIGH/MEDIUM/LOW, so inserting it as-is violates that CHECK constraint and was
    // breaking every work order creation for these sites. Floor it to LOW — a work order can still be
    // created manually; it's just not auto-escalated.
    const workOrderPriority = rec.priority === 'NONE' ? 'LOW' : rec.priority;

    // Hard guard against double-booking a crew: check for any of their existing
    // *unfinished* work orders directly, rather than trusting crews.status alone
    // (which could theoretically drift out of sync). This makes double-assignment
    // structurally impossible instead of merely unlikely.
    if (crew_id) {
      const activeCheck = await client.query(
        `SELECT id, status FROM work_orders WHERE crew_id = $1 AND status NOT IN ('COMPLETED', 'CANCELLED')`,
        [crew_id]
      );
      if (activeCheck.rows.length > 0) {
        await client.query('ROLLBACK');
        return res.status(409).json({
          error: `This crew already has an active work order (#${activeCheck.rows[0].id}, ${activeCheck.rows[0].status}). Wait for it to finish or choose a different crew.`,
        });
      }
    }

    let route = null;
    if (crew_id) {
      const crewResult = await client.query(
        'SELECT id, COALESCE(live_lon, ST_X(geom)) AS lon, COALESCE(live_lat, ST_Y(geom)) AS lat FROM crews WHERE id = $1',
        [crew_id]
      );
      const crew = crewResult.rows[0];
      if (crew && crew.lon != null && crew.lat != null) {
        route = await computeRoute(crew.lon, crew.lat, asset.lon, asset.lat);
      }
    }

    const status = crew_id ? 'DISPATCHED' : 'OPEN';

    const insertResult = await client.query(
      `INSERT INTO work_orders
         (asset_id, crew_id, priority, recommended_action, status, route_geometry, distance_km, eta_minutes, site_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [
        asset_id,
        crew_id || null,
        workOrderPriority,
        rec.recommended_action,
        status,
        route ? JSON.stringify(route.route_geometry) : null,
        route ? route.distance_km : null,
        route ? route.eta_minutes : null,
        asset.site_id,
      ]
    );

    const workOrder = insertResult.rows[0];

    await client.query(
      `INSERT INTO work_order_events (work_order_id, status, note) VALUES ($1, $2, $3)`,
      [workOrder.id, status, status === 'DISPATCHED' ? 'Work order created and crew dispatched' : 'Work order created']
    );

    if (crew_id) {
      await client.query("UPDATE crews SET status = 'DISPATCHED' WHERE id = $1", [crew_id]);
    }

    await client.query('COMMIT');

    if (crew_id) {
      // Fire-and-forget: a failed push should never fail the dispatch itself
      sendPushToCrew(crew_id, {
        title: `New job: ${workOrderPriority} priority`,
        body: `${asset.name} — ${rec.recommended_action}`,
        url: `/crew/${crew_id}`,
      }).catch((err) => console.warn('Push notification failed:', err.message));
    }

    res.status(201).json(workOrder);
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
});

app.patch('/api/work-orders/:id/status', async (req, res) => {
  const { id } = req.params;
  const { status, note } = req.body;
  const allowed = ['OPEN', 'DISPATCHED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: `status must be one of ${allowed.join(', ')}` });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const result = await client.query(
      `UPDATE work_orders SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *`,
      [status, id]
    );

    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Work order not found' });
    }

    const workOrder = result.rows[0];

    await client.query(
      `INSERT INTO work_order_events (work_order_id, status, note) VALUES ($1, $2, $3)`,
      [id, status, note || null]
    );

    if (['COMPLETED', 'CANCELLED'].includes(status) && workOrder.crew_id) {
      await client.query("UPDATE crews SET status = 'AVAILABLE' WHERE id = $1", [workOrder.crew_id]);
    }

    await client.query('COMMIT');
    res.json(workOrder);
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
});

// ---------------------------------------------------------------------------
// Standalone note: lets a crew log an update without changing the work
// order's status (e.g. "extra sand on the east side, may need more time").
// Recorded to the same audit trail shown to the dispatcher.
// ---------------------------------------------------------------------------
app.post('/api/work-orders/:id/notes', async (req, res) => {
  const { id } = req.params;
  const { note } = req.body;
  if (!note || !note.trim()) return res.status(400).json({ error: 'note text is required' });

  try {
    const woResult = await pool.query('SELECT status FROM work_orders WHERE id = $1', [id]);
    if (woResult.rows.length === 0) return res.status(404).json({ error: 'Work order not found' });

    await pool.query(
      `INSERT INTO work_order_events (work_order_id, status, note) VALUES ($1, $2, $3)`,
      [id, woResult.rows[0].status, note.trim()]
    );
    await pool.query('UPDATE work_orders SET updated_at = CURRENT_TIMESTAMP WHERE id = $1', [id]);

    res.status(201).json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Issue flag: lets a crew escalate a problem ("need extra equipment", "asset
// worse than expected") so it surfaces immediately to dispatchers, separate
// from the normal status flow. Dispatchers acknowledge to clear it.
// ---------------------------------------------------------------------------
app.patch('/api/work-orders/:id/flag', async (req, res) => {
  const { id } = req.params;
  const { flagged, reason } = req.body;
  if (typeof flagged !== 'boolean') return res.status(400).json({ error: 'flagged (boolean) is required' });
  if (flagged && (!reason || !reason.trim())) return res.status(400).json({ error: 'reason is required when raising an issue' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const result = await client.query(
      `UPDATE work_orders SET flagged = $1, flag_reason = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3 RETURNING *`,
      [flagged, flagged ? reason.trim() : null, id]
    );
    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Work order not found' });
    }

    await client.query(
      `INSERT INTO work_order_events (work_order_id, status, note) VALUES ($1, $2, $3)`,
      [id, flagged ? 'ISSUE_REPORTED' : 'ISSUE_CLEARED', flagged ? reason.trim() : null]
    );

    await client.query('COMMIT');
    res.json(result.rows[0]);
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
});


// ===========================================================================
// SITES, PREDICTION, SCHEDULING TEAM, EQUIPMENT
// Flow: pick a site -> Run Prediction -> Scheduling Team (crews + heavy/light
// equipment) -> Dashboard / Dispatch / Work Orders / Crews. Dispatch itself is
// always manual — nothing here creates work orders or sends crews anywhere.
// ===========================================================================
const PREDICTION_COLS = `p.id, p.site_id, p.run_at, p.window_start::text AS window_start, p.window_end::text AS window_end, p.window_days,
  p.current_accum_m::float AS current_accum_m, p.predicted_accum_m::float AS predicted_accum_m, p.net_accum_m::float AS net_accum_m,
  p.risk_level, p.confidence_pct, p.risk_counts, p.asset_results, p.model_results, p.series, p.metrics, p.resources`;

app.get('/api/sites', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT s.id, s.code, s.name, s.region, s.sort_order, ST_X(s.geom) AS lon, ST_Y(s.geom) AS lat,
             s.baseline_accum_m::float AS baseline_accum_m,
             (SELECT COUNT(*)::int FROM assets a WHERE a.site_id = s.id) AS asset_count,
             lp.id AS last_prediction_id, lp.risk_level AS last_risk_level, lp.run_at AS last_run_at
      FROM sites s
      LEFT JOIN LATERAL (
        SELECT id, risk_level, run_at FROM sand_predictions p WHERE p.site_id = s.id ORDER BY run_at DESC, id DESC LIMIT 1
      ) lp ON true
      ORDER BY s.sort_order NULLS LAST, s.code`);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/sites/:id', async (req, res) => {
  try {
    const r = await pool.query(`SELECT id, code, name, region, sort_order, ST_X(geom) AS lon, ST_Y(geom) AS lat,
      baseline_accum_m::float AS baseline_accum_m, wind_drift_potential::float AS wind_drift_potential, sand_supply_index::float AS sand_supply_index
      FROM sites WHERE id = $1`, [Number(req.params.id) || 0]);
    if (!r.rows.length) return res.status(404).json({ error: 'Site not found' });
    res.json(r.rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Latest prediction for a site (null when none yet) so the page restores its state on reload
app.get('/api/sites/:id/predictions/latest', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT ${PREDICTION_COLS} FROM sand_predictions p WHERE p.site_id = $1 ORDER BY p.run_at DESC, p.id DESC LIMIT 1`, [req.params.id]);
    res.json(result.rows[0] || null);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// :id is constrained to digits so this never shadows the /api/predictions/run(s)... AI-run
// routes added below (e.g. GET /api/predictions/runs would otherwise match :id="runs" here,
// since Express matches routes in registration order and both are two path segments).
app.get('/api/predictions/:id(\\d+)', async (req, res) => {
  try {
    const result = await pool.query(`SELECT ${PREDICTION_COLS} FROM sand_predictions p WHERE p.id = $1`, [req.params.id]);
    if (!result.rows.length) return res.status(404).json({ error: 'Prediction not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Run the prediction for a site over a window. body: { start_date, end_date }
app.post('/api/sites/:id/predict', async (req, res) => {
  const siteId = Number(req.params.id);
  const { start_date, end_date } = req.body || {};
  try {
    const siteRes = await pool.query('SELECT id, name, baseline_accum_m, wind_drift_potential, sand_supply_index FROM sites WHERE id = $1', [siteId]);
    if (!siteRes.rows.length) return res.status(404).json({ error: 'Site not found' });

    const start = start_date ? new Date(start_date) : new Date();
    const end = end_date ? new Date(end_date) : new Date(start.getTime() + 30 * 86400000);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return res.status(400).json({ error: 'Start and end must be valid dates' });
    const days = Math.round((end - start) / 86400000);
    if (days < 1 || days > 180) return res.status(400).json({ error: 'The prediction window must be between 1 and 180 days' });

    // Blocks = the site's assets; each carries the strongest dune-forecast zone that touches it
    const assetsRes = await pool.query(`
      SELECT a.id, a.name, a.asset_type, ST_X(a.geom) AS lon, ST_Y(a.geom) AS lat,
             (SELECT MAX(df.encroach_rate_m_per_yr)::float FROM dune_forecasts df WHERE ST_Intersects(a.geom, df.geom)) AS zone_rate
      FROM assets a WHERE a.site_id = $1 ORDER BY a.id`, [siteId]);
    if (!assetsRes.rows.length) return res.status(400).json({ error: 'This site has no assets to assess' });

    const r = runSandPrediction({ site: siteRes.rows[0], assets: assetsRes.rows, startDate: start, windowDays: days });
    const ins = await pool.query(
      `INSERT INTO sand_predictions
         (site_id, window_start, window_end, window_days, current_accum_m, predicted_accum_m, net_accum_m, risk_level, confidence_pct,
          risk_counts, asset_results, model_results, series, metrics, resources)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
       RETURNING id`,
      [siteId, r.window_start, r.window_end, r.window_days, r.current_accum_m, r.predicted_accum_m, r.net_accum_m, r.risk_level, r.confidence_pct,
        JSON.stringify(r.risk_counts), JSON.stringify(r.asset_results), JSON.stringify(r.model_results), JSON.stringify(r.series),
        JSON.stringify(r.metrics), JSON.stringify(r.resources)]);

    const full = await pool.query(`SELECT ${PREDICTION_COLS} FROM sand_predictions p WHERE p.id = $1`, [ins.rows[0].id]);
    res.status(201).json(full.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- Scheduling team: required vs. assigned resources for a prediction -------------------------
async function buildTeamPlan(predictionId) {
  const pred = await pool.query('SELECT id, site_id, resources FROM sand_predictions WHERE id = $1', [predictionId]);
  if (!pred.rows.length) return null;
  const required = pred.rows[0].resources;

  const crews = await pool.query(`
    SELECT c.id, c.name, c.specialty, c.status, c.base_location, c.engine_id, c.headcount,
           ${EQUIPMENT_JSON('c.id')} AS equipment,
           EXISTS (SELECT 1 FROM prediction_crews pc WHERE pc.prediction_id = $1 AND pc.crew_id = c.id) AS selected
    FROM crews c ORDER BY c.name`, [predictionId]);
  const pool_ = await pool.query(`
    SELECT e.id, e.unit_code, e.name, e.equipment_class, e.equipment_type, e.status, e.crew_id, c.name AS crew_name
    FROM equipment e LEFT JOIN crews c ON c.id = e.crew_id
    WHERE e.status <> 'RETIRED'
    ORDER BY e.equipment_class ASC, e.unit_code`);

  const picked = crews.rows.filter((c) => c.selected);
  const assigned = {
    people: picked.reduce((a, c) => a + c.headcount, 0),
    heavy_units: picked.reduce((a, c) => a + c.equipment.filter((e) => e.equipment_class === 'HEAVY').length, 0),
    light_units: picked.reduce((a, c) => a + c.equipment.filter((e) => e.equipment_class === 'LIGHT').length, 0),
    crews: picked.length,
  };
  const gaps = {
    people: Math.max(0, required.people - assigned.people),
    heavy_units: Math.max(0, required.heavy_units - assigned.heavy_units),
    light_units: Math.max(0, required.light_units - assigned.light_units),
  };
  return {
    prediction_id: predictionId,
    site_id: pred.rows[0].site_id,
    required,
    assigned,
    gaps,
    covered: gaps.people === 0 && gaps.heavy_units === 0 && gaps.light_units === 0,
    crews: crews.rows,
    equipment: pool_.rows,
  };
}

app.get('/api/predictions/:id(\\d+)/team', async (req, res) => {
  try {
    const plan = await buildTeamPlan(Number(req.params.id));
    if (!plan) return res.status(404).json({ error: 'Prediction not found' });
    res.json(plan);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Save the crews chosen for this prediction's scheduling team. body: { crew_ids: number[] }
app.put('/api/predictions/:id(\\d+)/team', async (req, res) => {
  const predictionId = Number(req.params.id);
  const ids = Array.isArray(req.body && req.body.crew_ids) ? [...new Set(req.body.crew_ids.map(Number))] : null;
  if (!ids || ids.some((n) => !Number.isInteger(n))) return res.status(400).json({ error: 'crew_ids must be an array of crew ids' });

  const client = await pool.connect();
  let released = false;
  try {
    await client.query('BEGIN');
    const pred = await client.query('SELECT id FROM sand_predictions WHERE id = $1 FOR UPDATE', [predictionId]);
    if (!pred.rows.length) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Prediction not found' }); }
    if (ids.length) {
      const found = await client.query('SELECT id, name, status FROM crews WHERE id = ANY($1::int[])', [ids]);
      if (found.rows.length !== ids.length) { await client.query('ROLLBACK'); return res.status(400).json({ error: 'One or more crews do not exist' }); }
      const off = found.rows.find((c) => c.status === 'OFF_DUTY');
      if (off) { await client.query('ROLLBACK'); return res.status(409).json({ error: `${off.name} is off duty and cannot be scheduled` }); }
    }
    await client.query('DELETE FROM prediction_crews WHERE prediction_id = $1', [predictionId]);
    for (const id of ids) await client.query('INSERT INTO prediction_crews (prediction_id, crew_id) VALUES ($1, $2)', [predictionId, id]);
    await client.query('COMMIT');
    client.release();
    released = true;
    res.json(await buildTeamPlan(predictionId));
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    res.status(500).json({ error: err.message });
  } finally {
    if (!released) client.release();
  }
});


// ---- Routing: nearest crews to a site (PostGIS KNN) + OSRM route geometry, distance and ETA ----------
// Crews are ranked in the database with the geography KNN operator (<->), then each of the closest ones gets a
// real driving route from OSRM. The result feeds the route lines, distance and ETA shown on the Scheduling
// Team and Prediction screens. Routing is isolated here so a future optimiser can replace the ranking step.
async function nearestCrewRoutes(siteId, { limit = 5, prefer = [] } = {}) {
  const site = await pool.query('SELECT id, code, name, ST_X(geom) AS lon, ST_Y(geom) AS lat FROM sites WHERE id = $1', [siteId]);
  if (!site.rows.length) return null;
  const s = site.rows[0];
  const crews = await pool.query(
    `SELECT c.id, c.name, c.specialty, c.status, c.base_location,
            COALESCE(c.live_lon, ST_X(c.geom)) AS lon, COALESCE(c.live_lat, ST_Y(c.geom)) AS lat,
            ROUND((ST_DistanceSphere(c.geom, st.geom) / 1000)::numeric, 1)::float AS straight_line_km,
            (c.id = ANY($3::int[])) AS in_team
     FROM crews c CROSS JOIN (SELECT geom FROM sites WHERE id = $1) st
     WHERE c.status <> 'OFF_DUTY'
     ORDER BY (c.id = ANY($3::int[])) DESC, c.geom::geography <-> st.geom::geography
     LIMIT $2`, [siteId, limit, prefer]);
  const routes = await Promise.all(crews.rows.map(async (c) => {
    const r = await computeRoute(c.lon, c.lat, s.lon, s.lat);
    return {
      crew_id: c.id, crew_name: c.name, specialty: c.specialty, status: c.status, base_location: c.base_location,
      in_team: c.in_team, from: { lon: c.lon, lat: c.lat }, straight_line_km: c.straight_line_km,
      distance_km: r ? r.distance_km : null, eta_minutes: r ? r.eta_minutes : null,
      routing_source: r ? 'road_network' : 'straight_line', route_geometry: r ? r.route_geometry : null,
    };
  }));
  routes.sort((a, b) => (b.in_team - a.in_team) || ((a.distance_km ?? a.straight_line_km) - (b.distance_km ?? b.straight_line_km)));
  return { site: s, routes };
}

// Nearest available crews to a site with their OSRM routes. ?limit= (1-10, default 5)
app.get('/api/sites/:id/routes', async (req, res) => {
  try {
    const limit = Math.min(10, Math.max(1, Number(req.query.limit) || 5));
    const out = await nearestCrewRoutes(Number(req.params.id), { limit });
    if (!out) return res.status(404).json({ error: 'Site not found' });
    res.json(out);
  } catch (err) { sendError(res, err); }
});

// Routes from the crews chosen for this prediction's scheduling team to its site (nearest other crews fill in when no team is saved yet)
app.get('/api/predictions/:id(\\d+)/routes', async (req, res) => {
  try {
    const pred = await pool.query('SELECT site_id FROM sand_predictions WHERE id = $1', [Number(req.params.id)]);
    if (!pred.rows.length) return res.status(404).json({ error: 'Prediction not found' });
    const team = await pool.query('SELECT crew_id FROM prediction_crews WHERE prediction_id = $1', [Number(req.params.id)]);
    const ids = team.rows.map((r) => r.crew_id);
    const out = await nearestCrewRoutes(pred.rows[0].site_id, { limit: Math.max(3, ids.length), prefer: ids });
    res.json(out);
  } catch (err) { sendError(res, err); }
});

// ---- Equipment (heavy / light): create, manage, track, assign ------------------------------------
const MAX_HEAVY_PER_CREW = 2;
const EQUIPMENT_STATUSES = ['AVAILABLE', 'MAINTENANCE', 'RETIRED'];
const EQUIPMENT_CLASSES = ['HEAVY', 'LIGHT'];

const EQUIPMENT_SELECT = `
  SELECT e.id, e.unit_code, e.name, e.equipment_class, e.equipment_type, e.make_model, e.status,
         e.last_service_on::text AS last_service_on, e.next_service_due::text AS next_service_due, e.notes,
         e.crew_id, c.name AS crew_name, e.created_at, e.updated_at,
         (e.status <> 'RETIRED' AND e.next_service_due IS NOT NULL AND e.next_service_due < CURRENT_DATE) AS service_overdue,
         (SELECT h.assigned_at FROM equipment_assignments h WHERE h.equipment_id = e.id AND h.released_at IS NULL LIMIT 1) AS assigned_since,
         (SELECT MIN(sc.start_date)::text FROM equipment_schedules sc WHERE sc.equipment_id = e.id AND sc.status = 'SCHEDULED' AND sc.end_date >= CURRENT_DATE) AS next_booking
  FROM equipment e LEFT JOIN crews c ON c.id = e.crew_id`;

const httpError = (status, message) => Object.assign(new Error(message), { status });

// Reads and validates the editable fields of an equipment payload. partial = true for PUT (only supplied keys).
function readEquipmentBody(body, partial) {
  const b = body || {};
  const out = {};
  const text = (k, max, required) => {
    if (b[k] === undefined) { if (!partial && required) throw httpError(400, `${k} is required`); return; }
    const v = b[k] === null ? '' : String(b[k]).trim();
    if (required && !v) throw httpError(400, `${k} cannot be empty`);
    if (v.length > max) throw httpError(400, `${k} must be at most ${max} characters`);
    out[k] = v || null;
  };
  text('unit_code', 30, true); text('name', 120, true); text('equipment_type', 50, true); text('make_model', 120, false); text('notes', 1000, false);
  if (b.equipment_class !== undefined || !partial) {
    const v = String(b.equipment_class || '').toUpperCase();
    if (!EQUIPMENT_CLASSES.includes(v)) throw httpError(400, 'equipment_class must be HEAVY or LIGHT');
    out.equipment_class = v;
  }
  if (b.status !== undefined) {
    const v = String(b.status).toUpperCase();
    if (!EQUIPMENT_STATUSES.includes(v)) throw httpError(400, `status must be one of ${EQUIPMENT_STATUSES.join(', ')}`);
    out.status = v;
  }
  for (const k of ['last_service_on', 'next_service_due']) {
    if (b[k] === undefined) continue;
    if (b[k] === null || b[k] === '') { out[k] = null; continue; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(b[k])) || Number.isNaN(new Date(b[k]).getTime())) throw httpError(400, `${k} must be a date (YYYY-MM-DD)`);
    out[k] = String(b[k]);
  }
  if (out.last_service_on && out.next_service_due && out.next_service_due < out.last_service_on) {
    throw httpError(400, 'next_service_due cannot be before last_service_on');
  }
  if (b.crew_id !== undefined) {
    if (b.crew_id !== null && !Number.isInteger(b.crew_id)) throw httpError(400, 'crew_id must be a crew id or null');
    out.crew_id = b.crew_id;
  }
  return out;
}

// Assignment rules shared by create, edit and assign. Runs inside the caller's transaction.
async function checkCrewCanTake(client, unit, crewId) {
  if (unit.status !== 'AVAILABLE') throw httpError(409, `${unit.unit_code} is ${unit.status.toLowerCase()} and cannot be assigned`);
  const crew = await client.query('SELECT id, name, status FROM crews WHERE id = $1 FOR UPDATE', [crewId]);
  if (!crew.rows.length) throw httpError(404, 'Crew not found');
  if (crew.rows[0].status === 'OFF_DUTY') throw httpError(409, `${crew.rows[0].name} is off duty`);
  if (unit.equipment_class === 'HEAVY') {
    const heavy = await client.query("SELECT COUNT(*)::int AS n FROM equipment WHERE crew_id = $1 AND equipment_class = 'HEAVY' AND id <> $2", [crewId, unit.id || 0]);
    if (heavy.rows[0].n >= MAX_HEAVY_PER_CREW) throw httpError(409, `${crew.rows[0].name} already has ${MAX_HEAVY_PER_CREW} heavy units — the maximum per crew`);
  }
  return crew.rows[0];
}

// Moves a unit to a crew (or to the yard with null) and keeps the assignment history in step.
async function setEquipmentCrew(client, equipmentId, crewId, crewName, note) {
  await client.query(
    "UPDATE equipment_assignments SET released_at = CURRENT_TIMESTAMP, release_note = $2 WHERE equipment_id = $1 AND released_at IS NULL",
    [equipmentId, note || (crewId ? 'Reassigned' : 'Returned to yard')]);
  if (crewId) await client.query('INSERT INTO equipment_assignments (equipment_id, crew_id, crew_name) VALUES ($1, $2, $3)', [equipmentId, crewId, crewName]);
  await client.query('UPDATE equipment SET crew_id = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2', [crewId, equipmentId]);
}

// Runs fn(client) in a transaction; releases the client before the caller does any further pool queries.
async function inTransaction(fn) {
  const client = await pool.connect();
  let released = false;
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    client.release(); released = true;
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    if (!released) client.release();
  }
}

const sendError = (res, err) => res.status(err.status || 500).json({ error: err.message });
const fetchEquipment = async (id) => (await pool.query(`${EQUIPMENT_SELECT} WHERE e.id = $1`, [id])).rows[0];

// ---- Equipment scheduling, availability, types and reports ---------------------------------------
const SCHEDULE_SELECT = `
  SELECT sc.id, sc.equipment_id, e.unit_code, e.name AS equipment_name, e.equipment_class, e.equipment_type,
         sc.crew_id, c.name AS crew_name, sc.site_id, st.name AS site_name,
         sc.start_date::text AS start_date, sc.end_date::text AS end_date, sc.purpose, sc.status, sc.created_at
  FROM equipment_schedules sc
  JOIN equipment e ON e.id = sc.equipment_id
  LEFT JOIN crews c ON c.id = sc.crew_id
  LEFT JOIN sites st ON st.id = sc.site_id`;

const isDate = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(new Date(v).getTime());

app.get('/api/equipment/types', async (req, res) => {
  try {
    const r = await pool.query('SELECT equipment_class, type_name FROM equipment_types ORDER BY equipment_class, type_name');
    const out = { HEAVY: [], LIGHT: [] };
    r.rows.forEach((row) => out[row.equipment_class].push(row.type_name));
    res.json(out);
  } catch (err) { sendError(res, err); }
});

// Bookings. ?from=&to= (overlapping window), ?site_id=, ?equipment_id=, ?crew_id=, ?status=
app.get('/api/equipment/schedules', async (req, res) => {
  const { from, to, site_id, equipment_id, crew_id, status } = req.query;
  try {
    if ((from && !isDate(from)) || (to && !isDate(to))) throw httpError(400, 'from and to must be dates (YYYY-MM-DD)');
    for (const [k, v] of Object.entries({ site_id, equipment_id, crew_id })) if (v && !Number.isInteger(Number(v))) throw httpError(400, `${k} must be an id`);
    const r = await pool.query(
      `${SCHEDULE_SELECT}
       WHERE ($1::date IS NULL OR sc.end_date >= $1) AND ($2::date IS NULL OR sc.start_date <= $2)
         AND ($3::int IS NULL OR sc.site_id = $3) AND ($4::int IS NULL OR sc.equipment_id = $4)
         AND ($5::int IS NULL OR sc.crew_id = $5) AND ($6::text IS NULL OR sc.status = $6)
       ORDER BY sc.start_date, e.unit_code`,
      [from || null, to || null, site_id || null, equipment_id || null, crew_id || null, status ? String(status).toUpperCase() : null]);
    res.json(r.rows);
  } catch (err) { sendError(res, err); }
});

// body: { equipment_id, crew_id?, site_id?, start_date, end_date, purpose? }
app.post('/api/equipment/schedules', async (req, res) => {
  try {
    const b = req.body || {};
    if (!Number.isInteger(b.equipment_id)) throw httpError(400, 'equipment_id is required');
    if (!isDate(b.start_date) || !isDate(b.end_date)) throw httpError(400, 'start_date and end_date are required (YYYY-MM-DD)');
    if (b.end_date < b.start_date) throw httpError(400, 'end_date cannot be before start_date');
    for (const k of ['crew_id', 'site_id']) if (b[k] != null && !Number.isInteger(b[k])) throw httpError(400, `${k} must be an id or null`);
    const purpose = b.purpose ? String(b.purpose).trim().slice(0, 200) : null;
    const id = await inTransaction(async (client) => {
      const unit = (await client.query('SELECT id, unit_code, status FROM equipment WHERE id = $1 FOR UPDATE', [b.equipment_id])).rows[0];
      if (!unit) throw httpError(404, 'Equipment not found');
      if (unit.status !== 'AVAILABLE') throw httpError(409, `${unit.unit_code} is ${unit.status.toLowerCase()} and cannot be scheduled`);
      if (b.crew_id != null) {
        const crew = (await client.query('SELECT status FROM crews WHERE id = $1', [b.crew_id])).rows[0];
        if (!crew) throw httpError(404, 'Crew not found');
        if (crew.status === 'OFF_DUTY') throw httpError(409, 'That crew is off duty');
      }
      if (b.site_id != null && !(await client.query('SELECT 1 FROM sites WHERE id = $1', [b.site_id])).rows.length) throw httpError(404, 'Site not found');
      const clash = await client.query(
        "SELECT start_date::text AS s, end_date::text AS e FROM equipment_schedules WHERE equipment_id = $1 AND status = 'SCHEDULED' AND start_date <= $3 AND end_date >= $2 LIMIT 1",
        [b.equipment_id, b.start_date, b.end_date]);
      if (clash.rows.length) throw httpError(409, `${unit.unit_code} is already booked ${clash.rows[0].s} to ${clash.rows[0].e}`);
      const ins = await client.query(
        'INSERT INTO equipment_schedules (equipment_id, crew_id, site_id, start_date, end_date, purpose) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id',
        [b.equipment_id, b.crew_id ?? null, b.site_id ?? null, b.start_date, b.end_date, purpose]);
      return ins.rows[0].id;
    });
    res.status(201).json((await pool.query(`${SCHEDULE_SELECT} WHERE sc.id = $1`, [id])).rows[0]);
  } catch (err) { sendError(res, err); }
});

// body: { status: SCHEDULED | COMPLETED | CANCELLED }
app.patch('/api/equipment/schedules/:sid', async (req, res) => {
  try {
    const status = String((req.body || {}).status || '').toUpperCase();
    if (!['SCHEDULED', 'COMPLETED', 'CANCELLED'].includes(status)) throw httpError(400, 'status must be SCHEDULED, COMPLETED or CANCELLED');
    await inTransaction(async (client) => {
      const cur = (await client.query('SELECT id, equipment_id, start_date::text AS s, end_date::text AS e FROM equipment_schedules WHERE id = $1 FOR UPDATE', [req.params.sid])).rows[0];
      if (!cur) throw httpError(404, 'Booking not found');
      if (status === 'SCHEDULED') {
        const clash = await client.query("SELECT 1 FROM equipment_schedules WHERE equipment_id = $1 AND id <> $2 AND status = 'SCHEDULED' AND start_date <= $4 AND end_date >= $3", [cur.equipment_id, cur.id, cur.s, cur.e]);
        if (clash.rows.length) throw httpError(409, 'Another booking now covers those dates');
      }
      await client.query('UPDATE equipment_schedules SET status = $1 WHERE id = $2', [status, cur.id]);
    });
    res.json((await pool.query(`${SCHEDULE_SELECT} WHERE sc.id = $1`, [req.params.sid])).rows[0]);
  } catch (err) { sendError(res, err); }
});

app.delete('/api/equipment/schedules/:sid', async (req, res) => {
  try {
    const r = await pool.query('DELETE FROM equipment_schedules WHERE id = $1', [Number(req.params.sid) || 0]);
    if (!r.rowCount) return res.status(404).json({ error: 'Booking not found' });
    res.json({ ok: true });
  } catch (err) { sendError(res, err); }
});

// Units free for a whole date window: status AVAILABLE, not booked in the window. ?from=&to= (required), ?class=
app.get('/api/equipment/availability', async (req, res) => {
  try {
    const { from, to, class: cls } = req.query;
    if (!isDate(from) || !isDate(to)) throw httpError(400, 'from and to are required (YYYY-MM-DD)');
    if (to < from) throw httpError(400, 'to cannot be before from');
    const r = await pool.query(
      `${EQUIPMENT_SELECT}
       WHERE e.status = 'AVAILABLE' AND ($3::text IS NULL OR e.equipment_class = $3)
         AND NOT EXISTS (SELECT 1 FROM equipment_schedules sc WHERE sc.equipment_id = e.id AND sc.status = 'SCHEDULED' AND sc.start_date <= $2 AND sc.end_date >= $1)
       ORDER BY e.equipment_class ASC, e.unit_code`, [from, to, cls ? String(cls).toUpperCase() : null]);
    res.json({ from, to, units: r.rows });
  } catch (err) { sendError(res, err); }
});

// Fleet report: status mix, service due, booked days (last 30 days) per unit, crew load and bookings per site
app.get('/api/equipment/report', async (req, res) => {
  try {
    const [byStatus, service, utilisation, byCrew, bySite] = await Promise.all([
      pool.query('SELECT equipment_class, status, COUNT(*)::int AS units FROM equipment GROUP BY 1, 2 ORDER BY 1, 2'),
      pool.query(`SELECT e.id, e.unit_code, e.name, e.equipment_class, e.next_service_due::text AS next_service_due,
                         (e.next_service_due - CURRENT_DATE)::int AS days_left
                  FROM equipment e WHERE e.status <> 'RETIRED' AND e.next_service_due IS NOT NULL AND e.next_service_due <= CURRENT_DATE + 30
                  ORDER BY e.next_service_due`),
      pool.query(`SELECT e.id, e.unit_code, e.name, e.equipment_class,
                         COALESCE(SUM(GREATEST(0, LEAST(sc.end_date, CURRENT_DATE) - GREATEST(sc.start_date, CURRENT_DATE - 29) + 1)) FILTER (WHERE sc.status <> 'CANCELLED'), 0)::int AS booked_days_30d
                  FROM equipment e LEFT JOIN equipment_schedules sc ON sc.equipment_id = e.id
                  WHERE e.status <> 'RETIRED' GROUP BY e.id ORDER BY booked_days_30d DESC, e.unit_code`),
      pool.query(`SELECT c.id AS crew_id, c.name AS crew_name,
                         COUNT(e.id) FILTER (WHERE e.equipment_class = 'HEAVY')::int AS heavy,
                         COUNT(e.id) FILTER (WHERE e.equipment_class = 'LIGHT')::int AS light
                  FROM crews c LEFT JOIN equipment e ON e.crew_id = c.id GROUP BY c.id ORDER BY c.name`),
      pool.query(`SELECT st.id AS site_id, st.name AS site_name, COUNT(*)::int AS bookings, COUNT(DISTINCT sc.equipment_id)::int AS units
                  FROM equipment_schedules sc JOIN sites st ON st.id = sc.site_id WHERE sc.status = 'SCHEDULED'
                  GROUP BY st.id ORDER BY bookings DESC, st.name`),
    ]);
    res.json({ generated_at: new Date().toISOString(), by_status: byStatus.rows, service_due: service.rows, utilisation_30d: utilisation.rows, by_crew: byCrew.rows, by_site: bySite.rows });
  } catch (err) { sendError(res, err); }
});

app.get('/api/equipment', async (req, res) => {
  const { class: cls, status, crew_id, q } = req.query;
  try {
    const result = await pool.query(
      `${EQUIPMENT_SELECT}
       WHERE ($1::text IS NULL OR e.equipment_class = $1)
         AND ($2::text IS NULL OR e.status = $2)
         AND ($3::text IS NULL OR ($3 = 'none' AND e.crew_id IS NULL) OR e.crew_id::text = $3)
         AND ($4::text IS NULL OR e.unit_code ILIKE '%' || $4 || '%' OR e.name ILIKE '%' || $4 || '%' OR e.equipment_type ILIKE '%' || $4 || '%')
       ORDER BY e.equipment_class ASC, e.unit_code`,
      [cls ? String(cls).toUpperCase() : null, status ? String(status).toUpperCase() : null, crew_id ? String(crew_id) : null, q ? String(q) : null]);
    res.json(result.rows);
  } catch (err) { sendError(res, err); }
});

// Fleet counts by class and state, for the Equipment page and the Dashboard
app.get('/api/equipment/summary', async (req, res) => {
  try {
    const r = await pool.query(`
      SELECT equipment_class,
             COUNT(*) FILTER (WHERE status <> 'RETIRED')::int AS total,
             COUNT(*) FILTER (WHERE status = 'AVAILABLE' AND crew_id IS NULL)::int AS free,
             COUNT(*) FILTER (WHERE status = 'AVAILABLE' AND crew_id IS NOT NULL)::int AS assigned,
             COUNT(*) FILTER (WHERE status = 'MAINTENANCE')::int AS maintenance,
             COUNT(*) FILTER (WHERE status = 'RETIRED')::int AS retired,
             COUNT(*) FILTER (WHERE status <> 'RETIRED' AND next_service_due < CURRENT_DATE)::int AS service_overdue
      FROM equipment GROUP BY equipment_class`);
    const zero = { total: 0, free: 0, assigned: 0, maintenance: 0, retired: 0, service_overdue: 0 };
    const out = { HEAVY: { ...zero }, LIGHT: { ...zero } };
    r.rows.forEach((row) => { out[row.equipment_class] = { ...zero, ...row }; delete out[row.equipment_class].equipment_class; });
    res.json(out);
  } catch (err) { sendError(res, err); }
});

app.get('/api/equipment/:id/history', async (req, res) => {
  try {
    const r = await pool.query(
      `SELECT id, crew_id, crew_name, assigned_at, released_at, release_note,
              ROUND(EXTRACT(EPOCH FROM (COALESCE(released_at, CURRENT_TIMESTAMP) - assigned_at)) / 86400)::int AS days
       FROM equipment_assignments WHERE equipment_id = $1 ORDER BY assigned_at DESC, id DESC`, [req.params.id]);
    res.json(r.rows);
  } catch (err) { sendError(res, err); }
});

app.post('/api/equipment', async (req, res) => {
  try {
    const data = readEquipmentBody(req.body, false);
    const id = await inTransaction(async (client) => {
      const dup = await client.query('SELECT 1 FROM equipment WHERE lower(unit_code) = lower($1)', [data.unit_code]);
      if (dup.rows.length) throw httpError(409, `Unit code ${data.unit_code} already exists`);
      const status = data.status || 'AVAILABLE';
      const crewId = data.crew_id ?? null;
      let crew = null;
      if (crewId) crew = await checkCrewCanTake(client, { ...data, status }, crewId);
      const ins = await client.query(
        `INSERT INTO equipment (unit_code, name, equipment_class, equipment_type, make_model, status, last_service_on, next_service_due, notes, crew_id)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
        [data.unit_code, data.name, data.equipment_class, data.equipment_type, data.make_model ?? null, status, data.last_service_on ?? null, data.next_service_due ?? null, data.notes ?? null, crewId]);
      if (crew) await client.query('INSERT INTO equipment_assignments (equipment_id, crew_id, crew_name) VALUES ($1, $2, $3)', [ins.rows[0].id, crewId, crew.name]);
      await client.query('INSERT INTO equipment_types (equipment_class, type_name) VALUES ($1, $2) ON CONFLICT DO NOTHING', [data.equipment_class, data.equipment_type]);
      return ins.rows[0].id;
    });
    res.status(201).json(await fetchEquipment(id));
  } catch (err) { sendError(res, err); }
});

// Edit details. Moving a unit to MAINTENANCE or RETIRED releases it from its crew automatically.
app.put('/api/equipment/:id', async (req, res) => {
  try {
    const data = readEquipmentBody(req.body, true);
    if ('crew_id' in data) throw httpError(400, 'Use PATCH /api/equipment/:id to assign a crew');
    await inTransaction(async (client) => {
      const cur = (await client.query(
        `SELECT id, unit_code, name, equipment_class, equipment_type, make_model, status, notes, crew_id,
                last_service_on::text AS last_service_on, next_service_due::text AS next_service_due
         FROM equipment WHERE id = $1 FOR UPDATE`, [req.params.id])).rows[0];
      if (!cur) throw httpError(404, 'Equipment not found');
      if (data.unit_code && data.unit_code.toLowerCase() !== cur.unit_code.toLowerCase()) {
        const dup = await client.query('SELECT 1 FROM equipment WHERE lower(unit_code) = lower($1) AND id <> $2', [data.unit_code, cur.id]);
        if (dup.rows.length) throw httpError(409, `Unit code ${data.unit_code} already exists`);
      }
      const next = { ...cur, ...data };
      if (cur.crew_id && next.equipment_class === 'HEAVY' && cur.equipment_class !== 'HEAVY') {
        await checkCrewCanTake(client, { ...next, id: cur.id, status: 'AVAILABLE' }, cur.crew_id);
      }
      await client.query(
        `UPDATE equipment SET unit_code=$1, name=$2, equipment_class=$3, equipment_type=$4, make_model=$5, status=$6,
                last_service_on=$7, next_service_due=$8, notes=$9, updated_at=CURRENT_TIMESTAMP WHERE id=$10`,
        [next.unit_code, next.name, next.equipment_class, next.equipment_type, next.make_model, next.status,
          next.last_service_on || null, next.next_service_due || null, next.notes, cur.id]);
      await client.query('INSERT INTO equipment_types (equipment_class, type_name) VALUES ($1, $2) ON CONFLICT DO NOTHING', [next.equipment_class, next.equipment_type]);
      if (next.status !== 'AVAILABLE') {
        // a unit that is not available cannot keep upcoming bookings
        await client.query("UPDATE equipment_schedules SET status = 'CANCELLED' WHERE equipment_id = $1 AND status = 'SCHEDULED' AND end_date >= CURRENT_DATE", [cur.id]);
      }
      if (next.status !== 'AVAILABLE' && cur.crew_id) {
        await setEquipmentCrew(client, cur.id, null, null, next.status === 'RETIRED' ? 'Retired' : 'Sent to maintenance');
      }
    });
    res.json(await fetchEquipment(req.params.id));
  } catch (err) { sendError(res, err); }
});

// Assign a unit to a crew, or release it back to the yard with crew_id = null
app.patch('/api/equipment/:id', async (req, res) => {
  const { crew_id } = req.body || {};
  if (crew_id !== null && !Number.isInteger(crew_id)) return res.status(400).json({ error: 'crew_id must be a crew id or null' });
  try {
    await inTransaction(async (client) => {
      const unit = (await client.query('SELECT id, unit_code, equipment_class, status, crew_id FROM equipment WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
      if (!unit) throw httpError(404, 'Equipment not found');
      if (unit.crew_id === crew_id) return;
      let crew = null;
      if (crew_id !== null) crew = await checkCrewCanTake(client, unit, crew_id);
      await setEquipmentCrew(client, unit.id, crew_id, crew && crew.name);
    });
    res.json(await fetchEquipment(req.params.id));
  } catch (err) { sendError(res, err); }
});

// Delete only units that are not on a crew; retire (status RETIRED) instead if history should be kept in the list
app.delete('/api/equipment/:id', async (req, res) => {
  try {
    await inTransaction(async (client) => {
      const unit = (await client.query('SELECT id, unit_code, crew_id FROM equipment WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
      if (!unit) throw httpError(404, 'Equipment not found');
      if (unit.crew_id) throw httpError(409, `${unit.unit_code} is assigned to a crew — release it first`);
      await client.query('DELETE FROM equipment WHERE id = $1', [unit.id]);
    });
    res.json({ ok: true });
  } catch (err) { sendError(res, err); }
});

// ---- GIS layers (PostGIS -> GeoJSON) --------------------------------------------------------------
// One call returns everything the Prediction map draws as GeoJSON: the site boundary (a 400 m buffer around the
// convex hull of its assets, computed on the geography type so the area is real square kilometres), the dune
// forecast zones that touch it, and the blocks (assets) with their latest predicted risk.
app.get('/api/sites/:id/layers', async (req, res) => {
  const siteId = Number(req.params.id);
  try {
    const site = await pool.query('SELECT id, code, name, ST_X(geom) AS lon, ST_Y(geom) AS lat FROM sites WHERE id = $1', [siteId]);
    if (!site.rows.length) return res.status(404).json({ error: 'Site not found' });

    const boundary = await pool.query(`
      WITH hull AS (SELECT ST_Buffer(ST_ConvexHull(ST_Collect(geom))::geography, 400) AS g FROM assets WHERE site_id = $1)
      SELECT ST_AsGeoJSON(g::geometry)::json AS geometry, ROUND((ST_Area(g) / 1000000)::numeric, 2)::float AS area_km2
      FROM hull WHERE g IS NOT NULL`, [siteId]);

    const zones = await pool.query(`
      WITH hull AS (SELECT ST_Buffer(ST_ConvexHull(ST_Collect(geom))::geography, 400)::geometry AS g FROM assets WHERE site_id = $1)
      SELECT df.id, df.risk_level, df.encroach_rate_m_per_yr::float AS encroach_rate_m_per_yr, ST_AsGeoJSON(df.geom)::json AS geometry
      FROM dune_forecasts df, hull WHERE hull.g IS NOT NULL AND ST_Intersects(df.geom, hull.g)`, [siteId]);

    const blocks = await pool.query(`
      SELECT a.id, a.name, a.asset_type, a.criticality, ST_AsGeoJSON(a.geom)::json AS geometry
      FROM assets a WHERE a.site_id = $1 ORDER BY a.id`, [siteId]);

    const b = boundary.rows[0];
    res.json({
      site: site.rows[0],
      area_km2: b ? b.area_km2 : null,
      boundary: b ? { type: 'Feature', properties: { kind: 'site-boundary', area_km2: b.area_km2 }, geometry: b.geometry } : null,
      zones: { type: 'FeatureCollection', features: zones.rows.map((z) => ({ type: 'Feature', properties: { id: z.id, risk_level: z.risk_level, encroach_rate_m_per_yr: z.encroach_rate_m_per_yr }, geometry: z.geometry })) },
      blocks: { type: 'FeatureCollection', features: blocks.rows.map((r) => ({ type: 'Feature', properties: { id: r.id, name: r.name, asset_type: r.asset_type, criticality: r.criticality }, geometry: r.geometry })) },
    });
  } catch (err) { sendError(res, err); }
});

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

// ---------------------------------------------------------------------------
// Push notification subscription management
// ---------------------------------------------------------------------------
app.get('/api/push/vapid-public-key', (req, res) => {
  if (!pushEnabled) return res.status(503).json({ error: 'Push notifications are not configured on this server' });
  res.json({ publicKey: VAPID_PUBLIC_KEY });
});

app.post('/api/crews/:id/push-subscribe', async (req, res) => {
  const { id } = req.params;
  const { subscription } = req.body;
  if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
    return res.status(400).json({ error: 'A valid push subscription object is required' });
  }
  try {
    await pool.query(
      `INSERT INTO push_subscriptions (crew_id, endpoint, p256dh, auth)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (endpoint) DO UPDATE SET crew_id = EXCLUDED.crew_id, p256dh = EXCLUDED.p256dh, auth = EXCLUDED.auth`,
      [id, subscription.endpoint, subscription.keys.p256dh, subscription.keys.auth]
    );
    res.status(201).json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/crews/:id/push-unsubscribe', async (req, res) => {
  const { endpoint } = req.body;
  if (!endpoint) return res.status(400).json({ error: 'endpoint is required' });
  try {
    await pool.query('DELETE FROM push_subscriptions WHERE endpoint = $1', [endpoint]);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===========================================================================
// SAND ACCUMULATION PREDICTION — AI backend integration (Prediction page v2)
// A single global, multi-site 7-day forecast (not scoped to one site/assets
// like sand_predictions above). Flow: Run Prediction -> call the AI backend
// (or fall back to prediction.json, see sandSiteDashboard.js) -> upsert into
// prediction_runs / prediction_sites, keyed by (site_name, schedule window)
// so re-running the same window never creates duplicates -> return the
// stored run to the frontend. See "Sand Accumulation Prediction" requirements
// doc delivered alongside this change for the full spec.
// ===========================================================================
const PREDICTION_SITE_COLS = `
  id, run_id, site_name, risk_level, lat, lon, total_area_km2::float AS total_area_km2,
  predicted_accumulation_m::float AS predicted_accumulation_m, net_accumulation_m::float AS net_accumulation_m,
  sand_deposition_m3::float AS sand_deposition_m3,
  sand_deposition_low_m3::float AS sand_deposition_low_m3,
  sand_deposition_expected_m3::float AS sand_deposition_expected_m3,
  sand_deposition_high_m3::float AS sand_deposition_high_m3,
  confidence_pct::float AS confidence_pct, dune_direction_deg::float AS dune_direction_deg,
  dune_intensity_pct::float AS dune_intensity_pct,
  ST_AsGeoJSON(current_zone)::json AS current_zone, ST_AsGeoJSON(predicted_zone)::json AS predicted_zone,
  accumulation_trend, window_start::text AS window_start, window_end::text AS window_end, updated_at`;

async function loadPredictionRun(runId) {
  const run = await pool.query(
    `SELECT run_id, start_date::text AS start_date, end_date::text AS end_date, created_date, status, source,
            risk_summary, model_metrics, sand_model, environmental_model
     FROM prediction_runs WHERE run_id = $1`, [runId]);
  if (!run.rows.length) return null;
  const sites = await pool.query(
    `SELECT ${PREDICTION_SITE_COLS} FROM prediction_sites WHERE run_id = $1 ORDER BY site_name`, [runId]);
  return { ...run.rows[0], sites: sites.rows };
}

// Turns a site_name like "Station 1" into a stable, short, unique-ish code
// ("STATION-1") for the legacy sites.code column.
function siteCodeFromName(name) {
  const code = String(name).toUpperCase().trim().replace(/[^A-Z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return (code || 'SITE').slice(0, 20);
}

// Keeps the legacy sites/assets tables (used by Dashboard, Dispatch, Work
// Orders, Crews and Equipment scheduling) in sync with the AI backend, so
// those pages work off the same real, API-sourced sites as the Prediction
// page instead of placeholder data — upserted by code, so re-running never
// duplicates a site or its representative asset.
//
// It ALSO (re)computes that site's Scheduling Team requirement with the
// ORIGINAL engine (backend/prediction.js) and stores it as a normal
// sand_predictions row. This is what lets the Scheduling Team widget stay
// populated from the single, top-level "Run Prediction" button — it never
// calls the AI backend itself and never reads the AI response's "schedule"
// object; it only ever runs the pre-existing, untouched prediction.js logic.
async function syncLegacySiteAndAsset(client, s, { startDate, endDate }) {
  const lat = s.coordinates?.lat;
  const lon = s.coordinates?.lng;
  if (lat == null || lon == null) return;
  const code = siteCodeFromName(s.site_name);
  // Derive a real starting depth from the run's own numbers (predicted - net = before this
  // run) rather than inventing one; fall back to the table's own default if not computable.
  const baseline = (s.predicted_accumulation_m != null && s.net_accumulation_m != null)
    ? Math.max(0, s.predicted_accumulation_m - s.net_accumulation_m)
    : null;

  const siteRow = await client.query(
    `INSERT INTO sites (code, name, region, geom, baseline_accum_m, sort_order)
     VALUES ($1, $2, 'AI Prediction Backend', ST_SetSRID(ST_MakePoint($3,$4),4326),
             COALESCE($5, 0.5), (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM sites))
     ON CONFLICT (code) DO UPDATE SET
       name = EXCLUDED.name, geom = EXCLUDED.geom,
       baseline_accum_m = COALESCE($5, sites.baseline_accum_m)
     RETURNING id, baseline_accum_m::float AS baseline_accum_m,
               wind_drift_potential::float AS wind_drift_potential, sand_supply_index::float AS sand_supply_index`,
    [code, s.site_name, lon, lat, baseline]);
  const siteRowData = siteRow.rows[0];
  const siteId = siteRowData.id;
  const assetName = `${s.site_name} — Facility`;

  const assetRow = await client.query(
    `INSERT INTO assets (site_id, name, asset_type, criticality, geom)
     VALUES ($1, $2, 'FACILITY', 'STANDARD', ST_SetSRID(ST_MakePoint($3,$4),4326))
     ON CONFLICT (site_id, name) DO UPDATE SET geom = EXCLUDED.geom
     RETURNING id`,
    [siteId, assetName, lon, lat]);
  const assetId = assetRow.rows[0].id;

  const days = Math.max(1, Math.round((new Date(endDate) - new Date(startDate)) / 86400000)) || 7;
  const r = runSandPrediction({
    site: siteRowData,
    assets: [{ id: assetId, name: assetName, asset_type: 'FACILITY', lat, lon, zone_rate: null }],
    startDate,
    windowDays: days,
  });
  await client.query(
    `INSERT INTO sand_predictions
       (site_id, window_start, window_end, window_days, current_accum_m, predicted_accum_m, net_accum_m, risk_level, confidence_pct,
        risk_counts, asset_results, model_results, series, metrics, resources)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,
    [siteId, r.window_start, r.window_end, r.window_days, r.current_accum_m, r.predicted_accum_m, r.net_accum_m, r.risk_level, r.confidence_pct,
      JSON.stringify(r.risk_counts), JSON.stringify(r.asset_results), JSON.stringify(r.model_results), JSON.stringify(r.series),
      JSON.stringify(r.metrics), JSON.stringify(r.resources)]);
}

// Upserts one AI-backend/mock response: one prediction_runs row (the run-level
// risk summary / model metrics / model descriptors) and one prediction_sites
// row per site, keyed by (site_name, schedule window) — requirement: running
// a prediction multiple times must never duplicate sites, schedules, polygons
// or prediction records; update the existing record, insert only if new.
async function persistPredictionRun({ startDate, endDate, source, data }) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const runIns = await client.query(
      `INSERT INTO prediction_runs (start_date, end_date, status, source, risk_summary, model_metrics, sand_model, environmental_model, raw_response)
       VALUES ($1,$2,'COMPLETED',$3,$4,$5,$6,$7,$8) RETURNING run_id`,
      [startDate, endDate, source, JSON.stringify(data.risk_summary || {}), JSON.stringify(data.model_metrics || {}),
        JSON.stringify(data['Sand Model'] || {}), JSON.stringify(data['Environmental Model'] || {}), JSON.stringify(data)]);
    const runId = runIns.rows[0].run_id;

    // NOTE: the API's scheduling / s.schedule objects are not copied into columns; they stay
    // in raw_response and GET /api/planning/plan reads them from there.
    for (const s of (data.sites || [])) {
      const dep = s.sand_deposition_range_m3 || {};
      const dune = s.dune_movement || {};
      const zones = siteZones(s); // zones live inside dune_movement in the updated prediction.json
      await client.query(
        `INSERT INTO prediction_sites (
           run_id, site_name, risk_level, lat, lon, total_area_km2,
           predicted_accumulation_m, net_accumulation_m, sand_deposition_m3,
           sand_deposition_low_m3, sand_deposition_expected_m3, sand_deposition_high_m3,
           confidence_pct, dune_direction_deg, dune_intensity_pct,
           current_zone, predicted_zone, accumulation_trend, window_start, window_end, updated_at
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,
           ST_SetSRID(ST_GeomFromGeoJSON($16),4326), ST_SetSRID(ST_GeomFromGeoJSON($17),4326),
           $18,$19,$20, CURRENT_TIMESTAMP)
         ON CONFLICT (site_name, window_start, window_end) DO UPDATE SET
           run_id = EXCLUDED.run_id, risk_level = EXCLUDED.risk_level, lat = EXCLUDED.lat, lon = EXCLUDED.lon,
           total_area_km2 = EXCLUDED.total_area_km2, predicted_accumulation_m = EXCLUDED.predicted_accumulation_m,
           net_accumulation_m = EXCLUDED.net_accumulation_m, sand_deposition_m3 = EXCLUDED.sand_deposition_m3,
           sand_deposition_low_m3 = EXCLUDED.sand_deposition_low_m3, sand_deposition_expected_m3 = EXCLUDED.sand_deposition_expected_m3,
           sand_deposition_high_m3 = EXCLUDED.sand_deposition_high_m3, confidence_pct = EXCLUDED.confidence_pct,
           dune_direction_deg = EXCLUDED.dune_direction_deg, dune_intensity_pct = EXCLUDED.dune_intensity_pct,
           current_zone = EXCLUDED.current_zone, predicted_zone = EXCLUDED.predicted_zone,
           accumulation_trend = EXCLUDED.accumulation_trend, updated_at = CURRENT_TIMESTAMP`,
        [runId, s.site_name, s.risk, s.coordinates?.lat ?? null, s.coordinates?.lng ?? null, s.total_area_km2 ?? null,
          s.predicted_accumulation_m ?? null, s.net_accumulation_m ?? null, s.sand_deposition_m3 ?? null,
          dep.low ?? null, dep.expected ?? null, dep.high ?? null,
          s.confidence_pct ?? null, dune.direction_deg ?? null, dune.intensity_pct ?? null,
          zones.current ? JSON.stringify(zones.current) : null, zones.predicted ? JSON.stringify(zones.predicted) : null,
          s.accumulation_trend ? JSON.stringify(s.accumulation_trend) : null, startDate, endDate]);

      // Non-fatal by design: the legacy sites/assets/Scheduling-Team sync is a
      // secondary convenience. If it fails for one site (bad geometry, etc.) the
      // primary AI prediction data above must still commit — "Run Prediction"
      // must never fail because of this. A SAVEPOINT is required here, not just
      // try/catch: once any query inside a Postgres transaction errors, the
      // whole transaction is aborted until a rollback, so a plain try/catch
      // around a failing query would silently poison every insert after it
      // (including the COMMIT) even though the error looked "caught".
      await client.query('SAVEPOINT sync_site');
      try {
        await syncLegacySiteAndAsset(client, s, { startDate, endDate });
        await client.query('RELEASE SAVEPOINT sync_site');
      } catch (syncErr) {
        await client.query('ROLLBACK TO SAVEPOINT sync_site');
        console.warn(`Legacy site/asset sync failed for "${s.site_name}": ${syncErr.message}`);
      }
    }
    await client.query('COMMIT');
    return runId;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

// Run (or mock) the AI prediction for every site and persist it (upsert).
// body: { start_date?, end_date? } — start defaults to today, end always
// defaults to start + 7 days (the window is always 7 days, per the spec).
app.post('/api/predictions/run', async (req, res) => {
  try {
    const startDate = (req.body && req.body.start_date) || new Date().toISOString().slice(0, 10);
    const endDate = (req.body && req.body.end_date) || new Date(new Date(startDate).getTime() + 7 * 86400000).toISOString().slice(0, 10);
    const { data, source } = await fetchSiteDashboardPrediction(startDate, endDate);
    const runId = await persistPredictionRun({ startDate, endDate, source, data });
    res.status(201).json(await loadPredictionRun(runId));
  } catch (err) {
    res.status(502).json({ error: `Prediction run failed: ${err.message}` });
  }
});

// Latest completed run (so the page restores its state on reload), or null.
app.get('/api/predictions/runs/latest', async (req, res) => {
  try {
    const r = await pool.query(`SELECT run_id FROM prediction_runs WHERE status = 'COMPLETED' ORDER BY created_date DESC, run_id DESC LIMIT 1`);
    res.json(r.rows.length ? await loadPredictionRun(r.rows[0].run_id) : null);
  } catch (err) { sendError(res, err); }
});

// Prediction history (the PredictionRun master list) — newest first.
app.get('/api/predictions/runs', async (req, res) => {
  try {
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
    const r = await pool.query(
      `SELECT run_id, start_date::text AS start_date, end_date::text AS end_date, created_date, status, source,
              (SELECT COUNT(*)::int FROM prediction_sites ps WHERE ps.run_id = pr.run_id) AS site_count
       FROM prediction_runs pr ORDER BY created_date DESC, run_id DESC LIMIT $1`, [limit]);
    res.json(r.rows);
  } catch (err) { sendError(res, err); }
});

// One run with all its sites — the drill-down data source.
app.get('/api/predictions/runs/:runId(\\d+)', async (req, res) => {
  try {
    const run = await loadPredictionRun(Number(req.params.runId));
    if (!run) return res.status(404).json({ error: 'Prediction run not found' });
    res.json(run);
  } catch (err) { sendError(res, err); }
});

// ---------------------------------------------------------------------------
// Operational planning (prediction-driven decision support) — backend/planning.js.
// Computed on demand from a stored run plus the CURRENT crews, equipment and
// bookings, so it always reflects who is free right now. Nothing is stored.
// Only prediction numbers are read from the run; the prediction API's own
// schedule / team / equipment objects are never used.
// GET /api/planning/plan[?run_id=]  (defaults to the latest completed run)
// ---------------------------------------------------------------------------
app.get('/api/planning/plan', async (req, res) => {
  try {
    let runId = req.query.run_id ? Number(req.query.run_id) : null;
    if (req.query.run_id && !Number.isInteger(runId)) return res.status(400).json({ error: 'run_id must be a number' });
    if (!runId) {
      const l = await pool.query(`SELECT run_id FROM prediction_runs WHERE status = 'COMPLETED' ORDER BY created_date DESC, run_id DESC LIMIT 1`);
      if (!l.rows.length) return res.json(null);
      runId = l.rows[0].run_id;
    }
    const run = await loadPredictionRun(runId);
    if (!run) return res.status(404).json({ error: 'Prediction run not found' });

    // two prediction fields that are not stored in columns: the "movement observed" flag and the daily volume series
    const raw = await pool.query(
      `SELECT raw_response->'accumulation_trend_m3' AS trend, raw_response->'scheduling' AS sched,
              (SELECT jsonb_object_agg(x->>'site_name', x->'schedule')
                 FROM jsonb_array_elements(COALESCE(raw_response->'sites', '[]'::jsonb)) x WHERE x->'schedule' IS NOT NULL) AS site_sched,
              (SELECT jsonb_object_agg(x->>'site_name', COALESCE((x->>'observed_movement_detected')::boolean, false))
                 FROM jsonb_array_elements(COALESCE(raw_response->'sites', '[]'::jsonb)) x) AS observed
       FROM prediction_runs WHERE run_id = $1`, [runId]);
    const observed = raw.rows[0].observed || {};
    const sites = run.sites.map((s) => ({ ...s, observed_movement_detected: !!observed[s.site_name] }));

    const [crews, equipment, bookings, legacy] = await Promise.all([
      pool.query(`SELECT id, name, status, specialty, base_location, headcount, ST_Y(geom) AS lat, ST_X(geom) AS lon FROM crews ORDER BY id`),
      pool.query(`SELECT id, unit_code, name, equipment_class, equipment_type AS type_name, status, crew_id FROM equipment WHERE status <> 'RETIRED' ORDER BY unit_code`),
      pool.query(`SELECT equipment_id FROM equipment_schedules WHERE status = 'SCHEDULED' AND start_date <= $2 AND end_date >= $1`, [run.start_date, run.end_date]),
      pool.query(`SELECT s.name, s.id AS site_id, (SELECT a.id FROM assets a WHERE a.site_id = s.id ORDER BY a.id LIMIT 1) AS asset_id FROM sites s`),
    ]);
    const legacyBySite = Object.fromEntries(legacy.rows.map((r) => [r.name, { site_id: r.site_id, asset_id: r.asset_id }]));
    res.json(buildPlan({
      run, sites, crews: crews.rows, equipment: equipment.rows, bookings: bookings.rows,
      trend: Array.isArray(raw.rows[0].trend) ? raw.rows[0].trend : [], legacy: legacyBySite,
      apiPlan: raw.rows[0].sched || null, siteSched: raw.rows[0].site_sched || {},
    }));
  } catch (err) { sendError(res, err); }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Dune Dynamix Portal API running on port ${PORT}`));
